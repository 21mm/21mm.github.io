const openButton = document.getElementById("open-aquvi");
const status = document.getElementById("popup-status");

openButton.addEventListener("click", async () => {
  openButton.disabled = true;
  status.textContent = "";
  try {
    await chrome.tabs.create({ url: chrome.runtime.getURL("viewer/index.html") });
    window.close();
  } catch (error) {
    status.textContent = error && error.message ? error.message : "Aquviを開けませんでした。";
    openButton.disabled = false;
  }
});

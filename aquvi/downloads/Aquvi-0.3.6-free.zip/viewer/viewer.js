import { buildPageViews, findViewIndexForImage, VIEW_MODES } from "../src/archive/page-layout.mjs";
import { initializeSecureHandoffStorage } from "../src/archive/file-handoff.mjs";
import { createFolderArchive } from "../src/archive/folder-reader.mjs";
import { buildBookshelfIndex, getBookshelfNode, listBookshelfItems } from "../src/archive/bookshelf-index.mjs";
import { createAndCacheThumbnail, getCachedThumbnail, clearCachedThumbnails, getCachedThumbnailStats } from "../src/archive/thumbnail-cache.mjs";
import { readEncryptedPageCache, writeEncryptedPageCache, setEncryptedPageCacheLimit, getEncryptedPageCacheStats, clearEncryptedPageCache } from "../src/archive/encrypted-page-cache.mjs";
import { loadReadingPosition, saveReadingPosition, clearReadingPositions, removeLegacyReadingPositions } from "../src/archive/reading-position-vault.mjs";
import { saveBookshelfHandle, getSavedBookshelfHandle, getBookshelfPermission, requestBookshelfPermission, forgetBookshelfHandle } from "../src/archive/bookshelf-handle-vault.mjs";
import {
  saveDefaultArchivePassword, loadDefaultArchivePassword,
  deleteDefaultArchivePassword, hasSavedDefaultArchivePassword
} from "../src/archive/password-vault.mjs";
import {
  buildDirectoryBookshelf, getDirectoryBookshelfNode, scanDirectoryLevel,
  readDirectoryBookImages, getDirectoryFile
} from "../src/archive/directory-bookshelf.mjs";

const $ = (id) => document.getElementById(id);
const appShell=$("app-shell"),workspace=$("workspace"),fileList=$("file-list");
const fileCount=$("file-count"),archiveName=$("archive-name"),pageContent=$("page-content");
const stage=$("stage"),emptyState=$("empty-state"),pageCounter=$("page-counter");
const pageCaption=$("page-caption"),readerStatus=$("reader-status"),loadingStatus=$("loading-status");
const previousButton=$("previous-view"),nextButton=$("next-view");
const directionButton=$("direction-toggle"),pageShiftButton=$("page-shift");
const sidebarButton=$("toggle-sidebar"),sidebarToggleIcon=$("sidebar-toggle-icon");
const readingModeButton=$("reading-mode"),modeSelect=$("mode-select");
const fileListPrev=$("file-list-prev"),fileListNext=$("file-list-next"),fileListPageLabel=$("file-list-page");
const rememberPositionInput=$("remember-position");
const screenPrivacyInput=$("screen-privacy-mode");
const passwordDialog=$("password-dialog"),passwordForm=$("password-form");
const passwordInput=$("password-input"),passwordMessage=$("password-message");
const passwordCancel=$("password-cancel");
const rememberDefaultPasswordInput=$("remember-default-password");
const forgetDefaultPasswordButton=$("forget-default-password");
const passwordStorageNote=$("password-storage-note");
const bookshelfToggle=$("bookshelf-toggle"),bookshelfPanel=$("bookshelf-panel");
const bookshelfClose=$("bookshelf-close"),bookshelfScan=$("bookshelf-scan");
const bookshelfUp=$("bookshelf-up"),bookshelfRootName=$("bookshelf-root-name");
const bookshelfBreadcrumb=$("bookshelf-breadcrumb"),bookshelfGrid=$("bookshelf-grid");
const bookshelfCount=$("bookshelf-count"),bookshelfStatus=$("bookshelf-status");
const settingsDialog=$("settings-dialog"),settingsOpen=$("settings-open"),settingsClose=$("settings-close");
const rememberBookshelfInput=$("remember-bookshelf"),cacheLimitSelect=$("cache-limit"),cacheUsageLabel=$("cache-usage"),cacheClearButton=$("cache-clear");
const REMEMBER_BOOKSHELF_KEY="aquvi.rememberBookshelf",CACHE_LIMIT_KEY="aquvi.encryptedPageCacheLimit";
let rememberBookshelf=true;
try{rememberBookshelf=localStorage.getItem(REMEMBER_BOOKSHELF_KEY)!=="false";}catch{}
const FILE_LIST_PAGE_SIZE=100;
const DEFAULT_PASSWORD_KEY="aquvi.defaultArchivePassword";
const legacyPlaintextPasswordRemoved=(()=>{
  try{
    const existed=Boolean(localStorage.getItem(DEFAULT_PASSWORD_KEY));
    localStorage.removeItem(DEFAULT_PASSWORD_KEY);
    return existed;
  }catch{return false;}
})();

let archive=null,sourceImages=[],pageViews=[],currentViewIndex=0,fileListPage=0,currentPositionKey="";
let readingPositionWrite=Promise.resolve();
const savedMode=localStorage.getItem("aquvi.mode");
let mode=VIEW_MODES.includes(savedMode)?savedMode:"single";
let direction=localStorage.getItem("aquvi.direction")==="ltr"?"ltr":"rtl";
let pageShifted=localStorage.getItem("aquvi.pageShifted")==="true";
let sidebarVisible=localStorage.getItem("aquvi.sidebarVisible")!=="false";
let objectUrls=[],loadToken=0,currentImageIndex=-1,currentSide=null,readingMode=false,readingFullscreenSize=null;
let screenPrivacyEnabled=localStorage.getItem("aquvi.screenPrivacy")!=="false";
let windowFocused=document.hasFocus(),printPreviewActive=false;
let passwordPromptPromise=null,passwordPromptResolve=null,pendingDefaultPassword=null;
let bookshelfIndex=null,bookshelfPath=[],bookshelfPreviewUrls=[],bookshelfSeriesContext=null,savedBookshelfHandle=null;
let bookshelfRenderToken=0,archivePreviewQueue=[],archivePreviewBusy=false,archivePreviewObserver=null,bookshelfImagePreviewObserver=null;
const archivePreviewTargets=new WeakMap(),bookshelfImagePreviewTargets=new WeakMap();

function updateScreenPrivacy(){
  const obscured=screenPrivacyEnabled&&(
    !windowFocused||document.visibilityState==="hidden"||printPreviewActive
  );
  document.body.classList.toggle("privacy-obscured",obscured);
}

function setStatus(message){readerStatus.textContent=message||"";}

function makeDirectoryPositionKey(pathSegments){
  return "directory\\u0000"+[bookshelfIndex?.rootName||"",...pathSegments].join("/");
}
async function readSavedPositionRecord(key){
  if(!rememberPositionInput.checked||!key)return null;
  try{await readingPositionWrite;return await loadReadingPosition(key);}catch{return null;}
}
async function getDefaultArchivePassword(){
  try{return await loadDefaultArchivePassword()||"";}
  catch{return "";}
}
async function persistPendingDefaultPassword(){
  if(typeof pendingDefaultPassword!=="string")return;
  const password=pendingDefaultPassword;
  pendingDefaultPassword=null;
  try{
    await saveDefaultArchivePassword(password);
    forgetDefaultPasswordButton.hidden=false;
    passwordStorageNote.textContent="既定パスワードはAES-GCMで暗号化して保存されます。同じChromeプロファイル内で動作するAquviからは復号できます。";
  }catch{
    forgetDefaultPasswordButton.hidden=true;
    passwordStorageNote.textContent="暗号化保存できませんでした。パスワードは今回の閲覧中のみ使用され、保存されていません。";
  }
}
async function refreshDefaultPasswordControl(){
  try{forgetDefaultPasswordButton.hidden=!(await hasSavedDefaultArchivePassword());}
  catch{forgetDefaultPasswordButton.hidden=true;}
}
async function clearDefaultArchivePassword(){
  pendingDefaultPassword=null;
  try{await deleteDefaultArchivePassword();}
  catch{/* Keep the viewer usable if local storage is unavailable. */}
  forgetDefaultPasswordButton.hidden=true;
}
function finishPasswordPrompt(password){
  const resolve=passwordPromptResolve;
  pendingDefaultPassword=password!==null&&rememberDefaultPasswordInput.checked?password:null;
  passwordPromptResolve=null;passwordPromptPromise=null;
  passwordInput.value="";
  if(passwordDialog.open)passwordDialog.close();
  if(resolve)resolve(password);
}
async function requestArchivePassword(retry=false){
  if(retry&&await getDefaultArchivePassword())await clearDefaultArchivePassword();
  if(passwordPromptPromise){
    if(retry)passwordMessage.textContent="パスワードが違うか、アーカイブが破損している可能性があります。もう一度入力してください。";
    return passwordPromptPromise;
  }
  passwordMessage.textContent=retry
    ?"パスワードが違うか、アーカイブが破損している可能性があります。もう一度入力してください。"
    :"このアーカイブを開くためのパスワードを入力してください。";
  passwordInput.value="";
  rememberDefaultPasswordInput.checked=false;
  void refreshDefaultPasswordControl();
  passwordPromptPromise=new Promise((resolve)=>{passwordPromptResolve=resolve;});
  passwordDialog.showModal();
  passwordInput.focus();
  return passwordPromptPromise;
}
function cancelPasswordPrompt(){
  if(passwordPromptPromise)finishPasswordPrompt(null);
}
forgetDefaultPasswordButton.addEventListener("click",()=>{void clearDefaultArchivePassword();});
passwordForm.addEventListener("submit",(event)=>{
  event.preventDefault();
  finishPasswordPrompt(passwordInput.value);
});
passwordCancel.addEventListener("click",()=>finishPasswordPrompt(null));
passwordDialog.addEventListener("cancel",(event)=>{
  event.preventDefault();
  finishPasswordPrompt(null);
});

function cacheArchiveCoverIfFirstPage(entry,data,password){
  const first=archive?.imageEntries?.[0];
  if(!first||first.name!==entry?.name||!archive?.file||!(data instanceof Uint8Array))return;
  const identity=thumbnailIdentity("archive",archive.file);
  void createAndCacheThumbnail(identity,new Blob([data],{type:mimeType(entry.name)}),password||"").catch(()=>{});
}
async function readEntryWithPassword(entry){
  // 7z accepts its password while the archive is opened. Keep using that
  // in-memory password for subsequent page reads instead of prompting again.
  let password=await getDefaultArchivePassword()||archive?.password||"";
  let hasPassword=Boolean(password);
  while(true){
    try{
      if(entry?.encrypted){
        if(!hasPassword){
          password=await requestArchivePassword(false);
          if(password===null){
            const cancelled=new Error("パスワード入力をキャンセルしました。");
            cancelled.code="PASSWORD_CANCELLED";
            throw cancelled;
          }
          hasPassword=true;
        }
        const cached=await readEncryptedPageCache(archive?.file,entry,password);
        if(cached){
          cacheArchiveCoverIfFirstPage(entry,cached,password);
          await persistPendingDefaultPassword();
          return cached;
        }
      }
      const data=hasPassword
        ?await archive.readEntry(entry,{password})
        :await archive.readEntry(entry);
      await persistPendingDefaultPassword();
      if(entry?.encrypted&&hasPassword&&archive?.file){
        void writeEncryptedPageCache(archive.file,entry,password,data).catch(()=>{});
      }
      cacheArchiveCoverIfFirstPage(entry,data,hasPassword?password:"");
      return data;
    }catch(error){
      if(error?.code!=="PASSWORD_REQUIRED"&&error?.code!=="BAD_PASSWORD")throw error;
      password=await requestArchivePassword(error.code==="BAD_PASSWORD");
      if(password===null){
        const cancelled=new Error("パスワード入力をキャンセルしました。");
        cancelled.code="PASSWORD_CANCELLED";
        throw cancelled;
      }
      hasPassword=true;
    }
  }
}
function mimeType(name){
  const ext=name.split(".").pop().toLowerCase();
  return ({jpg:"image/jpeg",jpeg:"image/jpeg",png:"image/png",gif:"image/gif",webp:"image/webp",avif:"image/avif",bmp:"image/bmp"})[ext]||"application/octet-stream";
}
function thumbnailIdentity(kind,file,path=""){
  return [kind,path,file.webkitRelativePath||"",file.name||"",file.size||0,file.lastModified||0].join("\\u001f");
}
function showBookshelfThumbnail(image,blob,token){
  if(token!==bookshelfRenderToken||!image.isConnected)return;
  const url=URL.createObjectURL(blob);
  bookshelfPreviewUrls.push(url);
  image.src=url;
}
function releaseUrls(){for(const url of objectUrls)URL.revokeObjectURL(url);objectUrls=[];}
function makePositionKey(file){
  return "archive\\u0000"+[file.name||"",file.size||0,file.lastModified||0].join("\\u0000");
}
async function loadSavedPositionFor(key,images){
  if(!rememberPositionInput.checked||!key)return null;
  try{
    await readingPositionWrite;
    const saved=await loadReadingPosition(key);
    const side=saved&&(saved.side==="left"||saved.side==="right")?saved.side:null;
    if(saved&&typeof saved.entryName==="string"){
      const index=images.findIndex((entry)=>entry.name===saved.entryName);
      if(index>=0)return {index,side};
    }
    if(saved&&Number.isInteger(saved.entryId)){
      const index=images.findIndex((entry)=>entry.id===saved.entryId);
      if(index>=0)return {index,side};
    }
    if(saved&&Number.isInteger(saved.index)&&saved.index>=0&&saved.index<images.length){
      return {index:saved.index,side};
    }
  }catch{/* Ignore unavailable or malformed encrypted position data. */}
  return null;
}
async function loadSavedPosition(){
  return loadSavedPositionFor(currentPositionKey,sourceImages);
}
function saveCurrentPosition(){
  if(!rememberPositionInput.checked||!currentPositionKey||currentImageIndex<0)return readingPositionWrite;
  const identity=currentPositionKey;
  const value={
    index:currentImageIndex,
    entryId:sourceImages[currentImageIndex]?.id??null,
    entryName:sourceImages[currentImageIndex]?.name??null,
    side:currentSide||null
  };
  readingPositionWrite=readingPositionWrite
    .catch(()=>{})
    .then(()=>saveReadingPosition(identity,value))
    .catch(()=>{});
  return readingPositionWrite;
}
async function clearSavedPositions(){
  try{
    await readingPositionWrite;
    await clearReadingPositions();
  }catch{/* Best-effort deletion of local reading history. */}
}

function updateToolbar(){
  modeSelect.value=mode;
  bookshelfToggle.classList.toggle("primary",bookshelfPanel.hidden);
  bookshelfToggle.setAttribute("aria-pressed",String(!bookshelfPanel.hidden));
  directionButton.textContent=direction==="rtl"?"右開き":"左開き";
  pageShiftButton.disabled=mode!=="pair";pageShiftButton.setAttribute("aria-pressed",String(pageShifted));
  pageShiftButton.classList.toggle("selected",pageShifted&&mode==="pair");
  pageShiftButton.title=pageShifted?"ページシフトを解除して元の組み合わせに戻す":"先頭を単独ページにして、見開きの組み合わせを1ページ分ずらす";
  workspace.classList.toggle("rtl",direction==="rtl");
  previousButton.textContent=direction==="rtl"?"›":"‹";nextButton.textContent=direction==="rtl"?"‹":"›";
  sidebarToggleIcon.textContent=sidebarVisible?"◀":"▶";
  sidebarButton.setAttribute("aria-pressed",String(sidebarVisible));
  sidebarButton.setAttribute("aria-label",sidebarVisible?"ファイル一覧を隠す":"ファイル一覧を表示");
  sidebarButton.title=sidebarVisible?"ファイル一覧を隠す":"ファイル一覧を表示";
  readingModeButton.disabled=pageViews.length===0;
}
function updateCounter(){pageCounter.textContent=pageViews.length?(currentViewIndex+1)+" / "+pageViews.length:"— / —";}
function updateSelection(){
  const view=pageViews[currentViewIndex],active=new Set(view?view.pages.map((page)=>page.index):[]);
  fileList.querySelectorAll(".file-row").forEach((button)=>{
    const selected=active.has(Number(button.dataset.index));button.classList.toggle("active",selected);
    if(selected)button.setAttribute("aria-current","page");else button.removeAttribute("aria-current");
  });
}
function updateFileListPager(){
  const pageCount=Math.max(1,Math.ceil(sourceImages.length/FILE_LIST_PAGE_SIZE));
  fileListPage=Math.max(0,Math.min(fileListPage,pageCount-1));
  const first=sourceImages.length?fileListPage*FILE_LIST_PAGE_SIZE+1:0;
  const last=Math.min((fileListPage+1)*FILE_LIST_PAGE_SIZE,sourceImages.length);
  fileListPageLabel.textContent=pageCount>1?(fileListPage+1)+" / "+pageCount:"1 / 1";
  fileListPageLabel.title=sourceImages.length?first+"–"+last+" / "+sourceImages.length:"0 files";
  fileListPrev.disabled=fileListPage===0;
  fileListNext.disabled=fileListPage>=pageCount-1;
}
function renderFileList(){
  fileList.replaceChildren();fileCount.textContent=String(sourceImages.length);
  const start=fileListPage*FILE_LIST_PAGE_SIZE;
  const end=Math.min(start+FILE_LIST_PAGE_SIZE,sourceImages.length);
  for(let index=start;index<end;index++){
    const entry=sourceImages[index];
    const button=document.createElement("button");button.className="file-row";button.type="button";
    button.dataset.index=String(index);button.textContent=entry.name;button.title=entry.name;
    const unavailable=archive.getEntryAvailability(entry);
    if(unavailable){button.disabled=true;button.title=entry.name+" — "+unavailable;}
    else button.addEventListener("click",()=>{
      const viewIndex=findViewIndexForImage(pageViews,index,direction==="rtl"?"right":"left");showView(viewIndex);
    });
    fileList.append(button);
  }
  updateFileListPager();updateSelection();
}
function rebuildViews(anchor=currentImageIndex,side=currentSide){
  loadToken++;loadingStatus.hidden=true;
  pageViews=buildPageViews(sourceImages,mode,pageShifted,direction);
  currentViewIndex=findViewIndexForImage(pageViews,anchor<0?0:anchor,side);
  const activePage=pageViews[currentViewIndex]?.pages[0]?.index??0;
  fileListPage=Math.floor(activePage/FILE_LIST_PAGE_SIZE);
  updateToolbar();updateCounter();renderFileList();
  if(pageViews.length)showView(currentViewIndex);
}
function fitSplit(frame,image,side){
  if(!image.naturalWidth||!image.naturalHeight)return;
  const availableHeight=Math.max(120,stage.clientHeight-28),availableWidth=Math.max(120,pageContent.clientWidth-28);
  const scale=Math.min(availableHeight/image.naturalHeight,availableWidth/(image.naturalWidth/2));
  const frameWidth=image.naturalWidth/2*scale,frameHeight=image.naturalHeight*scale;
  frame.style.width=frameWidth+"px";frame.style.height=frameHeight+"px";
  image.style.width=(image.naturalWidth*scale)+"px";image.style.height=frameHeight+"px";
  image.style.left=side==="right"?(-frameWidth)+"px":"0px";
}
function fitCurrentLayout(){
  const frame=pageContent.querySelector(".split-crop"),image=frame&&frame.querySelector("img");
  if(frame&&image)fitSplit(frame,image,currentSide);
}

function seriesContextFor(item){
  if(!item||!Number.isInteger(item.seriesIndex)||!Array.isArray(item.seriesPath))return null;
  return {path:item.seriesPath.slice(),index:item.seriesIndex};
}
function getSeriesVolumes(context=bookshelfSeriesContext){
  if(!context||!bookshelfIndex)return [];
  if(bookshelfIndex.directoryMode){
    const node=getDirectoryBookshelfNode(bookshelfIndex,context.path);
    return (node?.items||[]).filter((item)=>item.kind==="book"||item.kind==="archiveBook");
  }
  const path=[bookshelfIndex.rootName,...context.path];
  return listBookshelfItems(bookshelfIndex,path)
    .filter((item)=>item.kind==="book"||item.kind==="archiveBook");
}
function hasSeriesNeighbor(delta){
  if(!bookshelfSeriesContext)return false;
  const volumes=getSeriesVolumes();
  return bookshelfSeriesContext.index+delta>=0&&bookshelfSeriesContext.index+delta<volumes.length;
}
function updateNavigationButtons(){
  previousButton.disabled=currentViewIndex===0&&!hasSeriesNeighbor(-1);
  nextButton.disabled=currentViewIndex===pageViews.length-1&&!hasSeriesNeighbor(1);
}
async function openAdjacentVolume(delta){
  const context=bookshelfSeriesContext;
  const volumes=getSeriesVolumes(context);
  const nextIndex=(context?.index??-1)+delta;
  if(nextIndex<0||nextIndex>=volumes.length)return false;
  const volume=volumes[nextIndex];
  const nextContext={path:context.path.slice(),index:nextIndex};
  if(volume.kind==="book"){
    await openFolderBook(volume,delta<0?-1:0,nextContext);
  }else{
    await openArchiveItem(volume,delta<0?-1:0,nextContext);
  }
  return true;
}

async function showView(index){
  if(!archive||!pageViews.length)return;
  if(index<0){
    if(await openAdjacentVolume(-1))return;
    return;
  }
  if(index>=pageViews.length){
    if(await openAdjacentVolume(1))return;
    return;
  }
  const token=++loadToken,view=pageViews[index];currentViewIndex=index;
  const anchor=view.pages[0];currentImageIndex=anchor.index;currentSide=anchor.side||null;
  const targetListPage=Math.floor(currentImageIndex/FILE_LIST_PAGE_SIZE);
  if(targetListPage!==fileListPage){fileListPage=targetListPage;renderFileList();fileList.scrollTop=0;}
  else updateSelection();
  previousButton.disabled=true;nextButton.disabled=true;loadingStatus.textContent="読み込み中…";loadingStatus.hidden=false;
  setStatus("");updateCounter();
  const newUrls=[];
  try{
    const loadResults=await Promise.allSettled(view.pages.map(async(page)=>{
      const data=await readEntryWithPassword(page.entry);
      const url=URL.createObjectURL(new Blob([data],{type:mimeType(page.entry.name)}));
      newUrls.push(url);return {page,url};
    }));
    const failedLoad=loadResults.find((result)=>result.status==="rejected");
    if(failedLoad)throw failedLoad.reason;
    const loaded=loadResults.map((result)=>result.value);
    if(token!==loadToken){newUrls.forEach((url)=>URL.revokeObjectURL(url));return;}
    pageContent.replaceChildren();pageContent.className="page-content "+view.kind;
    const ordered=view.kind==="pair"&&direction==="rtl"?loaded.slice().reverse():loaded;

    if(view.kind==="split"){
      const item=ordered[0],crop=document.createElement("div"),image=document.createElement("img");
      crop.className="split-crop";image.alt=item.page.entry.name+" ("+item.page.side+" half)";
      image.draggable=false;
      image.onload=()=>{if(token===loadToken)fitSplit(crop,image,item.page.side);};
      image.onerror=()=>{if(token===loadToken)setStatus("画像を表示できませんでした: "+item.page.entry.name);};
      crop.append(image);pageContent.append(crop);image.src=item.url;
    }else{
      ordered.forEach((item,indexInView)=>{
        const frame=document.createElement("div"),image=document.createElement("img");
        frame.className="page-frame";
        if(view.kind==="pair")frame.classList.add(indexInView===0?"pair-left":"pair-right");
        image.className="reader-image";image.alt=item.page.entry.name;image.draggable=false;
        image.onerror=()=>{if(token===loadToken)setStatus("画像を表示できませんでした: "+item.page.entry.name);};
        frame.append(image);pageContent.append(frame);image.src=item.url;
      });
    }
    releaseUrls();objectUrls=newUrls;
    pageCaption.textContent=view.pages.map((page)=>page.entry.name).join("　／　");
    updateNavigationButtons();setStatus("");
    const active=fileList.querySelector(".file-row.active");if(active)active.scrollIntoView({block:"nearest"});
    void saveCurrentPosition();
  }catch(error){
    newUrls.forEach((url)=>URL.revokeObjectURL(url));
    if(token===loadToken){
      pageContent.replaceChildren();
      setStatus(error?.code==="PASSWORD_CANCELLED"?"パスワード入力をキャンセルしました。":(error&&error.message?error.message:"画像を開けませんでした。"));
    }
  }finally{
    if(token===loadToken){
      loadingStatus.hidden=true;
      updateNavigationButtons();
    }
  }
}
function releaseBookshelfPreviews(){
  bookshelfRenderToken++;
  archivePreviewQueue=[];
  archivePreviewObserver?.disconnect();
  archivePreviewObserver=null;
  bookshelfImagePreviewObserver?.disconnect();
  bookshelfImagePreviewObserver=null;
  for(const url of bookshelfPreviewUrls)URL.revokeObjectURL(url);
  bookshelfPreviewUrls=[];
}
function makeBookshelfThumbnail(file,className){
  const image=document.createElement("img");
  image.className=className;
  image.alt="";
  image.loading="lazy";
  const token=bookshelfRenderToken;
  const identity=thumbnailIdentity("folder-image",file);
  bookshelfImagePreviewTargets.set(image,{file,identity,token});
  return image;
}
function makeDirectoryBookshelfThumbnail(handle,className,path){
  const image=document.createElement("img");
  image.className=className;
  image.alt="";
  image.loading="lazy";
  bookshelfImagePreviewTargets.set(image,{handle,path,token:bookshelfRenderToken});
  return image;
}
function makeRememberedDirectoryThumbnail(directoryHandle,entryName,className,path){
  const image=document.createElement("img");
  image.className=className;
  image.alt="";
  image.loading="lazy";
  bookshelfImagePreviewTargets.set(image,{directoryHandle,entryName,path,token:bookshelfRenderToken});
  return image;
}
async function loadBookshelfThumbnail(image){
  const target=bookshelfImagePreviewTargets.get(image);
  if(!target||target.token!==bookshelfRenderToken||!image.isConnected)return;
  try{
    let file=target.file||null;
    if(target.handle)file=await target.handle.getFile();
    if(target.directoryHandle&&target.entryName){
      const handle=await target.directoryHandle.getFileHandle(target.entryName);
      file=await handle.getFile();
    }
    if(!file)return;
    const cachePath=[bookshelfIndex?.rootName||"",target.path||""].filter(Boolean).join("/");
    const identity=target.identity||thumbnailIdentity("folder-image",file,cachePath);
    const blob=await createAndCacheThumbnail(identity,file);
    showBookshelfThumbnail(image,blob,target.token);
  }catch{
    // A missing remembered-page thumbnail is non-fatal.
  }
}
function observeBookshelfThumbnails(){
  bookshelfImagePreviewObserver?.disconnect();
  bookshelfImagePreviewObserver=null;
  const images=bookshelfGrid.querySelectorAll(".bookshelf-cover-image,.bookshelf-last-page-image");
  if(!images.length)return;
  if(typeof IntersectionObserver!=="function"){
    images.forEach((image)=>loadBookshelfThumbnail(image));
    return;
  }
  bookshelfImagePreviewObserver=new IntersectionObserver((entries)=>{
    for(const entry of entries){
      if(!entry.isIntersecting)continue;
      bookshelfImagePreviewObserver.unobserve(entry.target);
      loadBookshelfThumbnail(entry.target);
    }
  },{root:bookshelfGrid,rootMargin:"140px"});
  images.forEach((image)=>bookshelfImagePreviewObserver.observe(image));
}
function makeArchiveBlobThumbnail(blob,className){
  const image=document.createElement("img");
  image.className=className;
  image.alt="";
  image.loading="lazy";
  const url=URL.createObjectURL(blob);
  bookshelfPreviewUrls.push(url);
  image.src=url;
  return image;
}
function makeArchivePlaceholder(){
  const placeholder=document.createElement("span");
  placeholder.className="bookshelf-archive-placeholder";
  placeholder.setAttribute("aria-label","パスワード保護または表紙未読込");
  const lock=document.createElement("span");
  lock.className="bookshelf-lock-symbol";
  lock.textContent="🔒";
  lock.setAttribute("aria-hidden","true");
  const label=document.createElement("span");
  label.className="bookshelf-archive-placeholder-label";
  label.textContent="書庫";
  placeholder.append(lock,label);
  return placeholder;
}
function queueArchivePreview(item,cover,token){
  archivePreviewQueue.push({item,cover,token});
  drainArchivePreviewQueue();
}
async function drainArchivePreviewQueue(){
  if(archivePreviewBusy)return;
  const job=archivePreviewQueue.shift();
  if(!job)return;
  if(job.token!==bookshelfRenderToken||!job.cover.isConnected){
    drainArchivePreviewQueue();
    return;
  }
  archivePreviewBusy=true;
  let opened=null;
  try{
    const archiveFile=job.item.file||await getDirectoryFile(job.item.handle);
    const cacheIdentity=thumbnailIdentity("archive",archiveFile);
    const password=await getDefaultArchivePassword();
    // The cache key is an HMAC of the archive identity and exact password scope.
    // A hit therefore reuses only the preview created for this archive/password
    // pair, without reopening the archive or decrypting its first image.
    const cached=await getCachedThumbnail(cacheIdentity,password);
    if(cached){
      if(job.token===bookshelfRenderToken&&job.cover.isConnected){
        job.cover.replaceChildren(makeArchiveBlobThumbnail(cached,"bookshelf-cover-image"));
      }
      return;
    }
    const {openArchiveFile}=await import("../src/archive/archive-loader.mjs");
    opened=await openArchiveFile(archiveFile,{
      password:password||undefined,
      requestPassword:async()=>null
    });
    const entry=opened.imageEntries[0];
    if(!entry)throw new Error("表紙に使える画像がありません。");
    const data=await opened.readEntry(entry,password?{password}:{});
    const thumbnail=await createAndCacheThumbnail(cacheIdentity,new Blob([data],{type:mimeType(entry.name)}),password);
    if(job.token===bookshelfRenderToken&&job.cover.isConnected){
      job.cover.replaceChildren(makeArchiveBlobThumbnail(thumbnail,"bookshelf-cover-image"));
    }
  }catch(error){
    if(job.token===bookshelfRenderToken&&job.cover.isConnected){
      const placeholder=makeArchivePlaceholder();
      if(error?.code==="PASSWORD_REQUIRED"||error?.code==="BAD_PASSWORD"||error?.code==="PASSWORD_CANCELLED"){
        placeholder.classList.add("is-locked");
        placeholder.querySelector(".bookshelf-archive-placeholder-label").textContent="鍵付き";
      }else{
        placeholder.querySelector(".bookshelf-archive-placeholder-label").textContent="表紙なし";
      }
      job.cover.replaceChildren(placeholder);
    }
  }finally{
    try{await opened?.close?.();}catch{/* Best-effort release of the preview reader. */}
    archivePreviewBusy=false;
    drainArchivePreviewQueue();
  }
}
function observeArchivePreviews(){
  archivePreviewObserver?.disconnect();
  archivePreviewObserver=null;
  const covers=bookshelfGrid.querySelectorAll(".bookshelf-archive-cover");
  if(!covers.length)return;
  if(typeof IntersectionObserver!=="function"){
    for(const cover of covers){
      const item=archivePreviewTargets.get(cover);
      if(item)queueArchivePreview(item,cover,bookshelfRenderToken);
    }
    return;
  }
  archivePreviewObserver=new IntersectionObserver((entries)=>{
    for(const entry of entries){
      if(!entry.isIntersecting)continue;
      archivePreviewObserver.unobserve(entry.target);
      const item=archivePreviewTargets.get(entry.target);
      if(item)queueArchivePreview(item,entry.target,bookshelfRenderToken);
    }
  },{root:bookshelfGrid,rootMargin:"140px"});
  covers.forEach((cover)=>archivePreviewObserver.observe(cover));
}
function makeBookshelfBreadcrumb(){
  bookshelfBreadcrumb.replaceChildren();
  if(!bookshelfIndex)return;
  const segments=[bookshelfIndex.rootName,...bookshelfPath];
  segments.forEach((segment,index)=>{
    if(index>0){
      const separator=document.createElement("span");
      separator.className="bookshelf-breadcrumb-separator";
      separator.textContent="›";
      bookshelfBreadcrumb.append(separator);
    }
    const button=document.createElement("button");
    button.type="button";
    button.className="bookshelf-crumb";
    button.textContent=segment;
    button.disabled=index===segments.length-1;
    button.addEventListener("click",()=>{
      bookshelfPath=bookshelfPath.slice(0,Math.max(0,index));
      renderBookshelf();
    });
    bookshelfBreadcrumb.append(button);
  });
  bookshelfUp.disabled=bookshelfPath.length===0;
}
async function makeBookshelfCard(item){
  const card=document.createElement("button");
  card.type="button";
  card.className="bookshelf-card "+(item.kind==="folder"?"folder-card":"book-card");
  if(item.kind==="archiveBook")card.classList.add("archive-book-card");
  if(item.kind==="folder"){
    const art=document.createElement("span");
    art.className="bookshelf-folder-art";
    art.setAttribute("aria-hidden","true");
    art.textContent="📁";
    const title=document.createElement("span");
    title.className="bookshelf-card-title";
    title.textContent=item.name;
    const subtitle=document.createElement("span");
    subtitle.className="bookshelf-card-subtitle";
    subtitle.textContent="フォルダ";
    card.append(art,title,subtitle);
    card.addEventListener("click",()=>{
      if(item.handle)navigateDirectoryFolder(item);
      else{
        bookshelfPath=item.folder.path.slice(1);
        renderBookshelf();
      }
    });
    return card;
  }

  const cover=document.createElement("span");
  cover.className="bookshelf-cover";
  if(item.kind==="archiveBook"){
    cover.classList.add("bookshelf-archive-cover");
    cover.append(makeArchivePlaceholder());
    archivePreviewTargets.set(cover,item);
    const title=document.createElement("span");
    title.className="bookshelf-card-title";
    title.textContent=item.name;
    const subtitle=document.createElement("span");
    subtitle.className="bookshelf-card-subtitle";
    subtitle.textContent=item.format.toUpperCase()+" アーカイブ";
    card.append(cover,title,subtitle);
    card.addEventListener("click",()=>openArchiveItem(item,null,seriesContextFor(item)));
    return card;
  }

  const identityKey=item.handle?makeDirectoryPositionKey(item.pathSegments||[]):(item.positionKey||makePositionKey(item.identity));
  if(item.firstImageHandle){
    cover.append(makeDirectoryBookshelfThumbnail(item.firstImageHandle,"bookshelf-cover-image",item.path||""));
  }else{
    const first=item.files?.[0];
    if(first)cover.append(makeBookshelfThumbnail(first,"bookshelf-cover-image"));
  }
  const savedRecord=await readSavedPositionRecord(identityKey);
  if(item.handle&&savedRecord?.entryName){
    const last=document.createElement("span");
    last.className="bookshelf-last-page";
    last.append(makeRememberedDirectoryThumbnail(item.handle,savedRecord.entryName,"bookshelf-last-page-image",item.path||""));
    last.title="最後に開いたページ";
    cover.append(last);
  }else{
    const saved=await loadSavedPositionFor(identityKey,item.files||[]);
    if(saved&&item.files?.[saved.index]){
      const last=document.createElement("span");
      last.className="bookshelf-last-page";
      last.append(makeBookshelfThumbnail(item.files[saved.index],"bookshelf-last-page-image"));
      last.title="最後に開いたページ";
      cover.append(last);
    }
  }
  const title=document.createElement("span");
  title.className="bookshelf-card-title";
  title.textContent=item.name;
  const subtitle=document.createElement("span");
  subtitle.className="bookshelf-card-subtitle";
  subtitle.textContent=(item.imageCount??item.files?.length??0)+" 枚";
  card.append(cover,title,subtitle);
  card.addEventListener("click",()=>openFolderBook(item,null,seriesContextFor(item)));
  return card;
}
async function renderBookshelf(){
  releaseBookshelfPreviews();
  const renderToken=bookshelfRenderToken;
  bookshelfGrid.replaceChildren();
  if(!bookshelfIndex){
    bookshelfRootName.textContent="フォルダ未選択";
    bookshelfCount.textContent="";
    bookshelfBreadcrumb.replaceChildren();
    bookshelfUp.disabled=true;
    bookshelfStatus.textContent="本棚フォルダを選択してスキャンしてください。";
    return;
  }
  const fullPath=[bookshelfIndex.rootName,...bookshelfPath];
  const node=bookshelfIndex.directoryMode
    ?getDirectoryBookshelfNode(bookshelfIndex,bookshelfPath)
    :getBookshelfNode(bookshelfIndex,fullPath);
  bookshelfRootName.textContent=bookshelfIndex.rootName;
  makeBookshelfBreadcrumb();
  if(!node){
    bookshelfStatus.textContent="この場所を読み込めませんでした。";
    return;
  }
  const items=bookshelfIndex.directoryMode?node.items:listBookshelfItems(bookshelfIndex,fullPath);
  const cards=await Promise.all(items.map((item)=>makeBookshelfCard(item)));
  if(renderToken!==bookshelfRenderToken)return;
  cards.forEach((card)=>bookshelfGrid.append(card));
  observeBookshelfThumbnails();
  observeArchivePreviews();
  const folders=items.filter((item)=>item.kind==="folder").length;
  const books=items.filter((item)=>item.kind==="book"||item.kind==="archiveBook").length;
  bookshelfCount.textContent=folders+" フォルダ・"+books+" 冊";
  bookshelfStatus.textContent=items.length
    ?"フォルダは中へ移動し、画像フォルダは表紙付きの本として表示します。書庫の表紙は必要なときに一件ずつ読み込みます。"
    :"この場所に表示できる本やフォルダはありません。";
}
function setBookshelfPanelVisible(visible){
  bookshelfPanel.hidden=!visible;
  bookshelfToggle.setAttribute("aria-expanded",String(visible));
  bookshelfToggle.setAttribute("aria-pressed",String(visible));
  bookshelfToggle.classList.toggle("primary",!visible);
  if(visible)renderBookshelf();
  else releaseBookshelfPreviews();
}
async function scanBookshelfHandle(handle, persist=true){
  try{
    if(persist&&rememberBookshelf){ await saveBookshelfHandle(handle); savedBookshelfHandle=handle; }
    releaseBookshelfPreviews();
    bookshelfSeriesContext=null;
    bookshelfStatus.textContent="フォルダの内容を確認しています…";
    const permission=await handle.queryPermission?.({mode:"read"});
    if(permission==="denied")throw new Error("フォルダの読み取りが許可されていません。もう一度選択してください。");
    if(permission!=="granted"&&typeof handle.requestPermission==="function"){
      const requested=await handle.requestPermission({mode:"read"});
      if(requested!=="granted")throw new Error("フォルダの読み取りが許可されませんでした。");
    }
    const index=await buildDirectoryBookshelf(handle,{
      onProgress:(progress)=>{
        if(progress.phase==="checking-child-folders"){
          bookshelfStatus.textContent="直下のフォルダを確認しています… "+(progress.checkedFolders||0)+"/"+(progress.childFolders||0);
          if(progress.childScanned)bookshelfStatus.textContent+="（"+progress.currentChild+"："+progress.childScanned.toLocaleString()+"項目）";
        }else{
          bookshelfStatus.textContent="フォルダを確認しています… "+(progress.scanned||0).toLocaleString()+"項目";
        }
      }
    });
    bookshelfIndex=index;
    bookshelfPath=[];
    setBookshelfPanelVisible(true);
    bookshelfStatus.textContent=index.root.scannedEntries.toLocaleString()+" 個の直下項目を確認しました。";
    renderBookshelf();
  }catch(error){
    if(error?.name==="AbortError")return;
    bookshelfIndex=null;
    bookshelfPath=[];
    setBookshelfPanelVisible(true);
    bookshelfStatus.textContent=error?.message||"本棚フォルダを読み込めませんでした。";
  }
}
async function navigateDirectoryFolder(item){
  if(!item?.handle||!bookshelfIndex?.directoryMode)return;
  const path=item.pathSegments||[];
  const key=path.join("/");
  let node=getDirectoryBookshelfNode(bookshelfIndex,path);
  if(!node){
    bookshelfStatus.textContent=item.name+" の内容を確認しています…";
    try{
      node=await scanDirectoryLevel(item.handle,path,{
        onProgress:(progress)=>{
          bookshelfStatus.textContent=item.name+" を確認しています… "+(progress.scanned||progress.childScanned||0).toLocaleString()+"項目";
        }
      });
      bookshelfIndex.nodes.set(key,node);
    }catch(error){
      bookshelfStatus.textContent=error?.message||"フォルダを読み込めませんでした。";
      return;
    }
  }
  bookshelfPath=path.slice();
  renderBookshelf();
}
async function restoreSavedBookshelf(){
  try{
    if(!rememberBookshelf){await forgetBookshelfHandle();savedBookshelfHandle=null;return;}
    const handle=await getSavedBookshelfHandle();
    savedBookshelfHandle=handle;
    if(!handle)return;
    const permission=await getBookshelfPermission(handle);
    if(permission==="granted"){
      await scanBookshelfHandle(handle,false);
    }else{
      setBookshelfPanelVisible(true);
      bookshelfStatus.textContent="前回の本棚を記憶しています。「本棚を開く」を押すとアクセスを再許可できます。";
    }
  }catch(error){
    setBookshelfPanelVisible(true);
    bookshelfStatus.textContent=error?.message||"前回の本棚を復元できませんでした。";
  }
}
function openBookshelfPickerFromGesture(){
  try{
    if(savedBookshelfHandle){
      const permissionPromise=requestBookshelfPermission(savedBookshelfHandle);
      permissionPromise.then(async(granted)=>{
        if(granted==="granted"){await scanBookshelfHandle(savedBookshelfHandle,false);return;}
        bookshelfStatus.textContent="前回の本棚へのアクセスが許可されませんでした。本棚へのアクセスが許可されませんでした。もう一度フォルダを選択してください。";
      }).catch((error)=>{
        bookshelfStatus.textContent=error?.message||"前回の本棚にアクセスできませんでした。本棚へのアクセスに失敗しました。フォルダを選び直してください。";
      });
      return;
    }
    if(typeof window.showDirectoryPicker==="function"){
      window.showDirectoryPicker({mode:"read"}).then((handle)=>scanBookshelfHandle(handle,true)).catch((error)=>{
        if(error?.name!=="AbortError")bookshelfStatus.textContent=error?.message||"本棚フォルダを開けませんでした。";
      });
      return;
    }
    $("bookshelf-folder").click();
  }catch(error){
    setBookshelfPanelVisible(true);
    bookshelfStatus.textContent=error?.message||"本棚フォルダを開けませんでした。";
  }
}
window.__aquviOpenBookshelfPicker=openBookshelfPickerFromGesture;
function scanBookshelf(files){
  try{
    releaseBookshelfPreviews();
    bookshelfSeriesContext=null;
    bookshelfIndex=buildBookshelfIndex(files);
    bookshelfPath=[];
    setBookshelfPanelVisible(true);
    bookshelfStatus.textContent=bookshelfIndex.fileCount+" 個のファイルをスキャンしました。";
    renderBookshelf();
  }catch(error){
    bookshelfIndex=null;
    bookshelfPath=[];
    setBookshelfPanelVisible(true);
    bookshelfStatus.textContent=error?.message||"本棚フォルダを読み込めませんでした。";
  }
}
async function openFolderBook(book,requestedStartIndex=null,series=null){
  if(!book?.files?.length&&!book?.handle)return;
  bookshelfSeriesContext=series;
  cancelPasswordPrompt();
  setBookshelfPanelVisible(false);
  const openToken=++loadToken;
  loadingStatus.hidden=true;
  releaseUrls();
  const previousArchive=archive;
  archive=null;
  try{await previousArchive?.close();}catch{/* Continue opening the selected folder book. */}
  if(openToken!==loadToken)return;

  currentPositionKey=book.handle?makeDirectoryPositionKey(book.pathSegments||[]):(book.positionKey||makePositionKey(book.identity));
  sourceImages=[];pageViews=[];currentImageIndex=-1;currentSide=null;fileListPage=0;
  pageContent.replaceChildren();fileList.replaceChildren();setStatus("フォルダ内の画像を準備しています…");
  archiveName.textContent=book.name;emptyState.hidden=true;stage.hidden=false;
  try{
    const files=book.files||await readDirectoryBookImages(book.handle,{
      onProgress:(progress)=>setStatus("画像一覧を確認しています… "+progress.scanned.toLocaleString()+"枚")
    });
    if(openToken!==loadToken)return;
    const opened=createFolderArchive(files,book.name,book.path);
    if(openToken!==loadToken){await opened.close();return;}
    archive=opened;
    sourceImages=opened.imageEntries;
    if(!sourceImages.length){
      updateCounter();
      setStatus("このフォルダ直下に対応する画像がありません。");
      return;
    }
    const saved=await loadSavedPosition();
    const startIndex=requestedStartIndex===-1?sourceImages.length-1:Number.isInteger(requestedStartIndex)?Math.max(0,Math.min(requestedStartIndex,sourceImages.length-1)):(saved&&saved.index<sourceImages.length?saved.index:0);
    rebuildViews(startIndex,requestedStartIndex===null?(saved?.side||(direction==="rtl"?"right":"left")):(direction==="rtl"?"right":"left"));
    setStatus(sourceImages.length+" 枚の画像");
  }catch(error){
    if(openToken!==loadToken)return;
    try{await archive?.close();}catch{/* Best-effort cleanup after a failed folder open. */}
    archive=null;stage.hidden=true;emptyState.hidden=false;
    setStatus(error?.message||"フォルダを開けませんでした。");
  }
}
settingsOpen.addEventListener("click",()=>{settingsDialog.showModal();void refreshSettings();});
settingsClose.addEventListener("click",()=>settingsDialog.close());
settingsDialog.addEventListener("click",(event)=>{if(event.target===settingsDialog)settingsDialog.close();});
rememberBookshelfInput.checked=rememberBookshelf;
rememberBookshelfInput.addEventListener("change",async()=>{
  rememberBookshelf=rememberBookshelfInput.checked;
  try{localStorage.setItem(REMEMBER_BOOKSHELF_KEY,String(rememberBookshelf));}catch{}
  if(!rememberBookshelf){
    try{await forgetBookshelfHandle();}catch(error){bookshelfStatus.textContent=error?.message||"本棚の記憶を削除できませんでした。";}
    savedBookshelfHandle=null;
  }else if(bookshelfIndex?.directoryMode&&bookshelfIndex.root?.handle){
    try{await saveBookshelfHandle(bookshelfIndex.root.handle);savedBookshelfHandle=bookshelfIndex.root.handle;}catch(error){bookshelfStatus.textContent=error?.message||"本棚を記憶できませんでした。";}
  }
});
async function refreshSettings(){
  try{
    const [stats,thumbnails]=await Promise.all([getEncryptedPageCacheStats(),getCachedThumbnailStats()]);
    const gb=stats.limitBytes/1024**3;
    cacheLimitSelect.value=String([2,4,6,8].includes(gb)?gb:2);
    cacheUsageLabel.textContent="ページ "+(stats.usedBytes/1024**3).toFixed(2)+" GB / "+gb+" GB（"+stats.count.toLocaleString()+" 件）・サムネイル "+(thumbnails.usedBytes/1024**2).toFixed(1)+" MB（"+thumbnails.count.toLocaleString()+" 件）";
  }catch{cacheUsageLabel.textContent="キャッシュ情報を取得できませんでした。";}
}
cacheLimitSelect.addEventListener("change",async()=>{
  try{await setEncryptedPageCacheLimit(Number(cacheLimitSelect.value));try{localStorage.setItem(CACHE_LIMIT_KEY,cacheLimitSelect.value);}catch{}await refreshSettings();}
  catch(error){cacheUsageLabel.textContent=error?.message||"容量を変更できませんでした。";}
});
cacheClearButton.addEventListener("click",async()=>{
  if(!window.confirm("暗号化されたページキャッシュと本棚のサムネイルをすべて削除します。よろしいですか？"))return;
  cacheClearButton.disabled=true;
  try{await clearEncryptedPageCache();await clearCachedThumbnails();await refreshSettings();cacheUsageLabel.textContent+=" — 消去しました";}
  catch(error){cacheUsageLabel.textContent=error?.message||"キャッシュを消去できませんでした。";}
  finally{cacheClearButton.disabled=false;}
});
void (async()=>{try{const saved=localStorage.getItem(CACHE_LIMIT_KEY);if(saved&&[2,4,6,8].includes(Number(saved)))await setEncryptedPageCacheLimit(Number(saved));}catch{} })();
bookshelfToggle.addEventListener("click",()=>setBookshelfPanelVisible(bookshelfPanel.hidden));
bookshelfClose.addEventListener("click",()=>setBookshelfPanelVisible(false));
bookshelfUp.addEventListener("click",()=>{
  if(bookshelfPath.length){bookshelfPath.pop();renderBookshelf();}
});
window.addEventListener("aquvi:bookshelf-selected",(event)=>{
  const files=event.detail?.files;
  if(files?.length)scanBookshelf(files);
});
window.addEventListener("aquvi:bookshelf-forget",()=>{void forgetBookshelfHandle().then(()=>{bookshelfIndex=null;bookshelfPath=[];renderBookshelf();});});
window.addEventListener("aquvi:bookshelf-directory-selected",(event)=>{
  const handle=event.detail?.handle;
  if(handle)scanBookshelfHandle(handle);
});
window.addEventListener("aquvi:bookshelf-directory-error",(event)=>{
  const error=event.detail?.error;
  bookshelfStatus.textContent=error?.name==="AbortError"
    ?"フォルダ選択がキャンセルされたか、Chromeが選択を完了できませんでした。もう一度お試しください。"
    :(error?.message||"フォルダを選択できませんでした。");
});
async function openArchiveItem(item,requestedStartIndex=null,series=null){
  if(!item)return;
  const file=item.file||await getDirectoryFile(item.handle);
  return openArchive(file,requestedStartIndex,series);
}
async function openArchive(file,requestedStartIndex=null,series=null){
  if(!file)return;
  bookshelfSeriesContext=series;
  setBookshelfPanelVisible(false);
  cancelPasswordPrompt();
  const openToken=++loadToken;
  loadingStatus.hidden=true;
  releaseUrls();
  const previousArchive=archive;
  archive=null;
  try{await previousArchive?.close();}catch{/* Continue opening the newly selected archive. */}
  if(openToken!==loadToken)return;

  currentPositionKey=makePositionKey(file);
  sourceImages=[];pageViews=[];currentImageIndex=-1;currentSide=null;fileListPage=0;
  pageContent.replaceChildren();fileList.replaceChildren();setStatus("アーカイブ形式を確認しています…");
  archiveName.textContent=file.name;emptyState.hidden=true;stage.hidden=false;
  try{
    const { openArchiveFile }=await import("../src/archive/archive-loader.mjs");
    const opened=await openArchiveFile(file,{password:(await getDefaultArchivePassword())||undefined,requestPassword:requestArchivePassword});
    if(openToken!==loadToken){await opened.close?.();return;}
    archive=opened;
    await persistPendingDefaultPassword();
    if(openToken!==loadToken)return;
    sourceImages=archive.imageEntries;renderFileList();
    if(!sourceImages.length){updateCounter();setStatus("対応している画像ファイルが見つかりませんでした。");return;}
    const saved=await loadSavedPosition();
    const startIndex=requestedStartIndex===-1?sourceImages.length-1:Number.isInteger(requestedStartIndex)?Math.max(0,Math.min(requestedStartIndex,sourceImages.length-1)):(saved&&saved.index<sourceImages.length?saved.index:0);
    rebuildViews(startIndex,requestedStartIndex===null?(saved?.side||(direction==="rtl"?"right":"left")):(direction==="rtl"?"right":"left"));
    setStatus(sourceImages.length+" 枚の画像");
  }catch(error){
    if(openToken!==loadToken)return;
    try{await archive?.close();}catch{/* Best-effort cleanup after a failed open. */}
    archive=null;stage.hidden=true;emptyState.hidden=false;
    setStatus(error?.code==="PASSWORD_CANCELLED"?"パスワード入力をキャンセルしました。":(error&&error.message?error.message:"アーカイブを開けませんでした。"));
  }
}
function setReadingMode(active){
  readingMode=active;
  if(!active)readingFullscreenSize=null;
  appShell.classList.toggle("reading-mode",active);
  window.requestAnimationFrame(fitCurrentLayout);
}
function captureReadingFullscreenSize(){
  readingFullscreenSize={
    innerWidth:window.innerWidth,innerHeight:window.innerHeight,
    outerWidth:window.outerWidth,outerHeight:window.outerHeight
  };
}
function rememberReadingFullscreenSize(){
  window.requestAnimationFrame(()=>window.requestAnimationFrame(()=>{
    if(readingMode&&document.fullscreenElement===appShell)captureReadingFullscreenSize();
  }));
}
function windowHasLeftReadingFullscreen(){
  if(!readingFullscreenSize)return false;
  const threshold=64;
  return window.innerWidth<readingFullscreenSize.innerWidth-threshold ||
    window.innerHeight<readingFullscreenSize.innerHeight-threshold ||
    window.outerWidth<readingFullscreenSize.outerWidth-threshold ||
    window.outerHeight<readingFullscreenSize.outerHeight-threshold;
}
async function toggleReadingMode(){
  if(!pageViews.length)return;
  if(readingMode){
    if(document.fullscreenElement===appShell){
      try{await document.exitFullscreen();}catch{/* CSS mode is still cleared below. */}
    }
    setReadingMode(false);
    return;
  }
  setReadingMode(true);
  if(typeof appShell.requestFullscreen==="function"){
    try{
      await appShell.requestFullscreen();
      if(document.fullscreenElement===appShell)rememberReadingFullscreenSize();
    }catch{/* Keep the in-tab image-only layout. */}
  }
}
function toggleSidebar(){
  sidebarVisible=!sidebarVisible;workspace.classList.toggle("sidebar-hidden",!sidebarVisible);
  localStorage.setItem("aquvi.sidebarVisible",String(sidebarVisible));updateToolbar();
  window.requestAnimationFrame(fitCurrentLayout);
}
sidebarButton.addEventListener("click",toggleSidebar);
fileListPrev.addEventListener("click",()=>{
  if(fileListPage>0){fileListPage--;renderFileList();fileList.scrollTop=0;}
});
fileListNext.addEventListener("click",()=>{
  if(fileListPage<Math.ceil(sourceImages.length/FILE_LIST_PAGE_SIZE)-1){fileListPage++;renderFileList();fileList.scrollTop=0;}
});
rememberPositionInput.checked=localStorage.getItem("aquvi.rememberPosition")==="true";
screenPrivacyInput.checked=screenPrivacyEnabled;
screenPrivacyInput.addEventListener("change",()=>{
  screenPrivacyEnabled=screenPrivacyInput.checked;
  localStorage.setItem("aquvi.screenPrivacy",String(screenPrivacyEnabled));
  updateScreenPrivacy();
});
window.addEventListener("blur",()=>{windowFocused=false;updateScreenPrivacy();});
window.addEventListener("focus",()=>{windowFocused=true;updateScreenPrivacy();});
document.addEventListener("visibilitychange",updateScreenPrivacy);
window.addEventListener("beforeprint",()=>{printPreviewActive=true;updateScreenPrivacy();});
window.addEventListener("afterprint",()=>{printPreviewActive=false;updateScreenPrivacy();});
appShell.addEventListener("contextmenu",(event)=>{
  if(screenPrivacyEnabled&&event.target instanceof Element&&event.target.closest("#page-content")){
    event.preventDefault();
  }
});
window.addEventListener("keydown",(event)=>{
  if(screenPrivacyEnabled&&(event.ctrlKey||event.metaKey)&&event.key.toLowerCase()==="p"){
    event.preventDefault();
    event.stopPropagation();
  }
},true);
rememberPositionInput.addEventListener("change",async()=>{
  const enabled=rememberPositionInput.checked;
  localStorage.setItem("aquvi.rememberPosition",String(enabled));
  if(enabled)await saveCurrentPosition();else await clearSavedPositions();
  if(!bookshelfPanel.hidden)await renderBookshelf();
});
modeSelect.addEventListener("change",()=>{
  const next=modeSelect.value;
  if(!VIEW_MODES.includes(next)||next===mode){modeSelect.value=mode;return;}
  mode=next;localStorage.setItem("aquvi.mode",mode);rebuildViews();
});
pageShiftButton.addEventListener("click",()=>{
  if(mode!=="pair")return;pageShifted=!pageShifted;localStorage.setItem("aquvi.pageShifted",String(pageShifted));rebuildViews();
});
directionButton.addEventListener("click",()=>{
  direction=direction==="rtl"?"ltr":"rtl";localStorage.setItem("aquvi.direction",direction);rebuildViews();
});
previousButton.addEventListener("click",()=>showView(currentViewIndex-1));
nextButton.addEventListener("click",()=>showView(currentViewIndex+1));
readingModeButton.addEventListener("click",toggleReadingMode);
document.addEventListener("fullscreenchange",()=>{
  if(document.fullscreenElement===appShell&&readingMode)rememberReadingFullscreenSize();
  else if(readingMode)setReadingMode(false);
});
document.addEventListener("keydown",(event)=>{
  if(event.altKey||event.ctrlKey||event.metaKey)return;
  if(event.target&&["INPUT","TEXTAREA","SELECT"].includes(event.target.tagName))return;
  if(event.key==="Escape"&&readingMode&&!document.fullscreenElement){setReadingMode(false);return;}
  if(event.key==="ArrowLeft"){event.preventDefault();showView(currentViewIndex+(direction==="rtl"?1:-1));}
  else if(event.key==="ArrowRight"){event.preventDefault();showView(currentViewIndex+(direction==="rtl"?-1:1));}
  else if(event.key===" "){event.preventDefault();showView(currentViewIndex+1);}
  else if(event.key.toLowerCase()==="f")toggleReadingMode();
  else if(event.key.toLowerCase()==="l")toggleSidebar();
});
window.addEventListener("resize",()=>{
  if(readingMode){
    // Some macOS window-control transitions resize the browser without clearing
    // document.fullscreenElement. Detect the return to the previous window size.
    if(document.fullscreenElement!==appShell){
      setReadingMode(false);
      return;
    }
    if(windowHasLeftReadingFullscreen()){
      setReadingMode(false);
      if(document.fullscreenElement===appShell&&typeof document.exitFullscreen==="function"){
        document.exitFullscreen().catch(()=>{});
      }
      return;
    }
  }
  fitCurrentLayout();
});

function disposeViewerOnPageHide(event){
  // Preserve the live session if Chrome places the extension page in BFCache.
  if(event.persisted)return;
  loadToken++;
  cancelPasswordPrompt();
  releaseUrls();
  const activeArchive=archive;
  archive=null;
  sourceImages=[];pageViews=[];currentImageIndex=-1;currentSide=null;
  try{Promise.resolve(activeArchive?.close()).catch(()=>{});}catch{/* Best-effort shutdown during page teardown. */}
}
window.addEventListener("pagehide",disposeViewerOnPageHide);

const dropOverlay=$("drop-overlay");
let fileDragDepth=0;
function isArchiveFileDrag(event){
  return Array.from(event.dataTransfer?.types||[]).includes("Files");
}
window.addEventListener("dragenter",(event)=>{
  if(!isArchiveFileDrag(event))return;
  event.preventDefault();
  fileDragDepth++;
  dropOverlay.hidden=false;
});
window.addEventListener("dragover",(event)=>{
  if(!isArchiveFileDrag(event))return;
  event.preventDefault();
  if(event.dataTransfer)event.dataTransfer.dropEffect="copy";
});
window.addEventListener("dragleave",(event)=>{
  if(!isArchiveFileDrag(event))return;
  event.preventDefault();
  fileDragDepth=Math.max(0,fileDragDepth-1);
  if(fileDragDepth===0)dropOverlay.hidden=true;
});
window.addEventListener("drop",(event)=>{
  if(!isArchiveFileDrag(event))return;
  event.preventDefault();
  fileDragDepth=0;
  dropOverlay.hidden=true;
  const file=event.dataTransfer?.files?.[0];
  if(file)openArchive(file);
});
window.addEventListener("aquvi:archive-selected",(event)=>{if(event.detail){delete window.__aquviPendingArchive;openArchive(event.detail);}});
workspace.classList.toggle("sidebar-hidden",!sidebarVisible);updateToolbar();updateScreenPrivacy();
void initializeSecureHandoffStorage().catch(()=>{});
try{removeLegacyReadingPositions();}catch{/* Remove legacy plaintext reading-history keys when possible. */}
void restoreSavedBookshelf();
if(new URLSearchParams(location.search).get("bookshelf")==="1")setBookshelfPanelVisible(true);
void refreshDefaultPasswordControl();
if(legacyPlaintextPasswordRemoved){
  passwordStorageNote.textContent="安全性向上のため、以前に平文保存されていた既定パスワードを削除しました。保存する場合は再入力してください。";
}
if(window.__aquviPendingArchive){const file=window.__aquviPendingArchive;delete window.__aquviPendingArchive;openArchive(file);}

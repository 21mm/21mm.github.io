(() => {
  const fileInput = document.getElementById("archive-file");
  const folderInput = document.getElementById("bookshelf-folder");
  const openButton = document.getElementById("open-archive");
  const emptyOpenButton = document.getElementById("empty-open");
  const bookshelfScanButton = document.getElementById("bookshelf-scan");

  // The picker must be called synchronously inside the user's click gesture.
  const openPicker = () => fileInput.click();
  openButton.addEventListener("click", openPicker);
  emptyOpenButton.addEventListener("click", openPicker);

  // Prefer the standard directory upload picker. It grants access only to
  // the files explicitly selected for this scan and avoids a persistent
  // File System Access permission prompt for the entire folder.
  bookshelfScanButton.addEventListener("click", () => {
    if (typeof window.__aquviOpenBookshelfPicker === "function") {
      window.__aquviOpenBookshelfPicker();
      return;
    }
    folderInput.click();
  });

  fileInput.addEventListener("change", () => {
    const file = fileInput.files && fileInput.files[0];
    fileInput.value = "";
    if (!file) return;
    window.__aquviPendingArchive = file;
    window.dispatchEvent(new CustomEvent("aquvi:archive-selected", { detail: file }));
  });

  folderInput.addEventListener("change", () => {
    const files = Array.from(folderInput.files || []);
    folderInput.value = "";
    if (!files.length) return;
    const detail = { files };
    window.__aquviPendingBookshelf = detail;
    window.dispatchEvent(new CustomEvent("aquvi:bookshelf-selected", { detail }));
  });
})();

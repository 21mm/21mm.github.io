export const ACTIVE_EDITION = "free";

const EDITION_CAPABILITIES = Object.freeze({
  free: Object.freeze({
    archiveFormats: new Set(["zip", "sevenZip", "tar"]),
    zipFallbackMethods: new Set([12])
  }),
  premium: Object.freeze({
    archiveFormats: null,
    zipFallbackMethods: null
  })
});

export function getEditionCapabilities(edition = ACTIVE_EDITION) {
  const capabilities = EDITION_CAPABILITIES[edition];
  if (!capabilities) throw new RangeError(`Unknown Aquvi edition: ${edition}`);
  return capabilities;
}

export function isArchiveFormatIncluded(format, edition = ACTIVE_EDITION) {
  const allowed = getEditionCapabilities(edition).archiveFormats;
  return allowed === null || allowed.has(format);
}

export function isZipFallbackMethodIncluded(method, edition = ACTIVE_EDITION) {
  const allowed = getEditionCapabilities(edition).zipFallbackMethods;
  return allowed === null || allowed.has(method);
}

export function getEditionRestrictedMessage(format) {
  const labels = {
    rar: "RAR / CBR", gzip: "GZIP", bzip2: "BZIP2", xz: "XZ", lzma: "LZMA",
    zstd: "Zstandard", cab: "CAB", iso: "ISO", dmg: "DMG", wim: "WIM",
    lha: "LHA / LZH", xar: "XAR / XIP", ar: "AR", cpio: "CPIO", exe: "EXE",
    msi: "MSI", lzip: "LZIP", brotli: "Brotli", lrzip: "LRZIP", lz4: "LZ4",
    snappy: "Snappy", appleArchive: "Apple Archive", is3: "IS3", cpt: "CPT", spk: "SPK"
  };
  const label = labels[format] || format;
  return `${label}形式はAquvi Freeの対応範囲外です。プレミアム版向けの拡張対象です。`;
}
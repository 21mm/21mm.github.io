# Workers and WebAssembly

CPU-intensive archive parsing, decryption, and decompression should run outside the viewer UI thread where practical.

## Design rules

- Bundle Worker and WebAssembly assets locally with the extension.
- Do not load executable code from a CDN or remote host.
- Keep message payloads bounded and avoid unnecessary copies of large buffers.
- Support cancellation when the user switches archives or closes the viewer.
- Return structured errors; do not include passwords or decrypted image data in logs.
- Review the extension Content Security Policy and Chrome WebAssembly requirements when selecting an engine.

## Startup behavior

- No archive Worker is created while the popup or empty viewer is idle.
- The selected file is signature-checked first with bounded reads.
- Only the Worker for the identified format is created, with local WASM assets initialized on first use.
- Do not initialize every format engine at extension startup.
- Keep a Worker alive for the active archive so navigation does not pay initialization cost repeatedly; terminate it when the archive is replaced or closed.

## 7-Zip worker

The 7z reader is implemented in `sevenzip-worker.mjs` and uses the pinned 7-Zip 26.02 WebAssembly loader.

- The archive File is passed to the Worker and copied in 4 MiB slices into the Worker memory filesystem.
- The 7z process lists entries without extracting them. For header-encrypted archives, the Worker returns a password-required error so the viewer can prompt and retry on the same Worker.
- The selected image is extracted by its exact relative path into a temporary in-memory directory.
- The extracted bytes are returned as a transferable ArrayBuffer; the temporary directory is removed immediately afterwards.
- The Worker retains the active archive and 7z runtime while the archive is open, then clears the filesystem and is terminated on close.

The upstream OPFS output adapter is not used by Aquvi; no extracted image or password is written to OPFS.


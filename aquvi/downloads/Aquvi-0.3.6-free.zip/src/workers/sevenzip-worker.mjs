import SevenZipFactory from "../../vendor/7zip/un7z-opfs/7zz.js";
import { parseSevenZipListing, isSupportedArchiveImage, isSafeArchivePath } from "../archive/sevenzip-listing.mjs";
import { toTransferableArrayBuffer } from "../archive/transferable-buffer.mjs";
import { isSevenZipPasswordPrompt } from "../archive/sevenzip-password-error.mjs";

const MAX_IMAGE_BYTES = 64 * 1024 * 1024;
const ARCHIVE_PATH = "/input/archive.7z";
const OUTPUT_ROOT = "/aquvi-output";

let sevenZip = null;
let loadedFile = null;
let cachedPassword = null;
let stdoutLines = null;
let stderrLines = null;
let outputCounter = 0;
let commandQueue = Promise.resolve();

function codedError(code, message) {
  const error = new Error(message);
  error.code = code;
  return error;
}

async function initializeEngine() {
  if (sevenZip) return;
  sevenZip = await SevenZipFactory({
    print: (line) => stdoutLines?.push(String(line)),
    printErr: (line) => stderrLines?.push(String(line))
  });
  sevenZip.FS.mkdir("/input");
  sevenZip.FS.mkdir(OUTPUT_ROOT);
}

async function writeArchiveInChunks(file) {
  const fs = sevenZip.FS;
  try { fs.unlink(ARCHIVE_PATH); } catch {/* First open. */}
  const stream = fs.open(ARCHIVE_PATH, "w+");
  let position = 0;
  const chunkSize = 4 * 1024 * 1024;

  try {
    while (position < file.size) {
      const end = Math.min(position + chunkSize, file.size);
      const chunk = new Uint8Array(await file.slice(position, end).arrayBuffer());
      let offset = 0;
      while (offset < chunk.length) {
        const written = fs.write(stream, chunk, offset, chunk.length - offset, position + offset);
        if (!Number.isInteger(written) || written <= 0) {
          throw codedError("ARCHIVE_COPY_FAILED", "7zアーカイブを読み込めませんでした。");
        }
        offset += written;
      }
      position = end;
    }
  } finally {
    fs.close(stream);
  }

  if (position !== file.size) {
    throw codedError("ARCHIVE_COPY_FAILED", "アーカイブの読み込みサイズが一致しません。");
  }
}

function collectOutput() {
  return [...(stdoutLines || []), ...(stderrLines || [])].join("\n");
}

function classifyFailure(exitCode, passwordSupplied, fallback) {
  const details = collectOutput();
  if (
    isSevenZipPasswordPrompt(details) ||
    (passwordSupplied && /(?:Listing|Extracting) archive:/i.test(details))
  ) {
    return codedError(
      passwordSupplied ? "BAD_PASSWORD" : "PASSWORD_REQUIRED",
      passwordSupplied
        ? "パスワードが違うか、7zアーカイブが破損しています。"
        : "この7zアーカイブにはパスワードが必要です。"
    );
  }
  return codedError("ARCHIVE_ERROR", details.trim() || fallback || ("7z exit code " + exitCode));
}

async function runCommand(args, passwordSupplied, fallback) {
  stdoutLines = [];
  stderrLines = [];
  try {
    const exitCode = await sevenZip.callMain(args);
    if (exitCode !== 0) throw classifyFailure(exitCode, passwordSupplied, fallback);
    return collectOutput();
  } catch (error) {
    if (error?.code) throw error;
    const details = collectOutput();
    if (
      isSevenZipPasswordPrompt(details) ||
      (passwordSupplied && /(?:Listing|Extracting) archive:/i.test(details))
    ) {
      throw classifyFailure(1, passwordSupplied, fallback);
    }
    // Encrypted 7z headers may surface as an Emscripten C++ exception before
    // the console prints a normal "Wrong password?" diagnostic. In the list
    // command this is the password-gated header parse; retry on the same
    // runtime with the password instead of surfacing a raw CppException.
    if (error?.name === "CppException" || /^CppException/.test(String(error))) {
      throw codedError(
        passwordSupplied ? "BAD_PASSWORD" : "PASSWORD_REQUIRED",
        passwordSupplied
          ? "パスワードが違うか、7zアーカイブが破損しています。"
          : "この7zアーカイブにはパスワードが必要です。"
      );
    }
    throw codedError("ARCHIVE_ERROR", details.trim() || error?.message || fallback || "7zの処理に失敗しました。");
  } finally {
    stdoutLines = null;
    stderrLines = null;
  }
}

async function openArchive(file, password) {
  await initializeEngine();
  if (!loadedFile) {
    if (!file || typeof file.slice !== "function" || !Number.isFinite(file.size) || file.size < 1) {
      throw codedError("INVALID_FILE", "有効な7zアーカイブを選択してください。");
    }
    await writeArchiveInChunks(file);
    loadedFile = { name: file.name || "archive.7z", size: file.size };
  }

  const args = ["l", "-slt", "-bb0", "-sccUTF-8"];
  if (password) args.push("-p" + password);
  args.push(ARCHIVE_PATH);

  const listing = await runCommand(args, Boolean(password), "7zの目次を読み込めませんでした。");
  const entries = parseSevenZipListing(listing, ARCHIVE_PATH)
    .filter((entry) => isSupportedArchiveImage(entry.name));

  if (!entries.length) {
    throw codedError("NO_IMAGES", "7zアーカイブに対応する画像ファイルがありません。");
  }

  cachedPassword = password || null;
  return entries;
}

function removeDirectoryContents(path) {
  const fs = sevenZip.FS;
  let names = [];
  try { names = fs.readdir(path).filter((name) => name !== "." && name !== ".."); }
  catch { return; }

  for (const name of names) {
    const child = path + "/" + name;
    try {
      const stat = fs.stat(child);
      if (fs.isDir(stat.mode)) {
        removeDirectoryContents(child);
        fs.rmdir(child);
      } else {
        fs.unlink(child);
      }
    } catch {/* Continue best-effort cleanup of remaining output files. */}
  }
}

function prepareOutputDirectory() {
  removeDirectoryContents(OUTPUT_ROOT);
  sevenZip.FS.mkdirTree(OUTPUT_ROOT);
}

function safeOutputPath(entryName) {
  if (!isSafeArchivePath(entryName)) {
    throw codedError("UNSAFE_PATH", "アーカイブ内のファイルパスが安全ではありません。");
  }
  return OUTPUT_ROOT + "/" + entryName.replace(/\\/g, "/");
}

async function readEntry(entry, password) {
  if (!entry || typeof entry.name !== "string" || !isSafeArchivePath(entry.name)) {
    throw codedError("UNSAFE_PATH", "アーカイブ内のファイルパスが安全ではありません。");
  }
  if (!isSupportedArchiveImage(entry.name)) {
    throw codedError("UNSUPPORTED_IMAGE", "このファイル形式は画像として表示できません。");
  }
  if (!Number.isSafeInteger(entry.size) || entry.size < 0 || entry.size > MAX_IMAGE_BYTES) {
    throw codedError("SIZE_LIMIT", "画像が現在の64 MiB上限を超えています。");
  }

  const effectivePassword = password ?? cachedPassword;
  const outputPath = safeOutputPath(entry.name);
  prepareOutputDirectory();

  const args = [
    "x",
    ARCHIVE_PATH,
    "-y",
    "-bb0",
    "-bd",
    "-spd",
    "-sccUTF-8",
    "-o" + OUTPUT_ROOT
  ];
  if (effectivePassword) args.push("-p" + effectivePassword);
  args.push("--", entry.name);

  try {
    await runCommand(args, Boolean(effectivePassword), "7zから画像を展開できませんでした。");
    let data;
    try {
      data = sevenZip.FS.readFile(outputPath);
    } catch {
      throw codedError("ENTRY_NOT_FOUND", "指定した画像をアーカイブ内で見つけられませんでした。");
    }
    if (!(data instanceof Uint8Array) || data.byteLength > MAX_IMAGE_BYTES) {
      throw codedError("SIZE_LIMIT", "展開後の画像が64 MiBを超えています。");
    }
    if (data.byteLength !== entry.size) {
      throw codedError("SIZE_MISMATCH", "7zの一覧情報と展開後の画像サイズが一致しません。");
    }
    if (effectivePassword) cachedPassword = effectivePassword;
    // FS.readFile may return a full-sized view of its own allocation. When
    // that is the case, the buffer can be transferred directly after the
    // temporary output file is unlinked in finally. Partial views are copied
    // by the helper so no unrelated bytes are exposed to the viewer.
    return toTransferableArrayBuffer(data);
  } catch (error) {
    if (error?.code === "BAD_PASSWORD") cachedPassword = null;
    throw error;
  } finally {
    removeDirectoryContents(OUTPUT_ROOT);
  }
}

async function closeArchive() {
  cachedPassword = null;
  loadedFile = null;
  outputCounter = 0;
  if (sevenZip) {
    try { removeDirectoryContents(OUTPUT_ROOT); } catch {/* Best-effort memory cleanup. */}
    try { sevenZip.FS.unlink(ARCHIVE_PATH); } catch {/* Best-effort memory cleanup. */}
    try { sevenZip.FS.rmdir("/input"); } catch {/* Best-effort memory cleanup. */}
    try { sevenZip.FS.rmdir(OUTPUT_ROOT); } catch {/* Best-effort memory cleanup. */}
  }
  sevenZip = null;
}

async function handleMessage(message) {
  if (message.type === "open") {
    return { entries: await openArchive(message.file, message.password) };
  }
  if (message.type === "read") {
    return { data: await readEntry(message.entry, message.password) };
  }
  if (message.type === "close") {
    await closeArchive();
    return { closed: true };
  }
  throw codedError("UNKNOWN_MESSAGE", "不明なアーカイブ操作です。");
}

self.onmessage = (event) => {
  const message = event.data || {};
  commandQueue = commandQueue.then(async () => {
    try {
      const result = await handleMessage(message);
      if (result.data instanceof ArrayBuffer) {
        self.postMessage({ id: message.id, ok: true, ...result }, [result.data]);
      } else {
        self.postMessage({ id: message.id, ok: true, ...result });
      }
    } catch (error) {
      self.postMessage({
        id: message.id,
        ok: false,
        error: {
          code: error?.code || "ARCHIVE_ERROR",
          message: error?.message || "7zを読み込めませんでした。"
        }
      });
    }
  }).catch(() => {});
};

/* Classic Worker: the full-format JS7z UMD runtime is loaded only on demand. */
const ENGINE_DIRECTORY = new URL("../../vendor/7zip-full/", self.location.href);
const MAX_IMAGE_BYTES = 64 * 1024 * 1024;
const OUTPUT_DIRECTORY = "/aquvi-output";

let engineFactory = null;
let activeFile = null;
let activeArchivePath = "";
let cachedPassword = null;
let commandQueue = Promise.resolve();

function codedError(code, message) {
  const error = new Error(message);
  error.code = code;
  return error;
}

function isSafeArchivePath(path) {
  if (!path || path.includes("\0")) return false;
  if (path.startsWith("/") || path.startsWith("\\") || /^[a-z]:/i.test(path)) return false;
  return !path.split(/[\\/]/).some((part) => part === ".." || part === ".");
}

function isImagePath(path) {
  const leaf = String(path || "").split(/[\\/]/).pop() || "";
  const dot = leaf.lastIndexOf(".");
  if (dot <= 0) return false;
  return new Set(["jpg", "jpeg", "png", "gif", "webp", "avif", "bmp"])
    .has(leaf.slice(dot + 1).toLowerCase());
}

function parseListing(text, archivePath) {
  const records = [];
  let block = [];
  for (const line of String(text || "").replace(/\r/g, "").split("\n")) {
    if (!line.trim() || /^-{5,}$/.test(line.trim())) {
      if (block.length) records.push(block);
      block = [];
    } else {
      block.push(line);
    }
  }
  if (block.length) records.push(block);

  const entries = [];
  for (const lines of records) {
    const record = {};
    for (const line of lines) {
      const separator = line.indexOf(" = ");
      if (separator > 0) record[line.slice(0, separator)] = line.slice(separator + 3);
    }

    const name = record.Path;
    if (!name || name === archivePath) continue;
    if (record.Folder === "+" || /^D/i.test(String(record.Attributes || "").trim())) continue;
    if (!isSafeArchivePath(name)) continue;
    if (record["Symbolic Link"] || record["Hard Link"] || record.ReparsePoint === "+") continue;

    const size = Number(record.Size);
    if (!Number.isSafeInteger(size) || size < 0) continue;
    entries.push({
      id: entries.length,
      name,
      size,
      encrypted: record.Encrypted === "+",
      method: record.Method || "",
      crc: record.CRC || null,
      isDirectory: false
    });
  }

  entries.sort((left, right) =>
    left.name.localeCompare(right.name, "ja", { numeric: true, sensitivity: "base" }) || left.id - right.id
  );
  const seen = new Set();
  for (const entry of entries) {
    if (seen.has(entry.name)) entry.duplicatePath = true;
    else seen.add(entry.name);
  }
  return entries;
}

function outputText(logs) {
  return logs.join("\n");
}

function passwordFailure(details, supplied) {
  if (
    /wrong password|password.*incorrect|incorrect password|enter password:?|can not open encrypted archive|cannot open encrypted archive|headers error|data error in encrypted file|encrypted archive/i.test(details)
  ) return true;
  return Boolean(supplied && /(?:Listing|Extracting) archive:/i.test(details));
}

function ensureEngineFactory() {
  if (engineFactory) return engineFactory;
  importScripts(new URL("js7z.js", ENGINE_DIRECTORY).href);
  engineFactory = self.JS7z || self.js7z || self.SevenZip;
  if (typeof engineFactory !== "function") {
    throw codedError("ENGINE_INIT", "7-Zip multi-format engine could not be initialized.");
  }
  return engineFactory;
}

function archiveNameFor(file) {
  const last = String(file?.name || "").split(/[\\/]/).pop() || "archive.bin";
  // Keep the real basename: single-stream wrappers such as image.png.gz
  // are exposed by 7-Zip as image.png after decompression.
  if (last === "." || last === ".." || last.includes("\\0")) return "archive.bin";
  return last;
}

function singleStreamImageName(fileName) {
  const leaf = String(fileName || "").split(/[\\/]/).pop() || "";
  const output = leaf.replace(/\.(?:gz|bz|bz2|xz|lzma|zst|zstd|lz|lzip|br|brotli|lrz|lrzip|lz4|snappy)$/i, "");
  return output !== leaf && isImagePath(output) ? output : null;
}

function collectExtractedFiles(fs, directory, output = []) {
  for (const name of fs.readdir(directory)) {
    if (name === "." || name === "..") continue;
    const path = directory.replace(/\/$/, "") + "/" + name;
    const stat = fs.stat(path);
    if (fs.isDir(stat.mode)) collectExtractedFiles(fs, path, output);
    else if (fs.isFile(stat.mode)) output.push(path);
  }
  return output;
}

async function withEngine(run) {
  const factory = ensureEngineFactory();
  const logs = [];
  const engine = await factory({
    locateFile: (path) => new URL(path, ENGINE_DIRECTORY).href,
    print: (line) => logs.push(String(line)),
    printErr: (line) => logs.push(String(line)),
    noInitialRun: true
  });

  try {
    if (typeof engine.FS?.mount !== "function" || !engine.WORKERFS) {
      throw codedError("WORKERFS_UNAVAILABLE", "This 7-Zip build lacks the Worker file-system adapter.");
    }
    engine.FS.mkdir("/input");
    engine.FS.mkdir(OUTPUT_DIRECTORY);
    engine.FS.mount(engine.WORKERFS, {
      blobs: [{ name: activeArchivePath.slice("/input/".length), data: activeFile }]
    }, "/input");
    return await run(engine, logs);
  } finally {
    try { engine.FS.unmount("/input"); } catch {/* The runtime is discarded after each CLI operation. */}
    try { engine.FS.unmount(OUTPUT_DIRECTORY); } catch {/* Best-effort runtime cleanup. */}
  }
}

async function runCommand(args, passwordSupplied, fallback, onSuccess = null) {
  return withEngine(async (engine, logs) => {
    try {
      const exitCode = await engine.callMain(args);
      const details = outputText(logs);
      if (exitCode !== 0) {
        if (passwordFailure(details, passwordSupplied)) {
          throw codedError(
            passwordSupplied ? "BAD_PASSWORD" : "PASSWORD_REQUIRED",
            passwordSupplied
              ? "パスワードが違うか、アーカイブが破損しています。"
              : "このアーカイブにはパスワードが必要です。"
          );
        }
        throw codedError("ARCHIVE_ERROR", details.trim() || fallback || ("7-Zip exit code " + exitCode));
      }
      return onSuccess ? await onSuccess(engine, details) : details;
    } catch (error) {
      if (error?.code) throw error;
      const details = outputText(logs);
      if (passwordFailure(details, passwordSupplied) || /CppException/.test(String(error))) {
        throw codedError(
          passwordSupplied ? "BAD_PASSWORD" : "PASSWORD_REQUIRED",
          passwordSupplied
            ? "パスワードが違うか、アーカイブが破損しています。"
            : "このアーカイブにはパスワードが必要です。"
        );
      }
      throw codedError("ARCHIVE_ERROR", details.trim() || error?.message || fallback || "アーカイブを読み込めませんでした。");
    }
  });
}

async function openArchive(file, password) {
  if (!file || typeof file.slice !== "function" || !Number.isFinite(file.size) || file.size < 1) {
    throw codedError("INVALID_FILE", "有効なアーカイブを選択してください。");
  }
  if (!activeFile) {
    activeFile = file;
    activeArchivePath = "/input/" + archiveNameFor(file);
  }

  const args = ["l", "-slt", "-bb0", "-sccUTF-8"];
  if (password) args.push("-p" + password);
  args.push(activeArchivePath);

  const listing = await runCommand(args, Boolean(password), "アーカイブの目次を読み込めませんでした。");
  const entries = parseListing(listing, activeArchivePath);
  if (!entries.length) {
    const name = singleStreamImageName(file.name);
    if (name) {
      entries.push({
        id: 0,
        name,
        size: null,
        encrypted: false,
        method: "single-stream",
        crc: null,
        isDirectory: false,
        singleStream: true
      });
    }
  }
  if (!entries.length) {
    throw codedError("NO_IMAGES", "アーカイブに対応する画像ファイルがありません。");
  }
  cachedPassword = password || null;
  return entries;
}

async function readEntry(entry, password) {
  if (!entry || typeof entry.name !== "string" || !isSafeArchivePath(entry.name)) {
    throw codedError("UNSAFE_PATH", "アーカイブ内のファイルパスが安全ではありません。");
  }
  if (entry.duplicatePath) {
    throw codedError("DUPLICATE_PATH", "同じパスの画像が複数あるため、この項目を特定できません。");
  }
  if (entry.size !== null && (!Number.isSafeInteger(entry.size) || entry.size < 0 || entry.size > MAX_IMAGE_BYTES)) {
    throw codedError("SIZE_LIMIT", "画像が現在の64 MiB上限を超えています。");
  }

  const effectivePassword = password ?? cachedPassword;

  if (entry.singleStream) {
    const args = ["x", activeArchivePath, "-y", "-bb0", "-bd", "-spd", "-sccUTF-8", "-o" + OUTPUT_DIRECTORY];
    if (effectivePassword) args.push("-p" + effectivePassword);
    try {
      const result = await runCommand(
        args,
        Boolean(effectivePassword),
        "圧縮された画像を展開できませんでした。",
        async (engine) => {
          const files = collectExtractedFiles(engine.FS, OUTPUT_DIRECTORY);
          if (files.length !== 1) {
            throw codedError("SINGLE_STREAM_OUTPUT", "単体圧縮ファイルから画像を1つだけ取り出せませんでした。");
          }
          const data = engine.FS.readFile(files[0]);
          if (!(data instanceof Uint8Array) || data.byteLength > MAX_IMAGE_BYTES) {
            throw codedError("SIZE_LIMIT", "展開後の画像が64 MiBを超えています。");
          }
          if (Number.isSafeInteger(entry.size) && entry.size > 0 && data.byteLength !== entry.size) {
            throw codedError("SIZE_MISMATCH", "一覧情報と展開後の画像サイズが一致しません。");
          }
          return data.slice().buffer;
        }
      );
      if (effectivePassword) cachedPassword = effectivePassword;
      return result;
    } catch (error) {
      if (error?.code === "BAD_PASSWORD") cachedPassword = null;
      throw error;
    }
  }

  const outputPath = OUTPUT_DIRECTORY + "/" + entry.name.replace(/\\/g, "/");

  const args = [
    "x",
    activeArchivePath,
    "-y",
    "-bb0",
    "-bd",
    "-spd",
    "-sccUTF-8",
    "-o" + OUTPUT_DIRECTORY
  ];
  if (effectivePassword) args.push("-p" + effectivePassword);
  args.push("--", entry.name);

  try {
    const result = await runCommand(
      args,
      Boolean(effectivePassword),
      "選択した画像を展開できませんでした。",
      async (engine) => {
        const data = engine.FS.readFile(outputPath);
        if (!(data instanceof Uint8Array) || data.byteLength > MAX_IMAGE_BYTES) {
          throw codedError("SIZE_LIMIT", "展開後の画像が64 MiBを超えています。");
        }
        if (data.byteLength !== entry.size) {
          throw codedError("SIZE_MISMATCH", "一覧情報と展開後の画像サイズが一致しません。");
        }
        return data.slice().buffer;
      }
    );
    if (effectivePassword) cachedPassword = effectivePassword;
    return result;
  } catch (error) {
    if (error?.code === "BAD_PASSWORD") cachedPassword = null;
    throw error;
  }
}

async function verifyEntry(entry, password) {
  if (!entry || typeof entry.name !== "string" || !isSafeArchivePath(entry.name)) {
    throw codedError("UNSAFE_PATH", "アーカイブ内のファイルパスが安全ではありません。");
  }
  const args = ["t", activeArchivePath, "-y", "-bb0", "-bd", "-spd", "-sccUTF-8"];
  if (password) args.push("-p" + password);
  args.push("--", entry.name);
  return runCommand(args, Boolean(password), "選択したアーカイブ項目の検査に失敗しました。",
    async (_engine, details) => ({ passed: true, details }));
}

function handleMessage(message) {
  if (message.type === "open") return openArchive(message.file, message.password);
  if (message.type === "read") return readEntry(message.entry, message.password);
  if (message.type === "verify") return verifyEntry(message.entry, message.password);
  if (message.type === "close") {
    cachedPassword = null;
    activeFile = null;
    activeArchivePath = "";
    engineFactory = null;
    return Promise.resolve({ closed: true });
  }
  return Promise.reject(codedError("UNKNOWN_MESSAGE", "不明なアーカイブ操作です。"));
}

let queue = Promise.resolve();
self.onmessage = (event) => {
  const message = event.data || {};
  queue = queue.then(async () => {
    try {
      const result = await handleMessage(message);
      if (result instanceof ArrayBuffer) {
        self.postMessage({ id: message.id, ok: true, data: result }, [result]);
      } else {
        self.postMessage({ id: message.id, ok: true, result });
      }
    } catch (error) {
      self.postMessage({
        id: message.id,
        ok: false,
        error: {
          code: error?.code || "ARCHIVE_ERROR",
          message: error?.message || "アーカイブを読み込めませんでした。"
        }
      });
    }
  }).catch(() => {});
};

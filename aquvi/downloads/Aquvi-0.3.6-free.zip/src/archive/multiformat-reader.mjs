import { isSupportedArchiveImage } from "./sevenzip-listing.mjs";

const MAX_IMAGE_BYTES = 64 * 1024 * 1024;

export class MultiFormatArchiveError extends Error {
  constructor(message, code = "MULTIFORMAT_ERROR") {
    super(message);
    this.name = "MultiFormatArchiveError";
    this.code = code;
  }
}

export class MultiFormatArchive {
  constructor(file, worker) {
    this.file = file;
    this.fileName = file.name || "archive";
    this.worker = worker;
    this.entries = [];
    this.closed = false;
    this.password = null;
    this.nextRequestId = 1;
    this.pending = new Map();

    worker.addEventListener("message", (event) => {
      const message = event.data || {};
      const pending = this.pending.get(message.id);
      if (!pending) return;
      this.pending.delete(message.id);
      if (message.ok) pending.resolve(message);
      else pending.reject(new MultiFormatArchiveError(
        message.error?.message || "アーカイブの処理に失敗しました。",
        message.error?.code || "ARCHIVE_ERROR"
      ));
    });
    worker.addEventListener("error", () => {
      for (const pending of this.pending.values()) {
        pending.reject(new MultiFormatArchiveError("マルチ形式Workerが停止しました。", "WORKER_FAILED"));
      }
      this.pending.clear();
    });
  }

  static async open(file, options = {}) {
    const worker = new Worker(
      new URL("../workers/multiformat-worker.js", import.meta.url),
      { name: "aquvi-multiformat-reader" }
    );
    const archive = new MultiFormatArchive(file, worker);
    let password = options.password || null;
    let retry = Boolean(password);

    try {
      while (true) {
        try {
          const result = await archive.request("open", { file, password });
          archive.entries = result.result;
          archive.password = password;
          return archive;
        } catch (error) {
          if (error?.code !== "PASSWORD_REQUIRED" && error?.code !== "BAD_PASSWORD") throw error;
          if (typeof options.requestPassword !== "function") throw error;
          password = await options.requestPassword(retry);
          if (password === null) {
            throw new MultiFormatArchiveError("パスワード入力をキャンセルしました。", "PASSWORD_CANCELLED");
          }
          retry = true;
        }
      }
    } catch (error) {
      await archive.close();
      throw error;
    }
  }

  get imageEntries() {
    return this.entries.filter((entry) => isSupportedArchiveImage(entry.name));
  }

  getEntryAvailability(entry) {
    if (this.closed || !this.worker) return "アーカイブは閉じられています。";
    if (!entry || !isSupportedArchiveImage(entry.name)) return "対応していない画像形式です。";
    if (entry.duplicatePath) return "同じパスの画像が複数あるため、この項目を区別できません。";
    if (entry.size !== null && (!Number.isSafeInteger(entry.size) || entry.size < 0 || entry.size > MAX_IMAGE_BYTES)) {
      return "画像が現在の64 MiB上限を超えています。";
    }
    return null;
  }

  async request(type, payload = {}) {
    if (this.closed || !this.worker) {
      throw new MultiFormatArchiveError("アーカイブは閉じられています。", "ARCHIVE_CLOSED");
    }
    const id = this.nextRequestId++;
    return new Promise((resolve, reject) => {
      this.pending.set(id, { resolve, reject });
      try { this.worker.postMessage({ id, type, ...payload }); }
      catch (error) {
        this.pending.delete(id);
        reject(error);
      }
    });
  }

  async readEntry(entry, options = {}) {
    if (this.closed) throw new MultiFormatArchiveError("アーカイブは閉じられています。", "ARCHIVE_CLOSED");
    const unavailable = this.getEntryAvailability(entry);
    if (unavailable) throw new MultiFormatArchiveError(unavailable, "UNSUPPORTED_ENTRY");

    const password = options.password ?? this.password;
    if (entry.encrypted && !password) {
      throw new MultiFormatArchiveError("この画像を開くにはパスワードが必要です。", "PASSWORD_REQUIRED");
    }
    try {
      const result = await this.request("read", {
        entry: { id: entry.id, name: entry.name, size: entry.size, encrypted: entry.encrypted, singleStream: entry.singleStream },
        password: password || null
      });
      if (!(result.data instanceof ArrayBuffer) || result.data.byteLength > MAX_IMAGE_BYTES) {
        throw new MultiFormatArchiveError("展開結果が不正です。", "INVALID_OUTPUT");
      }
      if (password) this.password = password;
      return new Uint8Array(result.data);
    } catch (error) {
      if (error?.code === "BAD_PASSWORD" && this.password === password) this.password = null;
      throw error;
    }
  }

  async close() {
    if (this.closed) return;
    this.closed = true;
    const worker = this.worker;
    this.worker = null;
    for (const pending of this.pending.values()) {
      pending.reject(new MultiFormatArchiveError("アーカイブは閉じられています。", "ARCHIVE_CLOSED"));
    }
    this.pending.clear();
    worker?.terminate();
    this.file = null;
    this.entries = [];
    this.password = null;
  }
}

const PASSWORD_PROMPT_PATTERNS = [
  /wrong password/i,
  /password.*incorrect/i,
  /incorrect password/i,
  /enter password(?:\s*\([^)]*\))?\s*:/i,
  /can not open encrypted archive/i,
  /cannot open encrypted archive/i,
  /headers error/i,
  /data error in encrypted file/i,
  /encrypted archive/i
];

export function isSevenZipPasswordPrompt(output) {
  const text = String(output || "");
  return PASSWORD_PROMPT_PATTERNS.some((pattern) => pattern.test(text));
}

const DATABASE_NAME = "aquvi-bookshelf-thumbnails";
const DATABASE_VERSION = 2;
const KEY_STORE = "encryption-keys";
const THUMBNAIL_STORE = "thumbnails";
const PROFILE_KEY_ID = "bookshelf-aes-gcm";
const MAX_CACHE_ENTRIES = 512;
const MAX_CACHE_BYTES = 64 * 1024 * 1024;
const MAX_WIDTH = 256;
const MAX_HEIGHT = 352;

let databasePromise = null;
let profileKeyPromise = null;

function requestResult(request) {
  return new Promise((resolve, reject) => {
    request.onsuccess = () => resolve(request.result);
    request.onerror = () => reject(request.error || new Error("IndexedDB request failed."));
  });
}

function transactionDone(transaction) {
  return new Promise((resolve, reject) => {
    transaction.oncomplete = () => resolve();
    transaction.onabort = () => reject(transaction.error || new Error("IndexedDB transaction aborted."));
    transaction.onerror = () => reject(transaction.error || new Error("IndexedDB transaction failed."));
  });
}

function openDatabase() {
  if (!globalThis.indexedDB) return Promise.resolve(null);
  if (databasePromise) return databasePromise;
  databasePromise = new Promise((resolve, reject) => {
    const request = indexedDB.open(DATABASE_NAME, DATABASE_VERSION);
    request.onupgradeneeded = (event) => {
      const database = request.result;
      if (!database.objectStoreNames.contains(KEY_STORE)) {
        database.createObjectStore(KEY_STORE, { keyPath: "id" });
      }
      if (!database.objectStoreNames.contains(THUMBNAIL_STORE)) {
        const store = database.createObjectStore(THUMBNAIL_STORE, { keyPath: "id" });
        store.createIndex("lastUsed", "lastUsed", { unique: false });
      } else if (event.oldVersion < 2) {
        // Old thumbnails used a profile-wide encryption key and password only
        // as an identifier scope. Discard them rather than migrate weak records.
        request.transaction.objectStore(THUMBNAIL_STORE).clear();
      }
    };
    request.onsuccess = () => {
      const database = request.result;
      database.onversionchange = () => database.close();
      resolve(database);
    };
    request.onerror = () => {
      databasePromise = null;
      reject(request.error || new Error("Could not open the thumbnail cache."));
    };
    request.onblocked = () => {
      databasePromise = null;
      reject(new Error("The thumbnail cache database is blocked."));
    };
  });
  return databasePromise;
}

async function getProfileKey(database) {
  if (profileKeyPromise) return profileKeyPromise;
  profileKeyPromise = (async () => {
    const read = database.transaction(KEY_STORE, "readonly");
    const stored = await requestResult(read.objectStore(KEY_STORE).get(PROFILE_KEY_ID));
    await transactionDone(read);
    if (stored?.key) return stored.key;

    const key = await crypto.subtle.generateKey(
      { name: "AES-GCM", length: 256 },
      false,
      ["encrypt", "decrypt"]
    );
    const write = database.transaction(KEY_STORE, "readwrite");
    write.objectStore(KEY_STORE).put({ id: PROFILE_KEY_ID, key });
    await transactionDone(write);
    return key;
  })().catch((error) => {
    profileKeyPromise = null;
    throw error;
  });
  return profileKeyPromise;
}

async function getIdentityKey(database) {
  const generatedKey = await crypto.subtle.generateKey(
    { name: "HMAC", hash: "SHA-256", length: 256 }, false, ["sign"]
  );
  return new Promise((resolve, reject) => {
    const transaction = database.transaction(KEY_STORE, "readwrite");
    const store = transaction.objectStore(KEY_STORE);
    let selectedKey = null;
    const request = store.get("bookshelf-identity-hmac");
    request.onsuccess = () => {
      if (request.result?.key) selectedKey = request.result.key;
      else {
        selectedKey = generatedKey;
        store.add({ id: "bookshelf-identity-hmac", key: generatedKey });
      }
    };
    request.onerror = () => { try { transaction.abort(); } catch {} };
    transaction.oncomplete = () => resolve(selectedKey);
    transaction.onabort = () => reject(transaction.error || request.error || new Error("Could not initialize the thumbnail identity key."));
  });
}
async function cacheRecordId(database, identity) {
  const key = await getIdentityKey(database);
  const digest = await crypto.subtle.sign("HMAC", key, new TextEncoder().encode(String(identity || "")));
  return Array.from(new Uint8Array(digest), (byte) => byte.toString(16).padStart(2, "0")).join("");
}
async function getThumbnailKey(database, passwordScope, salt) {
  if (!passwordScope) return getProfileKey(database);
  const material = await crypto.subtle.importKey("raw", new TextEncoder().encode(passwordScope), "PBKDF2", false, ["deriveKey"]);
  return crypto.subtle.deriveKey({ name: "PBKDF2", salt, iterations: 100000, hash: "SHA-256" }, material,
    { name: "AES-GCM", length: 256 }, false, ["encrypt", "decrypt"]);
}

async function trimCache(database) {
  const transaction = database.transaction(THUMBNAIL_STORE, "readonly");
  const records = await requestResult(transaction.objectStore(THUMBNAIL_STORE).getAll());
  await transactionDone(transaction);
  let totalBytes = records.reduce((sum, record) => sum + (record.byteLength || 0), 0);
  if (records.length <= MAX_CACHE_ENTRIES && totalBytes <= MAX_CACHE_BYTES) return;

  records.sort((left, right) => (left.lastUsed || 0) - (right.lastUsed || 0));
  const remove = [];
  let remaining = records.length;
  for (const record of records) {
    if (remaining <= MAX_CACHE_ENTRIES && totalBytes <= MAX_CACHE_BYTES) break;
    remove.push(record.id);
    totalBytes -= record.byteLength || 0;
    remaining--;
  }
  if (!remove.length) return;
  const write = database.transaction(THUMBNAIL_STORE, "readwrite");
  const store = write.objectStore(THUMBNAIL_STORE);
  remove.forEach((id) => store.delete(id));
  await transactionDone(write);
}

export async function getCachedThumbnail(identity, passwordScope = "") {
  if (!globalThis.crypto?.subtle || !globalThis.indexedDB) return null;
  try {
    const database = await openDatabase();
    if (!database) return null;
    const id = await cacheRecordId(database, identity);
    const read = database.transaction(THUMBNAIL_STORE, "readonly");
    const record = await requestResult(read.objectStore(THUMBNAIL_STORE).get(id));
    await transactionDone(read);
    if (!record) return null;

    const key = await getThumbnailKey(database, passwordScope, new Uint8Array(record.salt || []));
    const plaintext = await crypto.subtle.decrypt(
      { name: "AES-GCM", iv: new Uint8Array(record.iv), additionalData: new TextEncoder().encode(id) },
      key,
      record.ciphertext
    );
    const touch = database.transaction(THUMBNAIL_STORE, "readwrite");
    touch.objectStore(THUMBNAIL_STORE).put({ ...record, lastUsed: Date.now() });
    await transactionDone(touch);
    return new Blob([plaintext], { type: record.type || "image/webp" });
  } catch {
    // A decrypt failure can mean a wrong archive password. Never delete the
    // existing record here: it may still be valid for the correct password.
    return null;
  }
}

async function makeThumbnail(sourceBlob) {
  if (typeof createImageBitmap !== "function" || typeof document === "undefined") return null;
  let bitmap;
  try {
    bitmap = await createImageBitmap(sourceBlob);
    if (!bitmap.width || !bitmap.height) return null;
    const scale = Math.min(1, MAX_WIDTH / bitmap.width, MAX_HEIGHT / bitmap.height);
    const width = Math.max(1, Math.round(bitmap.width * scale));
    const height = Math.max(1, Math.round(bitmap.height * scale));
    const canvas = document.createElement("canvas");
    canvas.width = width;
    canvas.height = height;
    const context = canvas.getContext("2d", { alpha: false });
    if (!context) return null;
    context.fillStyle = "#ffffff";
    context.fillRect(0, 0, width, height);
    context.drawImage(bitmap, 0, 0, width, height);
    return await new Promise((resolve) => {
      canvas.toBlob((blob) => resolve(blob), "image/webp", 0.78);
    });
  } catch {
    return null;
  } finally {
    bitmap?.close?.();
  }
}

export async function createAndCacheThumbnail(identity, sourceBlob, passwordScope = "") {
  const cached = await getCachedThumbnail(identity, passwordScope);
  if (cached) return cached;

  const thumbnail = await makeThumbnail(sourceBlob);
  if (!thumbnail) return sourceBlob;

  if (globalThis.crypto?.subtle && globalThis.indexedDB) {
    try {
      const database = await openDatabase();
      const id = await cacheRecordId(database, identity);
      const salt = passwordScope ? crypto.getRandomValues(new Uint8Array(16)) : new Uint8Array(0);
      const key = await getThumbnailKey(database, passwordScope, salt);
      const iv = crypto.getRandomValues(new Uint8Array(12));
      const bytes = await thumbnail.arrayBuffer();
      const ciphertext = await crypto.subtle.encrypt({ name: "AES-GCM", iv, additionalData: new TextEncoder().encode(id) }, key, bytes);
      const transaction = database.transaction(THUMBNAIL_STORE, "readwrite");
      transaction.objectStore(THUMBNAIL_STORE).put({
        id,
        iv: iv.buffer,
        salt: salt.buffer,
        ciphertext,
        type: thumbnail.type || "image/webp",
        byteLength: ciphertext.byteLength,
        lastUsed: Date.now()
      });
      await transactionDone(transaction);
      await trimCache(database);
    } catch {
      // Failure to cache must never prevent the user from viewing the source image.
    }
  }
  return thumbnail;
}

export async function getCachedThumbnailStats() {
  const database = await openDatabase();
  if (!database) return { usedBytes: 0, count: 0 };
  const transaction = database.transaction(THUMBNAIL_STORE, "readonly");
  const records = await requestResult(transaction.objectStore(THUMBNAIL_STORE).getAll());
  await transactionDone(transaction);
  return {
    usedBytes: records.reduce((sum, record) => sum + (record.byteLength || 0), 0),
    count: records.length
  };
}

export async function clearCachedThumbnails() {
  const database = await openDatabase();
  if (!database) return;
  const transaction = database.transaction(THUMBNAIL_STORE, "readwrite");
  transaction.objectStore(THUMBNAIL_STORE).clear();
  await transactionDone(transaction);
}

export async function getOrCreateThumbnail(identity, sourceBlob) {
  return createAndCacheThumbnail(identity, sourceBlob);
}

const DB_NAME = "aquvi-local-transfer";
const DB_VERSION = 2;
const TRANSFER_STORE = "transfers";
const CHUNK_STORE = "encrypted-chunks";
const KEY_STORE = "encryption-keys";
const PROFILE_KEY_ID = "archive-handoff-aes-gcm";
const MAX_AGE_MS = 30 * 60 * 1000;
const CHUNK_SIZE = 4 * 1024 * 1024;
const encoder = new TextEncoder();

function requestResult(request) {
  return new Promise((resolve, reject) => {
    request.onsuccess = () => resolve(request.result);
    request.onerror = () => reject(request.error || new Error("Local file handoff storage request failed."));
  });
}

function transactionDone(transaction) {
  return new Promise((resolve, reject) => {
    transaction.oncomplete = () => resolve();
    transaction.onabort = () => reject(transaction.error || new Error("Local file handoff transaction was cancelled."));
    transaction.onerror = () => reject(transaction.error || new Error("Local file handoff transaction failed."));
  });
}

function openDatabase() {
  if (!globalThis.indexedDB) {
    return Promise.reject(new Error("Encrypted local file handoff is unavailable because IndexedDB is disabled."));
  }
  return new Promise((resolve, reject) => {
    let blocked = false;
    const request = indexedDB.open(DB_NAME, DB_VERSION);
    request.onupgradeneeded = () => {
      const database = request.result;
      // Delete the old v1 store: it contained structured-cloned plaintext File objects.
      if (database.objectStoreNames.contains("selected-archives")) {
        database.deleteObjectStore("selected-archives");
      }
      if (!database.objectStoreNames.contains(TRANSFER_STORE)) {
        database.createObjectStore(TRANSFER_STORE, { keyPath: "id" });
      }
      if (!database.objectStoreNames.contains(CHUNK_STORE)) {
        const chunks = database.createObjectStore(CHUNK_STORE, { keyPath: ["transferId", "index"] });
        chunks.createIndex("transferId", "transferId", { unique: false });
      }
      if (!database.objectStoreNames.contains(KEY_STORE)) {
        database.createObjectStore(KEY_STORE, { keyPath: "id" });
      }
    };
    request.onsuccess = () => {
      const database = request.result;
      if (blocked) {
        database.close();
        return;
      }
      database.onversionchange = () => database.close();
      resolve(database);
    };
    request.onerror = () => reject(request.error || new Error("Could not open encrypted local file handoff storage."));
    request.onblocked = () => {
      blocked = true;
      reject(new Error("Encrypted local file handoff storage is blocked by another Aquvi tab. Close older Aquvi tabs and retry."));
    };
  });
}

async function getProfileKey(database) {
  // Generate outside the transaction; serialize the read-or-create decision in
  // one readwrite transaction so two extension tabs cannot replace each other's key.
  const generatedKey = await crypto.subtle.generateKey(
    { name: "AES-GCM", length: 256 },
    false,
    ["encrypt", "decrypt"]
  );
  return new Promise((resolve, reject) => {
    const transaction = database.transaction(KEY_STORE, "readwrite");
    const store = transaction.objectStore(KEY_STORE);
    let selectedKey = null;
    const request = store.get(PROFILE_KEY_ID);
    request.onsuccess = () => {
      if (request.result?.key) {
        selectedKey = request.result.key;
      } else {
        selectedKey = generatedKey;
        store.add({ id: PROFILE_KEY_ID, key: generatedKey });
      }
    };
    request.onerror = () => {
      try { transaction.abort(); } catch {/* The transaction may already be inactive. */}
    };
    transaction.oncomplete = () => {
      if (selectedKey) resolve(selectedKey);
      else reject(new Error("Could not initialize the archive handoff encryption key."));
    };
    transaction.onabort = () => reject(transaction.error || request.error || new Error("Could not initialize the archive handoff encryption key."));
    transaction.onerror = () => reject(transaction.error || new Error("Could not initialize the archive handoff encryption key."));
  });
}

function aadFor(transferId, size, purpose, index = 0) {
  return encoder.encode("aquvi-local-transfer:v2:" + transferId + ":" + size + ":" + purpose + ":" + index);
}

async function encryptBytes(key, transferId, size, purpose, index, bytes) {
  const iv = crypto.getRandomValues(new Uint8Array(12));
  const ciphertext = await crypto.subtle.encrypt({
    name: "AES-GCM",
    iv,
    additionalData: aadFor(transferId, size, purpose, index),
    tagLength: 128
  }, key, bytes);
  return { iv: iv.buffer, ciphertext };
}

async function decryptBytes(key, transferId, size, purpose, index, record) {
  if (!(record?.iv instanceof ArrayBuffer) || record.iv.byteLength !== 12 ||
      !(record?.ciphertext instanceof ArrayBuffer)) {
    throw new Error("The encrypted archive handoff record is invalid.");
  }
  return crypto.subtle.decrypt({
    name: "AES-GCM",
    iv: new Uint8Array(record.iv),
    additionalData: aadFor(transferId, size, purpose, index),
    tagLength: 128
  }, key, record.ciphertext);
}

async function putTransfer(database, record) {
  const transaction = database.transaction(TRANSFER_STORE, "readwrite");
  const done = transactionDone(transaction);
  transaction.objectStore(TRANSFER_STORE).put(record);
  await done;
}

async function putChunk(database, record) {
  const transaction = database.transaction([CHUNK_STORE, TRANSFER_STORE], "readwrite");
  const done = transactionDone(transaction);
  transaction.objectStore(CHUNK_STORE).put(record);
  const transfers = transaction.objectStore(TRANSFER_STORE);
  const request = transfers.get(record.transferId);
  request.onsuccess = () => {
    const transfer = request.result;
    if (transfer?.state === "writing") {
      transfer.updatedAt = Date.now();
      transfers.put(transfer);
    }
  };
  request.onerror = () => {
    try { transaction.abort(); } catch {/* The transaction may already be inactive. */}
  };
  await done;
}

async function getTransfer(database, id) {
  const transaction = database.transaction(TRANSFER_STORE, "readonly");
  const done = transactionDone(transaction);
  const record = await requestResult(transaction.objectStore(TRANSFER_STORE).get(id));
  await done;
  return record || null;
}

async function getChunk(database, transferId, index) {
  const transaction = database.transaction([CHUNK_STORE, TRANSFER_STORE], "readwrite");
  const done = transactionDone(transaction);
  const chunks = transaction.objectStore(CHUNK_STORE);
  const transfers = transaction.objectStore(TRANSFER_STORE);
  let chunk = null;
  const chunkRequest = chunks.get([transferId, index]);
  chunkRequest.onsuccess = () => { chunk = chunkRequest.result || null; };
  const transferRequest = transfers.get(transferId);
  transferRequest.onsuccess = () => {
    const transfer = transferRequest.result;
    if (transfer?.state === "consuming") {
      transfer.updatedAt = Date.now();
      transfers.put(transfer);
    }
  };
  await done;
  return chunk;
}

async function deleteTransfer(database, id) {
  const transaction = database.transaction([TRANSFER_STORE, CHUNK_STORE], "readwrite");
  const done = transactionDone(transaction);
  const transfers = transaction.objectStore(TRANSFER_STORE);
  const chunks = transaction.objectStore(CHUNK_STORE);
  const request = chunks.index("transferId").openCursor(IDBKeyRange.only(id));
  request.onsuccess = () => {
    const cursor = request.result;
    if (cursor) {
      cursor.delete();
      cursor.continue();
    } else {
      transfers.delete(id);
    }
  };
  request.onerror = () => {
    try { transaction.abort(); } catch {/* The transaction may already be inactive. */}
  };
  await done;
}

async function removeExpiredTransfers(database, now) {
  const transaction = database.transaction(TRANSFER_STORE, "readonly");
  const done = transactionDone(transaction);
  const records = await requestResult(transaction.objectStore(TRANSFER_STORE).getAll());
  await done;
  for (const record of records) {
    const lastActivity = Number.isFinite(record.updatedAt) ? record.updatedAt : record.createdAt;
    if (!lastActivity || lastActivity < now - MAX_AGE_MS) {
      await deleteTransfer(database, record.id);
    }
  }
}

async function markConsuming(database, id, now) {
  const transaction = database.transaction(TRANSFER_STORE, "readwrite");
  const done = transactionDone(transaction);
  const store = transaction.objectStore(TRANSFER_STORE);
  const record = await requestResult(store.get(id));
  let expired = false;
  if (!record || record.state !== "ready") {
    // A second viewer must not delete a handoff already claimed by the first.
    await done;
    return null;
  }
  const lastActivity = Number.isFinite(record.updatedAt) ? record.updatedAt : record.createdAt;
  if (!lastActivity || now - lastActivity > MAX_AGE_MS) {
    expired = true;
  } else {
    record.state = "consuming";
    record.updatedAt = now;
    store.put(record);
  }
  await done;
  if (expired) {
    await deleteTransfer(database, id);
    return null;
  }
  return record;
}

function createDecryptedBlobStream(database, key, record) {
  let index = 0;
  let emittedBytes = 0;
  const expectedChunks = Math.ceil(record.size / CHUNK_SIZE);
  return new ReadableStream({
    async pull(controller) {
      if (index >= expectedChunks) {
        if (emittedBytes !== record.size) {
          controller.error(new Error("The decrypted archive size does not match its handoff metadata."));
          return;
        }
        controller.close();
        return;
      }
      const currentIndex = index++;
      const chunk = await getChunk(database, record.id, currentIndex);
      if (!chunk || chunk.index !== currentIndex) {
        controller.error(new Error("An encrypted archive handoff chunk is missing."));
        return;
      }
      try {
        const plaintext = new Uint8Array(await decryptBytes(
          key, record.id, record.size, "chunk", currentIndex, chunk
        ));
        const expectedLength = Math.min(CHUNK_SIZE, record.size - emittedBytes);
        if (plaintext.byteLength !== expectedLength) {
          controller.error(new Error("An encrypted archive handoff chunk has an invalid length."));
          return;
        }
        emittedBytes += plaintext.byteLength;
        controller.enqueue(plaintext);
      } catch {
        controller.error(new Error("The temporary archive could not be authenticated. The handoff data may be damaged."));
      }
    },
    cancel() {
      // The consumer owns no persistent plaintext; stored ciphertext is removed
      // by consumeSelectedArchive's finally block.
    }
  });
}


/**
 * Open the v2 store at extension startup. This also removes the legacy v1
 * plaintext File object store during the IndexedDB version upgrade and sweeps
 * expired / abandoned ciphertext records.
 */
export async function initializeSecureHandoffStorage() {
  const database = await openDatabase();
  try {
    await removeExpiredTransfers(database, Date.now());
  } finally {
    database.close();
  }
}

/**
 * Store the selected archive as independently authenticated AES-GCM chunks.
 * Only one 4 MiB plaintext slice is held by this function at a time.
 */
export async function storeSelectedArchive(file) {
  if (!file || typeof file.slice !== "function" || !Number.isSafeInteger(file.size) || file.size < 0) {
    throw new Error("A valid local archive was not selected.");
  }
  if (!globalThis.crypto?.subtle || typeof ReadableStream !== "function" || typeof Response !== "function") {
    throw new Error("This browser cannot securely hand off the selected archive. No unencrypted copy was saved.");
  }

  const database = await openDatabase();
  const id = crypto.randomUUID();
  const now = Date.now();
  const size = file.size;
  const chunkCount = Math.ceil(size / CHUNK_SIZE);
  let recordCreated = false;

  try {
    await removeExpiredTransfers(database, now);
    const key = await getProfileKey(database);
    const metadata = {
      name: file.name || "archive.zip",
      type: file.type || "application/octet-stream",
      lastModified: Number.isFinite(file.lastModified) ? file.lastModified : now
    };
    const metadataBytes = encoder.encode(JSON.stringify(metadata));
    const encryptedMetadata = await encryptBytes(key, id, size, "metadata", 0, metadataBytes);

    await putTransfer(database, {
      id,
      state: "writing",
      updatedAt: now,
      size,
      chunkCount,
      createdAt: now,
      metadataIv: encryptedMetadata.iv,
      metadataCiphertext: encryptedMetadata.ciphertext
    });
    recordCreated = true;

    for (let index = 0; index < chunkCount; index++) {
      const start = index * CHUNK_SIZE;
      const end = Math.min(size, start + CHUNK_SIZE);
      const plaintext = new Uint8Array(await file.slice(start, end).arrayBuffer());
      try {
        if (plaintext.byteLength !== end - start) {
          throw new Error("The selected archive could not be read completely for secure handoff.");
        }
        const encrypted = await encryptBytes(key, id, size, "chunk", index, plaintext);
        await putChunk(database, {
          transferId: id,
          index,
          iv: encrypted.iv,
          ciphertext: encrypted.ciphertext
        });
      } finally {
        // Best effort only: Web Crypto and the browser may retain internal copies.
        plaintext.fill(0);
      }
    }

    const completedAt = Date.now();
    await putTransfer(database, { ...(await getTransfer(database, id)), state: "ready", readyAt: completedAt, updatedAt: completedAt });
    return id;
  } catch (error) {
    if (recordCreated) {
      try { await deleteTransfer(database, id); } catch {/* Expiry cleanup will remove any incomplete residue. */}
    }
    throw error;
  } finally {
    database.close();
  }
}

/**
 * Consume a one-time handoff and reconstruct a normal File for existing archive
 * readers. Decryption is streamed chunk-by-chunk into a browser-managed Blob,
 * preserving the standard File.slice() and Worker structured-clone interfaces.
 */
export async function consumeSelectedArchive(id) {
  if (!id) return null;
  if (!globalThis.crypto?.subtle || typeof ReadableStream !== "function" || typeof Response !== "function") {
    throw new Error("This browser cannot securely restore the selected archive.");
  }

  const database = await openDatabase();
  let record = null;
  try {
    record = await markConsuming(database, id, Date.now());
    if (!record) return null;
    const key = await getProfileKey(database);
    const metadataRecord = {
      iv: record.metadataIv,
      ciphertext: record.metadataCiphertext
    };
    const metadataBytes = await decryptBytes(key, id, record.size, "metadata", 0, metadataRecord);
    let metadata;
    try {
      metadata = JSON.parse(new TextDecoder().decode(metadataBytes));
    } catch {
      throw new Error("The encrypted archive handoff metadata is invalid.");
    }
    if (!metadata || typeof metadata.name !== "string" || typeof metadata.type !== "string" ||
        !Number.isFinite(metadata.lastModified) || !Number.isSafeInteger(record.size) || record.size < 0 ||
        record.chunkCount !== Math.ceil(record.size / CHUNK_SIZE)) {
      throw new Error("The encrypted archive handoff metadata is incomplete.");
    }

    const blob = await new Response(createDecryptedBlobStream(database, key, record)).blob();
    if (blob.size !== record.size) {
      throw new Error("The decrypted archive does not match the original file size.");
    }
    return new File([blob], metadata.name, {
      type: metadata.type,
      lastModified: metadata.lastModified
    });
  } finally {
    if (record) {
      try { await deleteTransfer(database, id); } catch {/* Never reuse a claimed transfer; expiry cleanup is the fallback. */}
    }
    database.close();
  }
}

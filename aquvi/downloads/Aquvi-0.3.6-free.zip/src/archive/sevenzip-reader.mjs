import { isSupportedArchiveImage } from "./sevenzip-listing.mjs";

const MAX_IMAGE_BYTES = 64 * 1024 * 1024;
export class SevenZipArchiveError extends Error {
  constructor(message, code = "SEVENZIP_ERROR") {
    super(message);
    this.name = "SevenZipArchiveError";
    this.code = code;
  }
}

export class SevenZipArchive {
  constructor(file, worker) {
    this.file = file;
    this.fileName = file.name || "archive.7z";
    this.worker = worker;
    this.entries = [];
    this.closed = false;
    this.password = null;
    this.nextRequestId = 1;
    this.pending = new Map();

    worker.addEventListener("message", (event) => {
      const message = event.data || {};
      const pending = this.pending.get(message.id);
      if (!pending) return;
      this.pending.delete(message.id);
      if (message.ok) pending.resolve(message);
      else pending.reject(new SevenZipArchiveError(
        message.error?.message || "7zの処理に失敗しました。",
        message.error?.code || "ARCHIVE_ERROR"
      ));
    });
    worker.addEventListener("error", () => {
      for (const pending of this.pending.values()) {
        pending.reject(new SevenZipArchiveError("7z Worker が停止しました。", "WORKER_FAILED"));
      }
      this.pending.clear();
    });
  }

  static async open(file, options = {}) {
    const worker = new Worker(
      new URL("../workers/sevenzip-worker.mjs", import.meta.url),
      { type: "module", name: "aquvi-7zip-reader" }
    );
    const archive = new SevenZipArchive(file, worker);
    let password = options.password || null;
    let retry = Boolean(password);
    try {
      while (true) {
        try {
          const result = await archive.request("open", { file, password });
          archive.entries = result.entries;
          archive.password = password;
          return archive;
        } catch (error) {
          if (error?.code !== "PASSWORD_REQUIRED" && error?.code !== "BAD_PASSWORD") throw error;
          if (typeof options.requestPassword !== "function") throw error;
          password = await options.requestPassword(retry);
          if (password === null) {
            throw new SevenZipArchiveError("パスワード入力をキャンセルしました。", "PASSWORD_CANCELLED");
          }
          retry = true;
        }
      }
    } catch (error) {
      await archive.close();
      throw error;
    }
  }

  get imageEntries() {
    return this.entries.filter((entry) => isSupportedArchiveImage(entry.name));
  }

  getEntryAvailability(entry) {
    if (this.closed || !this.worker) return "アーカイブは閉じられています。";
    if (!entry || !isSupportedArchiveImage(entry.name)) return "対応していない画像形式です。";
    if (entry.duplicatePath) return "同じパスのファイルが複数あるため、この項目を区別できません。";
    if (!Number.isSafeInteger(entry.size) || entry.size < 0 || entry.size > MAX_IMAGE_BYTES) {
      return "画像が現在の64 MiB上限を超えています。";
    }
    return null;
  }

  async request(type, payload = {}) {
    if (this.closed || !this.worker) {
      throw new SevenZipArchiveError("アーカイブは閉じられています。", "ARCHIVE_CLOSED");
    }
    const id = this.nextRequestId++;
    return new Promise((resolve, reject) => {
      this.pending.set(id, { resolve, reject });
      try {
        this.worker.postMessage({ id, type, ...payload });
      } catch (error) {
        this.pending.delete(id);
        reject(error);
      }
    });
  }

  async readEntry(entry, options = {}) {
    if (this.closed) throw new SevenZipArchiveError("アーカイブは閉じられています。", "ARCHIVE_CLOSED");
    const unavailable = this.getEntryAvailability(entry);
    if (unavailable) throw new SevenZipArchiveError(unavailable, "UNSUPPORTED_ENTRY");

    const password = options.password ?? this.password;
    if (entry.encrypted && !password) {
      throw new SevenZipArchiveError("この画像を開くにはパスワードが必要です。", "PASSWORD_REQUIRED");
    }
    try {
      const result = await this.request("read", {
        entry: { id: entry.id, name: entry.name, size: entry.size },
        password: password || null
      });
      if (!(result.data instanceof ArrayBuffer) || result.data.byteLength > MAX_IMAGE_BYTES) {
        throw new SevenZipArchiveError("7zの展開結果が不正です。", "INVALID_OUTPUT");
      }
      if (password) this.password = password;
      const data = new Uint8Array(result.data);
      return data;
    } catch (error) {
      if (error.code === "BAD_PASSWORD") {
        this.password = null;
      }
      throw error;
    }
  }

  async close() {
    if (this.closed) return;
    this.closed = true;
    const worker = this.worker;
    this.worker = null;
    for (const pending of this.pending.values()) {
      pending.reject(new SevenZipArchiveError("アーカイブは閉じられています。", "ARCHIVE_CLOSED"));
    }
    this.pending.clear();
    worker?.terminate();
    this.file = null;
    this.entries = [];
    this.password = null;
  }
}

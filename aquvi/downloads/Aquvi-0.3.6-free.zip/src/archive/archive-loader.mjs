import { detectArchiveFormat, getArchiveFormatLabel } from "./format-detect.mjs";
import {
  ACTIVE_EDITION,
  isArchiveFormatIncluded,
  isZipFallbackMethodIncluded,
  getEditionRestrictedMessage
} from "../config/edition-profile.mjs";

export class ArchiveOpenError extends Error {
  constructor(message, code, format = "unknown") {
    super(message);
    this.name = "ArchiveOpenError";
    this.code = code;
    this.format = format;
  }
}

function editionRestricted(format, detail = "") {
  const message = getEditionRestrictedMessage(format);
  return new ArchiveOpenError(detail ? `${message} ${detail}` : message, "EDITION_RESTRICTED", format);
}

/**
 * Import archive engines only after a file has been selected and its container
 * has been identified. The active edition profile is enforced before loading
 * any reader so excluded formats cannot be opened through the UI route.
 */
export async function openArchiveFile(file, options = {}) {
  const format = await detectArchiveFormat(file);

  if (format === "unknown") {
    throw new ArchiveOpenError(
      "ファイル形式を判別できませんでした。対応するアーカイブを選択してください。",
      "UNKNOWN_FORMAT",
      format
    );
  }

  if (!isArchiveFormatIncluded(format, ACTIVE_EDITION)) {
    throw editionRestricted(format);
  }

  if (format === "zip") {
    const { ZipArchive } = await import("./zip.js");
    let archive;
    try {
      archive = await ZipArchive.open(file, options);
    } catch (error) {
      if (error?.code === "ZIP64_UNSUPPORTED") {
        throw editionRestricted("zip", "ZIP64はプレミアム版向けの拡張対象です。");
      }
      throw error;
    }

    const unsupportedEntries = archive.imageEntries.filter((entry) => {
      const unavailable = archive.getEntryAvailability(entry) || "";
      return unavailable.startsWith("ZIP compression method ") ||
        unavailable.startsWith("ZIP AES compression method ");
    });

    const premiumEntries = unsupportedEntries.filter((entry) =>
      !isZipFallbackMethodIncluded(entry.actualMethod ?? entry.method, ACTIVE_EDITION)
    );
    if (premiumEntries.length) {
      archive.close();
      throw editionRestricted(
        "zip",
        "このアーカイブにはFreeで扱わないZIP圧縮方式が含まれています。"
      );
    }

    if (!unsupportedEntries.length) {
      archive.format = format;
      archive.edition = ACTIVE_EDITION;
      return archive;
    }

    // Free allows the full-format fallback only for BZIP2-compressed ZIP
    // entries. Other method IDs remain outside the Free capability profile.
    const { MultiFormatArchive } = await import("./multiformat-reader.mjs");
    await archive.close();
    const fallback = await MultiFormatArchive.open(file, options);
    fallback.format = format;
    fallback.edition = ACTIVE_EDITION;
    fallback.engineFallback = "zip-bzip2";
    return fallback;
  }

  if (format === "sevenZip") {
    const { SevenZipArchive } = await import("./sevenzip-reader.mjs");
    const archive = await SevenZipArchive.open(file, options);
    archive.format = format;
    archive.edition = ACTIVE_EDITION;
    return archive;
  }

  if (format === "tar") {
    const { MultiFormatArchive } = await import("./multiformat-reader.mjs");
    const archive = await MultiFormatArchive.open(file, options);
    archive.format = format;
    archive.edition = ACTIVE_EDITION;
    return archive;
  }

  throw new ArchiveOpenError(
    `${getArchiveFormatLabel(format)}形式の閲覧エンジンはまだ組み込まれていません。`,
    "ENGINE_NOT_READY",
    format
  );
}

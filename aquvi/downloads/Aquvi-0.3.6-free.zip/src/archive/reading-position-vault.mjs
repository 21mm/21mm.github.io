const DATABASE_NAME = "aquvi-reading-position-vault";
const DATABASE_VERSION = 1;
const KEY_STORE = "keys";
const POSITION_STORE = "positions";
const ENCRYPTION_KEY_ID = "reading-position-aes-gcm";
const IDENTITY_KEY_ID = "reading-position-hmac";

function openDatabase() {
  return new Promise((resolve, reject) => {
    const request = indexedDB.open(DATABASE_NAME, DATABASE_VERSION);
    request.onupgradeneeded = () => {
      const db = request.result;
      if (!db.objectStoreNames.contains(KEY_STORE)) db.createObjectStore(KEY_STORE, { keyPath: "id" });
      if (!db.objectStoreNames.contains(POSITION_STORE)) db.createObjectStore(POSITION_STORE, { keyPath: "id" });
    };
    request.onsuccess = () => {
      const db = request.result;
      db.onversionchange = () => db.close();
      resolve(db);
    };
    request.onerror = () => reject(request.error || new Error("読書位置の保存領域を開けませんでした。"));
  });
}

function requestResult(request) {
  return new Promise((resolve, reject) => {
    request.onsuccess = () => resolve(request.result);
    request.onerror = () => reject(request.error || new Error("読書位置の読み込みに失敗しました。"));
  });
}

function transactionDone(tx) {
  return new Promise((resolve, reject) => {
    tx.oncomplete = resolve;
    tx.onabort = () => reject(tx.error || new Error("読書位置の保存に失敗しました。"));
    tx.onerror = () => reject(tx.error || new Error("読書位置の保存に失敗しました。"));
  });
}

async function getKey(db, id, algorithm, usages) {
  const readStored = async () => {
    const tx = db.transaction(KEY_STORE, "readonly");
    const record = await requestResult(tx.objectStore(KEY_STORE).get(id));
    await transactionDone(tx);
    return record?.key || null;
  };
  const existing = await readStored();
  if (existing) return existing;
  const generated = await crypto.subtle.generateKey(algorithm, false, usages);
  try {
    const write = db.transaction(KEY_STORE, "readwrite");
    write.objectStore(KEY_STORE).add({ id, key: generated });
    await transactionDone(write);
  } catch {
    // Another Aquvi tab may have created the profile key first.
  }
  const selected = await readStored();
  if (!selected) throw new Error("読書位置の暗号化キーを初期化できませんでした。");
  return selected;
}

async function positionId(db, identity) {
  const key = await getKey(db, IDENTITY_KEY_ID, { name: "HMAC", hash: "SHA-256", length: 256 }, ["sign"]);
  const digest = await crypto.subtle.sign("HMAC", key, new TextEncoder().encode(String(identity || "")));
  return Array.from(new Uint8Array(digest), byte => byte.toString(16).padStart(2, "0")).join("");
}

export async function loadReadingPosition(identity) {
  if (!identity || !globalThis.crypto?.subtle || !globalThis.indexedDB) return null;
  const db = await openDatabase();
  try {
    const id = await positionId(db, identity);
    const read = db.transaction(POSITION_STORE, "readonly");
    const record = await requestResult(read.objectStore(POSITION_STORE).get(id));
    await transactionDone(read);
    if (!record) return null;
    const key = await getKey(db, ENCRYPTION_KEY_ID, { name: "AES-GCM", length: 256 }, ["encrypt", "decrypt"]);
    const plaintext = await crypto.subtle.decrypt({ name: "AES-GCM", iv: new Uint8Array(record.iv), additionalData: new TextEncoder().encode(id) }, key, record.ciphertext);
    return JSON.parse(new TextDecoder().decode(plaintext));
  } catch {
    return null;
  } finally {
    db.close();
  }
}

export async function saveReadingPosition(identity, value) {
  if (!identity || !globalThis.crypto?.subtle || !globalThis.indexedDB) return false;
  const db = await openDatabase();
  try {
    const id = await positionId(db, identity);
    const key = await getKey(db, ENCRYPTION_KEY_ID, { name: "AES-GCM", length: 256 }, ["encrypt", "decrypt"]);
    const iv = crypto.getRandomValues(new Uint8Array(12));
    const plaintext = new TextEncoder().encode(JSON.stringify(value));
    const ciphertext = await crypto.subtle.encrypt({ name: "AES-GCM", iv, additionalData: new TextEncoder().encode(id) }, key, plaintext);
    const write = db.transaction(POSITION_STORE, "readwrite");
    write.objectStore(POSITION_STORE).put({ id, iv: iv.buffer, ciphertext, updatedAt: Date.now() });
    await transactionDone(write);
    return true;
  } finally {
    db.close();
  }
}

export async function clearReadingPositions() {
  if (!globalThis.indexedDB) return;
  const db = await openDatabase();
  try {
    const tx = db.transaction(POSITION_STORE, "readwrite");
    tx.objectStore(POSITION_STORE).clear();
    await transactionDone(tx);
  } finally {
    db.close();
  }
}

export function removeLegacyReadingPositions(storage = globalThis.localStorage) {
  if (!storage) return 0;
  const keys = [];
  for (let i = 0; i < storage.length; i++) {
    const key = storage.key(i);
    if (key?.startsWith("aquvi.reading-position.")) keys.push(key);
  }
  for (const key of keys) storage.removeItem(key);
  return keys.length;
}

export const VIEW_MODES = Object.freeze(["single", "pair", "split"]);

export function buildPageViews(entries, mode = "single", pageShifted = false, direction = "rtl") {
  const pages = entries.map((entry, index) => ({ entry, index, side: null }));
  if (mode === "pair") {
    const views = [];
    let cursor = 0;
    if (pageShifted && pages.length) {
      views.push({ kind: "single", pages: [pages[0]] });
      cursor = 1;
    }
    while (cursor < pages.length) {
      const group = pages.slice(cursor, cursor + 2);
      views.push({ kind: group.length === 2 ? "pair" : "single", pages: group });
      cursor += group.length;
    }
    return views;
  }
  if (mode === "split") {
    const sides = direction === "ltr" ? ["left", "right"] : ["right", "left"];
    return pages.flatMap((page) => sides.map((side) => ({ kind: "split", pages: [{ ...page, side }] })));
  }
  return pages.map((page) => ({ kind: "single", pages: [page] }));
}

export function findViewIndexForImage(views, imageIndex, preferredSide = null) {
  if (!Array.isArray(views) || imageIndex < 0) return 0;
  if (preferredSide) {
    const exact = views.findIndex((view) => view.pages.some((page) => page.index === imageIndex && page.side === preferredSide));
    if (exact >= 0) return exact;
  }
  const index = views.findIndex((view) => view.pages.some((page) => page.index === imageIndex));
  return index >= 0 ? index : 0;
}

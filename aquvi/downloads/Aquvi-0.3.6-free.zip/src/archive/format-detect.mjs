const FORMAT_LABELS = Object.freeze({
  zip: "ZIP / CBZ",
  sevenZip: "7z",
  rar: "RAR / CBR",
  tar: "TAR / PAX",
  gzip: "GZIP / CPGZ",
  bzip2: "BZIP2",
  xz: "XZ",
  lzma: "LZMA",
  zstd: "Zstandard",
  lzip: "LZIP",
  lz4: "LZ4",
  snappy: "Snappy",
  lrzip: "LRZIP",
  brotli: "Brotli",
  cab: "CAB",
  iso: "ISO",
  dmg: "DMG",
  wim: "WIM",
  msi: "MSI",
  exe: "EXE / 自己解凍形式",
  pax: "PAX",
  appleArchive: "Apple Archive",
  cpgz: "CPGZ",
  is3: "IS3",
  cpt: "CPT",
  spk: "SPK",
  lha: "LHA / LZH",
  xar: "XAR",
  ar: "AR",
  cpio: "CPIO",
  unknown: "不明な形式"
});

const EXTENSION_FORMATS = new Map([
  ["zip", "zip"], ["zipx", "zip"], ["cbz", "zip"], ["epub", "zip"], ["apk", "zip"],
  ["xpi", "zip"], ["jar", "zip"], ["war", "zip"], ["ipa", "zip"], ["appx", "zip"],
  ["wpress", "zip"], ["wacz", "zip"],
  ["7z", "sevenZip"],
  ["rar", "rar"], ["cbr", "rar"],
  ["tar", "tar"], ["tgz", "gzip"], ["gz", "gzip"], ["cpgz", "cpgz"],
  ["tbz", "bzip2"], ["tbz2", "bzip2"], ["bz2", "bzip2"], ["bz", "bzip2"],
  ["txz", "xz"], ["xz", "xz"], ["lzma", "lzma"],
  ["tzst", "zstd"], ["zst", "zstd"], ["zstd", "zstd"],
  ["lz", "lzip"], ["lzip", "lzip"], ["br", "brotli"], ["brotli", "brotli"],
  ["lz4", "lz4"], ["snappy", "snappy"], ["lrzip", "lrzip"],
  ["cab", "cab"], ["iso", "iso"], ["dmg", "dmg"], ["wim", "wim"],
  ["lha", "lha"], ["lzh", "lha"], ["xar", "xar"], ["xip", "xar"],
  ["ar", "ar"], ["cpio", "cpio"], ["pax", "tar"], ["exe", "exe"], ["msi", "msi"],
  ["aar", "appleArchive"], ["is3", "is3"], ["cpt", "cpt"], ["spk", "spk"]
]);

function asciiAt(bytes, offset, value) {
  if (offset < 0 || offset + value.length > bytes.length) return false;
  for (let index = 0; index < value.length; index++) {
    if (bytes[offset + index] !== value.charCodeAt(index)) return false;
  }
  return true;
}

function startsWith(bytes, signature) {
  if (bytes.length < signature.length) return false;
  return signature.every((byte, index) => bytes[index] === byte);
}

function extensionOf(name) {
  const filename = String(name || "").toLowerCase().split(/[\\/]/).pop() || "";
  if (filename.endsWith(".tar.gz")) return "gz";
  if (filename.endsWith(".tar.bz2")) return "bz2";
  if (filename.endsWith(".tar.xz")) return "xz";
  const dot = filename.lastIndexOf(".");
  return dot >= 0 ? filename.slice(dot + 1) : "";
}

export function getArchiveFormatLabel(format) {
  return FORMAT_LABELS[format] || FORMAT_LABELS.unknown;
}

/**
 * Identify a container from its signature first, using the filename only as a
 * fallback. Normal files require only a 512-byte header read.
 */
export async function detectArchiveFormat(file) {
  if (!file || typeof file.slice !== "function" || !Number.isFinite(file.size) || file.size < 1) {
    throw new TypeError("A non-empty archive File or Blob is required.");
  }

  const head = new Uint8Array(await file.slice(0, Math.min(file.size, 512)).arrayBuffer());

  if (
    startsWith(head, [0x50, 0x4b, 0x03, 0x04]) ||
    startsWith(head, [0x50, 0x4b, 0x05, 0x06]) ||
    startsWith(head, [0x50, 0x4b, 0x07, 0x08])
  ) return "zip";

  if (startsWith(head, [0x37, 0x7a, 0xbc, 0xaf, 0x27, 0x1c])) return "sevenZip";
  if (startsWith(head, [0x52, 0x61, 0x72, 0x21, 0x1a, 0x07, 0x00])) return "rar";
  if (startsWith(head, [0x52, 0x61, 0x72, 0x21, 0x1a, 0x07, 0x01, 0x00])) return "rar";
  if (startsWith(head, [0x1f, 0x8b])) return "gzip";
  if (asciiAt(head, 0, "BZh")) return "bzip2";
  if (startsWith(head, [0xfd, 0x37, 0x7a, 0x58, 0x5a, 0x00])) return "xz";
  if (startsWith(head, [0x28, 0xb5, 0x2f, 0xfd])) return "zstd";
  if (startsWith(head, [0x04, 0x22, 0x4d, 0x18])) return "lz4";
  if (asciiAt(head, 0, "LZIP")) return "lzip";
  if (startsWith(head, [0x4d, 0x53, 0x43, 0x46])) return "cab";
  if (startsWith(head, [0x4d, 0x53, 0x57, 0x49, 0x4d, 0x00, 0x00, 0x00])) return "wim";
  if (asciiAt(head, 0, "xar!")) return "xar";
  if (asciiAt(head, 0, "!<arch>\n")) return "ar";
  if (asciiAt(head, 0, "070701") || asciiAt(head, 0, "070702") || asciiAt(head, 0, "070707")) return "cpio";
  if (asciiAt(head, 257, "ustar")) return "tar";
  if (asciiAt(head, 2, "-lh") || asciiAt(head, 2, "-lz")) return "lha";

  const extension = extensionOf(file.name);
  const extensionFormat = EXTENSION_FORMATS.get(extension);

  if (extensionFormat === "iso" && file.size > 0x8006) {
    const descriptor = new Uint8Array(await file.slice(0x8001, 0x8006).arrayBuffer());
    if (asciiAt(descriptor, 0, "CD001")) return "iso";
  }

  if (extensionFormat === "dmg" && file.size >= 512) {
    const footer = new Uint8Array(await file.slice(file.size - 512, file.size).arrayBuffer());
    if (asciiAt(footer, 0, "koly")) return "dmg";
  }

  if (extensionFormat === "msi" && startsWith(head, [0xd0, 0xcf, 0x11, 0xe0])) return "msi";
  if (extensionFormat === "exe" && asciiAt(head, 0, "MZ")) return "exe";

  // Extension-only containers are hints until a format-specific parser validates them.
  return extensionFormat || "unknown";
}

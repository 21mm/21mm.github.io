/**
 * Return a transferable buffer without copying when the Uint8Array already
 * spans its complete ArrayBuffer. A partial view must be copied so unrelated
 * bytes from the backing allocation are never transferred.
 */
export function toTransferableArrayBuffer(view) {
  if (!(view instanceof Uint8Array)) {
    throw new TypeError("Expected a Uint8Array.");
  }
  if (view.buffer instanceof ArrayBuffer && view.byteOffset === 0 && view.byteLength === view.buffer.byteLength) {
    return view.buffer;
  }
  return view.slice().buffer;
}
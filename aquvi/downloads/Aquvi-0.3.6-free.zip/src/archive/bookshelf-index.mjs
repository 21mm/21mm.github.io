import { createFolderIdentity } from "./folder-reader.mjs";

const IMAGE_EXTENSIONS = new Set(["jpg", "jpeg", "png", "gif", "webp", "avif", "bmp"]);
const COLLATOR = new Intl.Collator("ja", { numeric: true, sensitivity: "base" });
const ARCHIVE_EXTENSIONS = new Set(["zip", "cbz", "7z", "tar"]);

export function isBookshelfImage(file) {
  if (isIgnoredBookshelfFile(file)) return false;
  const name = String(file?.name || "");
  const dot = name.lastIndexOf(".");
  return dot > 0 && IMAGE_EXTENSIONS.has(name.slice(dot + 1).toLowerCase());
}

function archiveExtension(file) {
  const name = String(file?.name || "");
  const dot = name.lastIndexOf(".");
  if (dot <= 0) return "";
  const extension = name.slice(dot + 1).toLowerCase();
  return ARCHIVE_EXTENSIONS.has(extension) ? extension : "";
}

function makeArchiveBook(node, file) {
  const extension = archiveExtension(file);
  return {
    kind: "archiveBook",
    name: file.name.slice(0, -(extension.length + 1)),
    path: node.path.join("/"),
    file,
    format: extension
  };
}

function splitRelativePath(path) {
  return String(path || "").split("/").filter(Boolean);
}

const IGNORED_NAMES = new Set([
  ".ds_store",
  "thumbs.db",
  "desktop.ini",
  "ehthumbs.db"
]);

/**
 * Ignore conventional hidden files and OS metadata at every directory level.
 * File objects do not expose the platform's hidden attribute consistently,
 * so this covers dotfiles and well-known Finder/Explorer metadata names.
 */
export function isIgnoredBookshelfFile(file) {
  const relativeParts = splitRelativePath(file?.webkitRelativePath);
  const name = String(file?.name || "");
  const parts = [...relativeParts, name];
  return parts.some((part) => {
    const normalized = String(part).toLowerCase();
    return normalized.startsWith(".") ||
      normalized === "__macosx" ||
      IGNORED_NAMES.has(normalized);
  });
}

function makeFolder(name, path) {
  return { name, path, folders: new Map(), files: [] };
}

export function buildBookshelfIndex(fileList) {
  const files = Array.from(fileList || []).filter((file) => !isIgnoredBookshelfFile(file));
  const firstPath = files.map((file) => splitRelativePath(file.webkitRelativePath)).find((parts) => parts.length >= 2);
  if (!firstPath) throw new Error("本棚フォルダ内のファイル情報を取得できませんでした。フォルダを選び直してください。");

  const rootName = firstPath[0];
  const root = makeFolder(rootName, [rootName]);
  let accepted = 0;

  for (const file of files) {
    const parts = splitRelativePath(file.webkitRelativePath);
    if (parts.length < 2 || parts[0] !== rootName) continue;

    let current = root;
    for (const segment of parts.slice(1, -1)) {
      if (!current.folders.has(segment)) {
        current.folders.set(segment, makeFolder(segment, [...current.path, segment]));
      }
      current = current.folders.get(segment);
    }
    current.files.push(file);
    accepted++;
  }

  if (!accepted) throw new Error("本棚フォルダにファイルがありません。");
  return { root, fileCount: accepted, rootName };
}

export function getBookshelfNode(index, path = []) {
  let node = index?.root || null;
  const segments = path.length && path[0] === node?.name ? path.slice(1) : path;
  for (const segment of segments) {
    node = node?.folders.get(segment) || null;
    if (!node) return null;
  }
  return node;
}

function makeBook(node, images, name = node.name) {
  const files = images.slice().sort((left, right) =>
    COLLATOR.compare(left.name, right.name) ||
    (left.lastModified || 0) - (right.lastModified || 0)
  );
  return {
    kind: "book",
    name,
    path: node.path.join("/"),
    files,
    identity: createFolderIdentity(files, node.path.join("/"))
  };
}

/**
 * Folder cards navigate deeper and never receive a cover.
 * A leaf folder with supported direct-child images becomes a book card.
 * Direct images alongside subfolders form a separate "folder images" book.
 */
export function listBookshelfItems(index, path = []) {
  const node = getBookshelfNode(index, path);
  if (!node) return [];

  const folders = Array.from(node.folders.values());
  const items = [];
  const directImages = node.files.filter(isBookshelfImage);
  const archiveFiles = node.files.filter((file) => archiveExtension(file));

  if (directImages.length && (folders.length || archiveFiles.length || node === index.root)) {
    const label = node === index.root && folders.length === 0
      ? node.name
      : "このフォルダの画像";
    items.push(makeBook(node, directImages, label));
  }
  for (const file of archiveFiles) items.push(makeArchiveBook(node, file));

  for (const child of folders) {
    const images = child.files.filter(isBookshelfImage);
    const childArchives = child.files.filter((file) => archiveExtension(file));
    if (child.folders.size > 0 || childArchives.length > 0) {
      items.push({
        kind: "folder",
        name: child.name,
        path: child.path.join("/"),
        folder: child
      });
    } else if (images.length > 0) {
      items.push(makeBook(child, images));
    }
  }

  const folderItems = items.filter((item) => item.kind === "folder")
    .sort((a, b) => COLLATOR.compare(a.name, b.name));
  const bookItems = items.filter((item) => item.kind === "book")
    .sort((a, b) => COLLATOR.compare(a.name, b.name));
  const archiveItems = items.filter((item) => item.kind === "archiveBook")
    .sort((a, b) => COLLATOR.compare(a.name, b.name));
  // Books and archive files that sit beside one another belong to the same
  // reading series. Keep them in one natural-order volume sequence.
  const volumes = [...bookItems, ...archiveItems]
    .sort((a, b) => COLLATOR.compare(a.name, b.name) || a.kind.localeCompare(b.kind));
  volumes.forEach((item, index) => {
    item.seriesPath = node.path.slice(1);
    item.seriesIndex = index;
    item.seriesLength = volumes.length;
  });
  return [...folderItems, ...volumes];
}

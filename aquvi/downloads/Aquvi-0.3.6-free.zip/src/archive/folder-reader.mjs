const IMAGE_EXTENSIONS = new Set(["jpg", "jpeg", "png", "gif", "webp", "avif", "bmp"]);
const COLLATOR = new Intl.Collator("ja", { numeric: true, sensitivity: "base" });
const MAX_IMAGE_BYTES = 64 * 1024 * 1024;

function isImageName(name) {
  const leaf = String(name || "").split("/").pop() || "";
  const dot = leaf.lastIndexOf(".");
  return dot > 0 && IMAGE_EXTENSIONS.has(leaf.slice(dot + 1).toLowerCase());
}

function splitPath(path) {
  return String(path || "").split("/").filter(Boolean);
}

export function selectTopLevelFolderImages(files, folderPath = "") {
  const prefix = splitPath(folderPath);
  return Array.from(files || []).filter((file) => {
    if (!file || typeof file.slice !== "function" || !isImageName(file.name)) return false;
    const relativePath = String(file.webkitRelativePath || "");
    if (!relativePath) return true;
    const parts = splitPath(relativePath);
    return parts.length === prefix.length + 1 &&
      prefix.every((part, index) => parts[index] === part);
  }).sort((left, right) =>
    COLLATOR.compare(left.name, right.name) ||
    (left.lastModified || 0) - (right.lastModified || 0)
  );
}

function identityFromSelected(selected, folderPath) {
  const size = selected.reduce((sum, file) => sum + file.size, 0);
  const lastModified = selected.reduce((max, file) => Math.max(max, file.lastModified || 0), 0);
  const signature = selected.map((file) =>
    file.name + ":" + file.size + ":" + (file.lastModified || 0)
  ).join("|");
  return {
    name: "folder:" + folderPath + ":" + signature,
    size,
    lastModified
  };
}

export function createFolderIdentity(files, folderPath = "") {
  return identityFromSelected(selectTopLevelFolderImages(files, folderPath), folderPath);
}

export function createFolderArchive(files, folderName = "フォルダ", folderPath = "") {
  const selected = selectTopLevelFolderImages(files, folderPath);
  const entries = selected.map((file, id) => ({
    id,
    name: file.name,
    size: file.size,
    file,
    encrypted: false,
    isDirectory: false
  }));
  let closed = false;

  return {
    fileName: folderName,
    identity: identityFromSelected(selected, folderPath),
    entries,
    imageEntries: entries,
    getEntryAvailability(entry) {
      if (closed) return "フォルダは閉じられています。";
      if (!entry || !entries.includes(entry)) return "フォルダ内の画像を特定できません。";
      if (!Number.isSafeInteger(entry.size) || entry.size < 0 || entry.size > MAX_IMAGE_BYTES) {
        return "画像が現在の64 MiB上限を超えています。";
      }
      return null;
    },
    async readEntry(entry) {
      const unavailable = this.getEntryAvailability(entry);
      if (unavailable) {
        const error = new Error(unavailable);
        error.code = "UNSUPPORTED_ENTRY";
        throw error;
      }
      return new Uint8Array(await entry.file.arrayBuffer());
    },
    async close() {
      closed = true;
      for (const entry of entries) entry.file = null;
      entries.length = 0;
    }
  };
}

const DB_NAME = "aquvi-encrypted-page-cache";
const DB_VERSION = 1;
const STORE = "records";
const META = "meta";
const DEFAULT_LIMIT = 2 * 1024 ** 3;
const PBKDF2_ITERATIONS = 100000;
const encoder = new TextEncoder();
const keyCache = new Map();
const archiveFingerprintCache = new WeakMap();

function openDb() {
  return new Promise((resolve, reject) => {
    const request = indexedDB.open(DB_NAME, DB_VERSION);
    request.onupgradeneeded = () => {
      const db = request.result;
      if (!db.objectStoreNames.contains(STORE)) {
        const store = db.createObjectStore(STORE, { keyPath: "id" });
        store.createIndex("lastUsed", "lastUsed");
      }
      if (!db.objectStoreNames.contains(META)) db.createObjectStore(META, { keyPath: "id" });
    };
    request.onsuccess = () => resolve(request.result);
    request.onerror = () => reject(request.error);
  });
}

function requestResult(request) {
  return new Promise((resolve, reject) => {
    request.onsuccess = () => resolve(request.result);
    request.onerror = () => reject(request.error);
  });
}

async function digestHex(data) {
  const hash = new Uint8Array(await crypto.subtle.digest("SHA-256", data));
  return [...hash].map((value) => value.toString(16).padStart(2, "0")).join("");
}

async function archiveIdentity(file) {
  const cached = archiveFingerprintCache.get(file);
  if (cached) return cached;

  // Keep identity checks fast: hash file metadata and small samples from the
  // beginning, middle, and end instead of reading the entire archive.
  const sampleSize = 64 * 1024;
  const offsets = [
    0,
    Math.max(0, Math.floor(file.size / 2) - Math.floor(sampleSize / 2)),
    Math.max(0, file.size - sampleSize)
  ];
  const parts = [encoder.encode(JSON.stringify([file.size, file.lastModified, offsets]))];
  for (const offset of offsets) {
    const bytes = new Uint8Array(await file.slice(offset, Math.min(file.size, offset + sampleSize)).arrayBuffer());
    parts.push(bytes);
  }

  const totalLength = parts.reduce((sum, part) => sum + part.byteLength, 0);
  const input = new Uint8Array(totalLength);
  let cursor = 0;
  for (const part of parts) {
    input.set(part, cursor);
    cursor += part.byteLength;
  }
  const fingerprint = await digestHex(input);
  archiveFingerprintCache.set(file, fingerprint);
  return fingerprint;
}

async function getSalt(db, archiveId) {
  const id = "salt:" + archiveId;
  const existing = await requestResult(db.transaction(META).objectStore(META).get(id));
  if (existing?.salt) return new Uint8Array(existing.salt);
  const salt = crypto.getRandomValues(new Uint8Array(16));
  await new Promise((resolve, reject) => {
    const tx = db.transaction(META, "readwrite");
    const store = tx.objectStore(META);
    const request = store.get(id);
    request.onsuccess = () => {
      if (!request.result) store.put({ id, salt: Array.from(salt) });
    };
    tx.oncomplete = resolve;
    tx.onerror = () => reject(tx.error);
    tx.onabort = () => reject(tx.error);
  });
  const saved = await requestResult(db.transaction(META).objectStore(META).get(id));
  return new Uint8Array(saved?.salt || salt);
}

async function deriveKey(password, salt, archiveId) {
  const passwordTag = await digestHex(encoder.encode(password));
  const cacheId = archiveId + ":" + passwordTag;
  if (keyCache.has(cacheId)) return keyCache.get(cacheId);
  const material = await crypto.subtle.importKey("raw", encoder.encode(password), "PBKDF2", false, ["deriveKey"]);
  const key = await crypto.subtle.deriveKey(
    { name: "PBKDF2", salt, iterations: PBKDF2_ITERATIONS, hash: "SHA-256" },
    material,
    { name: "AES-GCM", length: 256 },
    false,
    ["encrypt", "decrypt"]
  );
  keyCache.set(cacheId, key);
  return key;
}

async function recordId(archiveId, entry) {
  const identity = encoder.encode(JSON.stringify([archiveId, entry.id ?? null, entry.name || "", entry.size ?? entry.uncompressedSize ?? null]));
  return digestHex(identity);
}

async function getLimit(db) {
  const record = await requestResult(db.transaction(META).objectStore(META).get("limit"));
  return Number.isFinite(record?.bytes) ? record.bytes : DEFAULT_LIMIT;
}

export async function setEncryptedPageCacheLimit(gigabytes) {
  const value = Number(gigabytes);
  if (![2, 4, 6, 8].includes(value)) throw new RangeError("Cache limit must be 2, 4, 6, or 8 GB.");
  const db = await openDb();
  await new Promise((resolve, reject) => {
    const tx = db.transaction(META, "readwrite");
    tx.objectStore(META).put({ id: "limit", bytes: value * 1024 ** 3 });
    tx.oncomplete = resolve; tx.onerror = () => reject(tx.error); tx.onabort = () => reject(tx.error);
  });
  db.close();
}

export async function getEncryptedPageCacheStats() {
  const db = await openDb();
  const records = await requestResult(db.transaction(STORE).objectStore(STORE).getAll());
  const limit = await getLimit(db);
  db.close();
  return { usedBytes: records.reduce((sum, record) => sum + (record.size || 0), 0), limitBytes: limit, count: records.length };
}

export async function clearEncryptedPageCache() {
  const db = await openDb();
  await new Promise((resolve, reject) => {
    const tx = db.transaction([STORE, META], "readwrite");
    tx.objectStore(STORE).clear();
    const meta = tx.objectStore(META);
    const request = meta.openCursor();
    request.onsuccess = () => {
      const cursor = request.result;
      if (cursor && String(cursor.key).startsWith("salt:")) cursor.delete();
      if (cursor) cursor.continue();
    };
    tx.oncomplete = resolve; tx.onerror = () => reject(tx.error); tx.onabort = () => reject(tx.error);
  });
  db.close();
  keyCache.clear();
}

export async function readEncryptedPageCache(file, entry, password) {
  if (!file || !entry || typeof password !== "string" || !password) return null;
  const db = await openDb();
  try {
    const archiveId = await archiveIdentity(file);
    const id = await recordId(archiveId, entry);
    const record = await requestResult(db.transaction(STORE).objectStore(STORE).get(id));
    if (!record) return null;
    const salt = await getSalt(db, archiveId);
    const key = await deriveKey(password, salt, archiveId);
    try {
      const plain = await crypto.subtle.decrypt({ name: "AES-GCM", iv: new Uint8Array(record.iv) }, key, record.ciphertext);
      const data = new Uint8Array(plain);
      const tx = db.transaction(STORE, "readwrite");
      tx.objectStore(STORE).put({ ...record, lastUsed: Date.now() });
      return data;
    } catch {
      // A wrong password must never delete a valid cache record.
      return null;
    }
  } finally {
    db.close();
  }
}

export async function writeEncryptedPageCache(file, entry, password, data) {
  if (!file || !entry || typeof password !== "string" || !password ||
      !(data instanceof Uint8Array) || !data.byteLength) return false;
  const db = await openDb();
  try {
    const archiveId = await archiveIdentity(file);
    const salt = await getSalt(db, archiveId);
    const key = await deriveKey(password, salt, archiveId);
    const iv = crypto.getRandomValues(new Uint8Array(12));
    const ciphertext = await crypto.subtle.encrypt({ name: "AES-GCM", iv }, key, data);
    const id = await recordId(archiveId, entry);
    const record = { id, iv: Array.from(iv), ciphertext, size: ciphertext.byteLength, lastUsed: Date.now() };
    const limit = await getLimit(db);
    await new Promise((resolve, reject) => {
      const tx = db.transaction(STORE, "readwrite");
      const store = tx.objectStore(STORE);
      store.put(record);
      const all = store.getAll();
      all.onsuccess = () => {
        const records = all.result;
        let total = records.reduce((sum, item) => sum + (item.size || 0), 0);
        records.sort((a, b) => a.lastUsed - b.lastUsed);
        for (const item of records) {
          if (total <= limit) break;
          if (item.id === id) continue;
          store.delete(item.id);
          total -= item.size || 0;
        }
      };
      tx.oncomplete = resolve; tx.onerror = () => reject(tx.error); tx.onabort = () => reject(tx.error);
    });
    return true;
  } finally {
    db.close();
  }
}

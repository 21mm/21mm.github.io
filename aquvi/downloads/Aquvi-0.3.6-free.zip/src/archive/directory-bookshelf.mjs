const IMAGE_EXTENSIONS = new Set(["jpg", "jpeg", "png", "gif", "webp", "avif", "bmp"]);
const ARCHIVE_EXTENSIONS = new Set(["zip", "cbz", "7z", "tar"]);
const COLLATOR = new Intl.Collator("ja", { numeric: true, sensitivity: "base" });
const YIELD_EVERY = 512;

export function isIgnoredDirectoryEntry(name) {
  const value = String(name || "");
  const lower = value.toLowerCase();
  return lower.startsWith(".") ||
    lower === "__macosx" ||
    lower === "thumbs.db" ||
    lower === "desktop.ini" ||
    lower === "ehthumbs.db";
}

function extensionOf(name) {
  const value = String(name || "");
  const dot = value.lastIndexOf(".");
  return dot > 0 ? value.slice(dot + 1).toLowerCase() : "";
}

function isImage(name) {
  return IMAGE_EXTENSIONS.has(extensionOf(name));
}

function archiveExtension(name) {
  const extension = extensionOf(name);
  return ARCHIVE_EXTENSIONS.has(extension) ? extension : "";
}

function compareNames(left, right) {
  return COLLATOR.compare(left, right);
}

async function yieldToBrowser() {
  await new Promise((resolve) => setTimeout(resolve, 0));
}

async function probeDirectory(handle, pathSegments, progress) {
  let firstImageHandle = null;
  let firstImageName = "";
  let imageCount = 0;
  let scanned = 0;

  for await (const [name, entry] of handle.entries()) {
    if (isIgnoredDirectoryEntry(name)) continue;
    scanned++;
    if (entry.kind === "directory") {
      return { kind: "folder", handle, name: handle.name, pathSegments, scanned };
    }
    const format = archiveExtension(name);
    if (format) {
      return { kind: "folder", handle, name: handle.name, pathSegments, scanned };
    }
    if (isImage(name)) {
      imageCount++;
      if (!firstImageHandle || compareNames(name, firstImageName) < 0) {
        firstImageHandle = entry;
        firstImageName = name;
      }
    }
    if (scanned % YIELD_EVERY === 0) {
      progress(scanned);
      await yieldToBrowser();
    }
  }

  if (imageCount) {
    return {
      kind: "book",
      handle,
      name: handle.name,
      pathSegments,
      firstImageHandle,
      firstImageName,
      imageCount,
      scanned
    };
  }
  return null;
}

async function mapWithConcurrency(items, limit, callback) {
  const results = new Array(items.length);
  let next = 0;
  const workers = Array.from({ length: Math.min(limit, items.length) }, async () => {
    while (true) {
      const index = next++;
      if (index >= items.length) return;
      results[index] = await callback(items[index], index);
    }
  });
  await Promise.all(workers);
  return results;
}

function makeBook(handle, name, pathSegments, firstImageHandle, firstImageName, imageCount, direct = false) {
  return {
    kind: "book",
    name,
    path: pathSegments.join("/"),
    pathSegments: pathSegments.slice(),
    handle,
    firstImageHandle,
    firstImageName,
    imageCount,
    direct,
    positionKey: "aquvi.reading-position.dir." + pathSegments.join("/")
  };
}

function makeArchiveBook(handle, name, pathSegments, format) {
  return {
    kind: "archiveBook",
    name: name.slice(0, -(format.length + 1)),
    path: pathSegments.join("/"),
    pathSegments: pathSegments.slice(),
    handle,
    format
  };
}

export async function scanDirectoryLevel(handle, pathSegments = [], options = {}) {
  if (!handle || handle.kind !== "directory") {
    throw new TypeError("A FileSystemDirectoryHandle is required.");
  }
  const onProgress = typeof options.onProgress === "function" ? options.onProgress : () => {};
  const root = Boolean(options.root);
  const childDirectories = [];
  const archiveFiles = [];
  let firstDirectImageHandle = null;
  let firstDirectImageName = "";
  let directImageCount = 0;
  let scanned = 0;
  let sinceYield = 0;

  onProgress({ phase: "reading-current-folder", folder: handle.name, scanned: 0 });

  for await (const [name, entry] of handle.entries()) {
    if (isIgnoredDirectoryEntry(name)) continue;
    scanned++;
    sinceYield++;
    if (entry.kind === "directory") {
      childDirectories.push({ name, handle: entry });
    } else {
      const format = archiveExtension(name);
      if (format) {
        archiveFiles.push({ name, handle: entry, format });
      } else if (isImage(name)) {
        directImageCount++;
        if (!firstDirectImageHandle || compareNames(name, firstDirectImageName) < 0) {
          firstDirectImageHandle = entry;
          firstDirectImageName = name;
        }
      }
    }
    if (sinceYield >= YIELD_EVERY) {
      onProgress({ phase: "reading-current-folder", folder: handle.name, scanned });
      sinceYield = 0;
      await yieldToBrowser();
    }
  }

  onProgress({
    phase: "checking-child-folders",
    folder: handle.name,
    scanned,
    childFolders: childDirectories.length
  });

  let probedCount = 0;
  const childItems = await mapWithConcurrency(childDirectories, 4, async ({ name, handle: childHandle }) => {
    const childPath = [...pathSegments, name];
    const result = await probeDirectory(childHandle, childPath, (childScanned) => {
      onProgress({
        phase: "checking-child-folders",
        folder: handle.name,
        scanned,
        childFolders: childDirectories.length,
        checkedFolders: probedCount,
        currentChild: name,
        childScanned
      });
    });
    probedCount++;
    onProgress({
      phase: "checking-child-folders",
      folder: handle.name,
      scanned,
      childFolders: childDirectories.length,
      checkedFolders: probedCount,
      currentChild: name
    });
    return result;
  });

  const folders = [];
  const books = [];
  for (const item of childItems) {
    if (!item) continue;
    if (item.kind === "folder") folders.push(item);
    else books.push(item);
  }

  const items = [];
  if (directImageCount && (root || childDirectories.length || archiveFiles.length)) {
    const title = root && !folders.length && !books.length && !archiveFiles.length
      ? handle.name
      : "このフォルダの画像";
    items.push(makeBook(
      handle,
      title,
      pathSegments,
      firstDirectImageHandle,
      firstDirectImageName,
      directImageCount,
      true
    ));
  }

  for (const { name, handle: fileHandle, format } of archiveFiles) {
    items.push(makeArchiveBook(fileHandle, name, pathSegments, format));
  }

  items.push(...folders, ...books);
  const folderItems = items.filter((item) => item.kind === "folder")
    .sort((a, b) => compareNames(a.name, b.name));
  const volumeItems = items.filter((item) => item.kind === "book" || item.kind === "archiveBook")
    .sort((a, b) => compareNames(a.name, b.name) || a.kind.localeCompare(b.kind));

  volumeItems.forEach((item, index) => {
    item.seriesPath = pathSegments.slice();
    item.seriesIndex = index;
    item.seriesLength = volumeItems.length;
  });

  return {
    name: handle.name,
    pathSegments: pathSegments.slice(),
    handle,
    folders: new Map(folderItems.map((item) => [item.name, item])),
    items: [...folderItems, ...volumeItems],
    scannedEntries: scanned,
    childFolderCount: childDirectories.length,
    imageCount: directImageCount,
    archiveCount: archiveFiles.length,
    loaded: true
  };
}

export async function buildDirectoryBookshelf(rootHandle, options = {}) {
  const root = await scanDirectoryLevel(rootHandle, [], { ...options, root: true });
  return {
    directoryMode: true,
    rootName: rootHandle.name,
    root,
    nodes: new Map([["", root]])
  };
}

export function getDirectoryBookshelfNode(index, pathSegments = []) {
  return index?.nodes?.get(pathSegments.join("/")) || null;
}

export async function readDirectoryBookImages(handle, options = {}) {
  const onProgress = typeof options.onProgress === "function" ? options.onProgress : () => {};
  const files = [];
  let scanned = 0;
  for await (const [name, entry] of handle.entries()) {
    if (isIgnoredDirectoryEntry(name) || entry.kind !== "file" || !isImage(name)) continue;
    const file = await entry.getFile();
    files.push(file);
    scanned++;
    if (scanned % 256 === 0) {
      onProgress({ phase: "loading-book-images", folder: handle.name, scanned });
      await yieldToBrowser();
    }
  }
  files.sort((a, b) => compareNames(a.name, b.name) || (a.lastModified || 0) - (b.lastModified || 0));
  return files;
}

export async function getDirectoryFile(handle) {
  if (!handle || handle.kind !== "file" || typeof handle.getFile !== "function") {
    throw new TypeError("A FileSystemFileHandle is required.");
  }
  return handle.getFile();
}

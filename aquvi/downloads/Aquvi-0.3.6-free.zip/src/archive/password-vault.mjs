const DATABASE_NAME = "aquvi-password-vault";
const DATABASE_VERSION = 1;
const KEY_STORE = "keys";
const PASSWORD_STORE = "passwords";
const PROFILE_KEY_ID = "default-password-aes-gcm";
const DEFAULT_PASSWORD_ID = "default-archive-password";

let databasePromise = null;
let keyPromise = null;

function requestResult(request) {
  return new Promise((resolve, reject) => {
    request.onsuccess = () => resolve(request.result);
    request.onerror = () => reject(request.error || new Error("Password storage request failed."));
  });
}

function transactionDone(transaction) {
  return new Promise((resolve, reject) => {
    transaction.oncomplete = () => resolve();
    transaction.onabort = () => reject(transaction.error || new Error("Password storage transaction aborted."));
    transaction.onerror = () => reject(transaction.error || new Error("Password storage transaction failed."));
  });
}

function openDatabase() {
  if (!globalThis.indexedDB) {
    return Promise.reject(new Error("Encrypted password storage is unavailable."));
  }
  if (databasePromise) return databasePromise;

  databasePromise = new Promise((resolve, reject) => {
    const request = indexedDB.open(DATABASE_NAME, DATABASE_VERSION);
    request.onupgradeneeded = () => {
      const database = request.result;
      if (!database.objectStoreNames.contains(KEY_STORE)) {
        database.createObjectStore(KEY_STORE, { keyPath: "id" });
      }
      if (!database.objectStoreNames.contains(PASSWORD_STORE)) {
        database.createObjectStore(PASSWORD_STORE, { keyPath: "id" });
      }
    };
    request.onsuccess = () => {
      const database = request.result;
      database.onversionchange = () => {
        database.close();
        databasePromise = null;
        keyPromise = null;
      };
      resolve(database);
    };
    request.onerror = () => {
      databasePromise = null;
      reject(request.error || new Error("Could not open encrypted password storage."));
    };
    request.onblocked = () => {
      databasePromise = null;
      reject(new Error("Encrypted password storage is blocked by another connection."));
    };
  });
  return databasePromise;
}

async function getProfileKey(database) {
  if (keyPromise) return keyPromise;
  keyPromise = (async () => {
    // Generate before opening the transaction. The get/add decision itself is
    // made inside one serialized readwrite transaction so two Aquvi tabs cannot
    // replace each other's profile key and orphan ciphertext.
    const generatedKey = await crypto.subtle.generateKey(
      { name: "AES-GCM", length: 256 },
      false,
      ["encrypt", "decrypt"]
    );
    return new Promise((resolve, reject) => {
      const transaction = database.transaction(KEY_STORE, "readwrite");
      const store = transaction.objectStore(KEY_STORE);
      let selectedKey = null;
      const request = store.get(PROFILE_KEY_ID);
      request.onsuccess = () => {
        if (request.result?.key) {
          selectedKey = request.result.key;
          return;
        }
        selectedKey = generatedKey;
        store.add({ id: PROFILE_KEY_ID, key: generatedKey });
      };
      request.onerror = () => {
        try { transaction.abort(); } catch {/* The transaction may already be inactive. */}
      };
      transaction.oncomplete = () => resolve(selectedKey);
      transaction.onabort = () => reject(transaction.error || request.error || new Error("Could not initialize the password encryption key."));
      transaction.onerror = () => reject(transaction.error || new Error("Could not initialize the password encryption key."));
    });
  })().catch((error) => {
    keyPromise = null;
    throw error;
  });
  return keyPromise;
}

export async function saveDefaultArchivePassword(password) {
  if (typeof password !== "string" || !password) {
    await deleteDefaultArchivePassword();
    return;
  }
  if (!globalThis.crypto?.subtle) {
    throw new Error("Web Crypto is unavailable; the password was not saved.");
  }

  const database = await openDatabase();
  const key = await getProfileKey(database);
  const iv = crypto.getRandomValues(new Uint8Array(12));
  const plaintext = new TextEncoder().encode(password);
  const ciphertext = await crypto.subtle.encrypt({ name: "AES-GCM", iv }, key, plaintext);

  const transaction = database.transaction(PASSWORD_STORE, "readwrite");
  const done = transactionDone(transaction);
  transaction.objectStore(PASSWORD_STORE).put({
    id: DEFAULT_PASSWORD_ID,
    algorithm: "AES-GCM",
    iv: iv.buffer,
    ciphertext,
    updatedAt: Date.now()
  });
  await done;
}

export async function loadDefaultArchivePassword() {
  if (!globalThis.crypto?.subtle || !globalThis.indexedDB) return null;

  const database = await openDatabase();
  const read = database.transaction(PASSWORD_STORE, "readonly");
  const done = transactionDone(read);
  const record = await requestResult(read.objectStore(PASSWORD_STORE).get(DEFAULT_PASSWORD_ID));
  await done;
  if (!record) return null;

  try {
    if (record.algorithm !== "AES-GCM" || !(record.iv instanceof ArrayBuffer) ||
        !(record.ciphertext instanceof ArrayBuffer)) {
      throw new Error("Invalid encrypted password record.");
    }
    const key = await getProfileKey(database);
    const plaintext = await crypto.subtle.decrypt(
      { name: "AES-GCM", iv: new Uint8Array(record.iv) },
      key,
      record.ciphertext
    );
    return new TextDecoder().decode(plaintext);
  } catch {
    await deleteDefaultArchivePassword();
    return null;
  }
}

export async function deleteDefaultArchivePassword() {
  if (!globalThis.indexedDB) return;
  const database = await openDatabase();
  const transaction = database.transaction([PASSWORD_STORE, KEY_STORE], "readwrite");
  const done = transactionDone(transaction);
  transaction.objectStore(PASSWORD_STORE).delete(DEFAULT_PASSWORD_ID);
  transaction.objectStore(KEY_STORE).delete(PROFILE_KEY_ID);
  await done;
  keyPromise = null;
}

export async function hasSavedDefaultArchivePassword() {
  if (!globalThis.indexedDB) return false;
  const database = await openDatabase();
  const transaction = database.transaction(PASSWORD_STORE, "readonly");
  const done = transactionDone(transaction);
  const record = await requestResult(transaction.objectStore(PASSWORD_STORE).get(DEFAULT_PASSWORD_ID));
  await done;
  return Boolean(record?.ciphertext);
}

const IMAGE_EXTENSIONS = new Set(["jpg", "jpeg", "png", "gif", "webp", "avif", "bmp"]);
const COLLATOR = new Intl.Collator("ja", { numeric: true, sensitivity: "base" });

export function isSafeArchivePath(path) {
  if (!path || path.includes("\0")) return false;
  if (path.startsWith("/") || path.startsWith("\\") || /^[a-z]:/i.test(path)) return false;
  return !path.split(/[\\/]/).some((part) => part === ".." || part === ".");
}

function parseBlock(block) {
  const record = {};
  for (const line of block) {
    const separator = line.indexOf(" = ");
    if (separator <= 0) continue;
    record[line.slice(0, separator)] = line.slice(separator + 3);
  }
  return record;
}

/**
 * Parse 7-Zip technical listing output. Only regular files with a safe path
 * and a finite declared size are returned.
 */
export function parseSevenZipListing(text, archiveName = "") {
  const blocks = [];
  let block = [];
  for (const line of String(text || "").replace(/\r/g, "").split("\n")) {
    if (!line.trim() || /^-{5,}$/.test(line.trim())) {
      if (block.length) blocks.push(block);
      block = [];
      continue;
    }
    block.push(line);
  }
  if (block.length) blocks.push(block);

  const entries = [];
  for (const lines of blocks) {
    const record = parseBlock(lines);
    const name = record.Path;
    if (!name || name === archiveName) continue;
    // 7-Zip omits "Folder = -" on some encrypted / solid 7z listings.
    // A directory is explicitly marked with Folder = + or a D attribute;
    // regular files still carry a numeric Size field below.
    if (record.Folder === "+" || /^D/i.test(String(record.Attributes || "").trim())) continue;
    if (!isSafeArchivePath(name)) continue;
    if (record["Symbolic Link"] || record["Hard Link"] || record.ReparsePoint === "+") continue;
    const size = Number(record.Size);
    if (!Number.isSafeInteger(size) || size < 0) continue;
    entries.push({
      id: entries.length,
      name,
      size,
      encrypted: record.Encrypted === "+",
      method: record.Method || "",
      crc: record.CRC || null,
      isDirectory: false
    });
  }
  entries.sort((left, right) =>
    COLLATOR.compare(left.name, right.name) || left.id - right.id
  );
  const seenPaths = new Set();
  for (const entry of entries) {
    if (seenPaths.has(entry.name)) entry.duplicatePath = true;
    else seenPaths.add(entry.name);
  }
  return entries;
}

export function isSupportedArchiveImage(name) {
  const leaf = String(name || "").split(/[\\/]/).pop() || "";
  const dot = leaf.lastIndexOf(".");
  return dot > 0 && IMAGE_EXTENSIONS.has(leaf.slice(dot + 1).toLowerCase());
}
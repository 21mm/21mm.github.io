const DATABASE_NAME = "aquvi-bookshelf-handle";
const DATABASE_VERSION = 1;
const STORE_NAME = "handles";
const HANDLE_ID = "last-selected-root";

function openDatabase() {
  return new Promise((resolve, reject) => {
    const request = indexedDB.open(DATABASE_NAME, DATABASE_VERSION);
    request.onupgradeneeded = () => {
      if (!request.result.objectStoreNames.contains(STORE_NAME)) {
        request.result.createObjectStore(STORE_NAME, { keyPath: "id" });
      }
    };
    request.onsuccess = () => {
      const database = request.result;
      database.onversionchange = () => database.close();
      resolve(database);
    };
    request.onerror = () => reject(request.error || new Error("本棚の保存領域を開けませんでした。"));
  });
}

function requestResult(request) {
  return new Promise((resolve, reject) => {
    request.onsuccess = () => resolve(request.result);
    request.onerror = () => reject(request.error || new Error("本棚の保存に失敗しました。"));
  });
}

function transactionDone(transaction) {
  return new Promise((resolve, reject) => {
    transaction.oncomplete = resolve;
    transaction.onabort = () => reject(transaction.error || new Error("本棚の保存に失敗しました。"));
    transaction.onerror = () => reject(transaction.error || new Error("本棚の保存に失敗しました。"));
  });
}

export async function saveBookshelfHandle(handle) {
  if (!handle || handle.kind !== "directory") throw new TypeError("有効な本棚フォルダではありません。");
  const database = await openDatabase();
  try {
    const transaction = database.transaction(STORE_NAME, "readwrite");
    transaction.objectStore(STORE_NAME).put({ id: HANDLE_ID, handle, savedAt: Date.now() });
    await transactionDone(transaction);
  } finally {
    database.close();
  }
}

export async function getSavedBookshelfHandle() {
  const database = await openDatabase();
  try {
    const transaction = database.transaction(STORE_NAME, "readonly");
    const record = await requestResult(transaction.objectStore(STORE_NAME).get(HANDLE_ID));
    await transactionDone(transaction);
    return record?.handle || null;
  } finally {
    database.close();
  }
}

export async function getBookshelfPermission(handle) {
  if (!handle || typeof handle.queryPermission !== "function") return "prompt";
  try {
    return await handle.queryPermission({ mode: "read" });
  } catch {
    return "prompt";
  }
}

export async function requestBookshelfPermission(handle) {
  if (!handle) return "denied";
  if (typeof handle.requestPermission !== "function") return "granted";
  return handle.requestPermission({ mode: "read" });
}

export async function forgetBookshelfHandle() {
  const database = await openDatabase();
  try {
    const transaction = database.transaction(STORE_NAME, "readwrite");
    transaction.objectStore(STORE_NAME).delete(HANDLE_ID);
    await transactionDone(transaction);
  } finally {
    database.close();
  }
}

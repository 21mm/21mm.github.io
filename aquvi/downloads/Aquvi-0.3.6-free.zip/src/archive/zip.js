const EOCD = 0x06054b50;
const CENTRAL = 0x02014b50;
const LOCAL = 0x04034b50;
const MAX_ENTRIES = 20000;
const MAX_CENTRAL_DIRECTORY_BYTES = 64 * 1024 * 1024;
const MAX_IMAGE_BYTES = 64 * 1024 * 1024;
const CP437 = "ÇüéâäàåçêëèïîìÄÅÉæÆôöòûùÿÖÜ¢£¥₧ƒáíóúñÑªº¿⌐¬½¼¡«»░▒▓│┤╡╢╖╕╣║╗╝╜╛┐└┴┬├─┼╞╟╚╔╩╦╠═╬╧╨╤╥╙╘╒╓╫╪┘┌█▄▌▐▀αßΓπΣσµτΦΘΩδ∞φε∩≡±≥≤⌠⌡÷≈°∙·√ⁿ²■ ";
const FILENAME_COLLATOR = new Intl.Collator("ja", { numeric: true, sensitivity: "base" });
const CRC_TABLE = (() => {
  const table = new Uint32Array(256);
  for (let n = 0; n < 256; n++) {
    let c = n;
    for (let k = 0; k < 8; k++) c = (c & 1) ? (0xedb88320 ^ (c >>> 1)) : (c >>> 1);
    table[n] = c >>> 0;
  }
  return table;
})();

export class ZipArchiveError extends Error {
  constructor(message, code = "ZIP_ERROR") {
    super(message);
    this.name = "ZipArchiveError";
    this.code = code;
  }
}


let ZIP_DECRYPTION_API_PROMISE = null;

async function getZipDecryptionApi() {
  if (!ZIP_DECRYPTION_API_PROMISE) {
    ZIP_DECRYPTION_API_PROMISE = (async () => {
      // This comparatively large dependency is fetched only when an encrypted
      // ZIP entry is first opened. The ordinary ZIP reader remains unchanged.
      await import("../../vendor/zipjs/zip-native.min.js");
      const api = globalThis.zip;
      if (!api || !api.ZipReader || !api.BlobReader || !api.Uint8ArrayWriter || !api.configure) {
        throw new ZipArchiveError("ZIP decryption engine failed to initialize.", "ZIP_ENGINE_INIT");
      }

      // Chrome extensions disallow blob: workers. Use zip.js's bundled local
      // worker instead; it is started only on the first encrypted extraction.
      const canUseLocalWorker = typeof Worker === "function" && typeof document !== "undefined";
      api.configure({
        maxWorkers: 2,
        useWebWorkers: canUseLocalWorker,
        ...(canUseLocalWorker ? {
          createWorker: () => new Worker(
            new URL("../../vendor/zipjs/zip-web-worker-native.js", import.meta.url),
            { type: "module" }
          )
        } : {})
      });
      return api;
    })().catch((error) => {
      ZIP_DECRYPTION_API_PROMISE = null;
      throw error;
    });
  }
  return ZIP_DECRYPTION_API_PROMISE;
}

function parseAesExtra(extraBytes) {
  if (!extraBytes || extraBytes.length < 11) return null;
  const view = new DataView(extraBytes.buffer, extraBytes.byteOffset, extraBytes.byteLength);
  let cursor = 0;

  while (cursor + 4 <= extraBytes.length) {
    const fieldId = view.getUint16(cursor, true);
    const fieldLength = view.getUint16(cursor + 2, true);
    const dataStart = cursor + 4;
    const dataEnd = dataStart + fieldLength;
    if (dataEnd > extraBytes.length) break;

    if (fieldId === 0x9901 && fieldLength >= 7) {
      const version = view.getUint16(dataStart, true);
      const vendor = view.getUint16(dataStart + 2, true);
      const strength = view.getUint8(dataStart + 4);
      const compressionMethod = view.getUint16(dataStart + 5, true);
      if ((version === 1 || version === 2) && vendor === 0x4541 && strength >= 1 && strength <= 3) {
        return { version, strength, compressionMethod };
      }
      return null;
    }
    cursor = dataEnd;
  }
  return null;
}

const UTF8_DECODER = new TextDecoder("utf-8", { fatal: true });
const SHIFT_JIS_DECODER = new TextDecoder("shift_jis", { fatal: true });

function tryDecode(decoder, bytes) {
  try { return decoder.decode(bytes); }
  catch { return null; }
}

function containsJapanese(value) {
  return /[\p{Script=Hiragana}\p{Script=Katakana}\p{Script=Han}]/u.test(value);
}

function decodeCp437(bytes) {
  let value = "";
  for (const byte of bytes) value += byte < 128 ? String.fromCharCode(byte) : CP437[byte - 128];
  return value;
}

function decodeUnicodePathExtra(extraBytes, rawNameBytes) {
  if (!extraBytes || extraBytes.length < 9) return null;
  const view = new DataView(extraBytes.buffer, extraBytes.byteOffset, extraBytes.byteLength);
  const expectedCrc = checksum(rawNameBytes);
  let cursor = 0;

  while (cursor + 4 <= extraBytes.length) {
    const fieldId = view.getUint16(cursor, true);
    const fieldLength = view.getUint16(cursor + 2, true);
    const dataStart = cursor + 4;
    const dataEnd = dataStart + fieldLength;
    if (dataEnd > extraBytes.length) break;

    if (fieldId === 0x7075 && fieldLength >= 5 && view.getUint8(dataStart) === 1) {
      const storedCrc = view.getUint32(dataStart + 1, true);
      if (storedCrc === expectedCrc) {
        const unicodeName = tryDecode(UTF8_DECODER, extraBytes.subarray(dataStart + 5, dataEnd));
        if (unicodeName !== null) return unicodeName;
      }
    }
    cursor = dataEnd;
  }
  return null;
}

function decodeName(bytes, flags, extraBytes = null) {
  if (flags & 0x0800) {
    const utf8 = tryDecode(UTF8_DECODER, bytes);
    if (utf8 === null) throw new ZipArchiveError("The ZIP contains an invalid UTF-8 filename.", "INVALID_FILENAME");
    return utf8;
  }

  // Info-ZIP Unicode Path (0x7075) is authoritative when its filename CRC matches.
  const unicodePath = decodeUnicodePathExtra(extraBytes, bytes);
  if (unicodePath !== null) return unicodePath;

  // Some ZIP writers omit the UTF-8 flag even when storing UTF-8 filename bytes.
  const unflaggedUtf8 = tryDecode(UTF8_DECODER, bytes);
  if (unflaggedUtf8 !== null && containsJapanese(unflaggedUtf8)) return unflaggedUtf8;

  // Japanese Windows ZIPs commonly use CP932 / Windows-31J without setting bit 11.
  const shiftJis = tryDecode(SHIFT_JIS_DECODER, bytes);
  if (shiftJis !== null && containsJapanese(shiftJis)) return shiftJis;

  // ZIP's standard legacy fallback remains CP437 for other unflagged names.
  return decodeCp437(bytes);
}

function checksum(bytes) {
  let crc = 0xffffffff;
  for (const byte of bytes) crc = CRC_TABLE[(crc ^ byte) & 255] ^ (crc >>> 8);
  return (crc ^ 0xffffffff) >>> 0;
}

function concat(chunks, length) {
  const output = new Uint8Array(length);
  let offset = 0;
  for (const chunk of chunks) { output.set(chunk, offset); offset += chunk.length; }
  return output;
}

async function collectStream(stream, expectedSize, maxBytes) {
  const reader = stream.getReader();
  const chunks = [];
  let total = 0;
  try {
    while (true) {
      const { value, done } = await reader.read();
      if (done) break;
      total += value.byteLength;
      if (total > maxBytes || total > expectedSize) {
        await reader.cancel();
        throw new ZipArchiveError("The extracted image exceeds its size limit.", "SIZE_LIMIT");
      }
      chunks.push(value);
    }
  } finally {
    reader.releaseLock();
  }
  if (total !== expectedSize) throw new ZipArchiveError("Extracted size does not match the ZIP directory.", "SIZE_MISMATCH");
  return concat(chunks, total);
}

function locateEocd(bytes, absoluteStart) {
  const view = new DataView(bytes.buffer, bytes.byteOffset, bytes.byteLength);
  for (let i = bytes.length - 22; i >= 0; i--) {
    if (view.getUint32(i, true) === EOCD && i + 22 + view.getUint16(i + 20, true) === bytes.length) {
      return absoluteStart + i;
    }
  }
  throw new ZipArchiveError("ZIP end-of-central-directory record not found.", "INVALID_ZIP");
}

export class ZipArchive {
  constructor(file, entries, options = {}) {
    this.file = file;
    this.entries = entries;
    this.fileName = file.name || "archive.zip";
    this.maxImageBytes = options.maxImageBytes ?? MAX_IMAGE_BYTES;
    this.closed = false;
    this.zipReader = null;
    this.zipEntries = null;
    this.lastPassword = null;
    this.entryPasswords = new Map();
  }

  static async open(file, options = {}) {
    if (!file || typeof file.slice !== "function" || !Number.isFinite(file.size) || file.size < 22) {
      throw new ZipArchiveError("Please choose a valid ZIP file.", "INVALID_FILE");
    }

    const tailLength = Math.min(file.size, 22 + 0xffff);
    const tailStart = file.size - tailLength;
    const tail = new Uint8Array(await file.slice(tailStart).arrayBuffer());
    const eocdOffset = locateEocd(tail, tailStart);
    const eocd = new DataView(tail.buffer, tail.byteOffset, tail.byteLength);
    const pos = eocdOffset - tailStart;
    const disk = eocd.getUint16(pos + 4, true);
    const centralDisk = eocd.getUint16(pos + 6, true);
    const onDiskCount = eocd.getUint16(pos + 8, true);
    const count = eocd.getUint16(pos + 10, true);
    const directorySize = eocd.getUint32(pos + 12, true);
    const directoryOffset = eocd.getUint32(pos + 16, true);

    if (disk !== 0 || centralDisk !== 0 || onDiskCount !== count) {
      throw new ZipArchiveError("Multi-volume ZIP archives are not supported.", "MULTI_VOLUME");
    }
    if (count === 0xffff || directorySize === 0xffffffff || directoryOffset === 0xffffffff) {
      throw new ZipArchiveError("ZIP64 archives are not supported in this preview.", "ZIP64_UNSUPPORTED");
    }
    if (count > MAX_ENTRIES) throw new ZipArchiveError(`Archive has more than ${MAX_ENTRIES.toLocaleString()} entries.`, "ENTRY_LIMIT");
    if (directorySize > MAX_CENTRAL_DIRECTORY_BYTES) throw new ZipArchiveError("ZIP central directory exceeds the 64 MiB limit.", "DIRECTORY_LIMIT");
    if (directoryOffset + directorySize > eocdOffset || directoryOffset + directorySize > file.size) {
      throw new ZipArchiveError("ZIP central directory points outside the file.", "INVALID_ZIP");
    }

    const bytes = new Uint8Array(await file.slice(directoryOffset, directoryOffset + directorySize).arrayBuffer());
    const view = new DataView(bytes.buffer, bytes.byteOffset, bytes.byteLength);
    const entries = [];
    let cursor = 0;

    for (let index = 0; index < count; index++) {
      if (cursor + 46 > bytes.length || view.getUint32(cursor, true) !== CENTRAL) {
        throw new ZipArchiveError("ZIP central directory is invalid or truncated.", "INVALID_ZIP");
      }
      const flags = view.getUint16(cursor + 8, true);
      const method = view.getUint16(cursor + 10, true);
      const crc32 = view.getUint32(cursor + 16, true);
      const compressedSize = view.getUint32(cursor + 20, true);
      const uncompressedSize = view.getUint32(cursor + 24, true);
      const nameLength = view.getUint16(cursor + 28, true);
      const extraLength = view.getUint16(cursor + 30, true);
      const commentLength = view.getUint16(cursor + 32, true);
      const startDisk = view.getUint16(cursor + 34, true);
      const localHeaderOffset = view.getUint32(cursor + 42, true);
      const recordLength = 46 + nameLength + extraLength + commentLength;

      if (cursor + recordLength > bytes.length) throw new ZipArchiveError("ZIP central directory entry is truncated.", "INVALID_ZIP");
      if (compressedSize === 0xffffffff || uncompressedSize === 0xffffffff || localHeaderOffset === 0xffffffff) {
        throw new ZipArchiveError("ZIP64 entries are not supported in this preview.", "ZIP64_UNSUPPORTED");
      }
      if (startDisk !== 0) throw new ZipArchiveError("Multi-volume ZIP entries are not supported.", "MULTI_VOLUME");

      const rawNameBytes = bytes.subarray(cursor + 46, cursor + 46 + nameLength);
      const extraBytes = bytes.subarray(cursor + 46 + nameLength, cursor + 46 + nameLength + extraLength);
      const name = decodeName(rawNameBytes, flags, extraBytes);
      const aes = method === 99 ? parseAesExtra(extraBytes) : null;
      const encrypted = Boolean(flags & 0x0001) || method === 99;
      entries.push({
        id: index, name, compressedSize, uncompressedSize, method,
        actualMethod: aes ? aes.compressionMethod : method,
        crc32, flags, aes,
        localHeaderOffset,
        encrypted,
        strongEncryption: Boolean(flags & 0x0040),
        encryption: method === 99 ? "winzip-aes" : (encrypted ? "zipcrypto" : null),
        isDirectory: name.endsWith("/")
      });
      cursor += recordLength;
    }
    return new ZipArchive(file, entries, options);
  }

  get imageEntries() {
    const extensions = new Set(["jpg", "jpeg", "png", "gif", "webp", "avif", "bmp"]);
    return this.entries.filter((entry) => {
      if (entry.isDirectory) return false;
      const name = entry.name.split(/[\\/]/).pop() || "";
      return extensions.has(name.includes(".") ? name.split(".").pop().toLowerCase() : "");
    }).sort((left, right) =>
      FILENAME_COLLATOR.compare(left.name, right.name) || left.id - right.id
    );
  }

  getEntryAvailability(entry) {
    if (entry.encrypted) {
      if (entry.strongEncryption && entry.encryption !== "winzip-aes") {
        return "This ZIP uses an unsupported strong-encryption extension.";
      }
      if (entry.encryption === "winzip-aes") {
        if (!entry.aes) return "The ZIP AES encryption metadata is invalid or unsupported.";
        if (![0, 8, 9].includes(entry.aes.compressionMethod)) {
          return `ZIP AES compression method ${entry.aes.compressionMethod} is not supported.`;
        }
      } else if (![0, 8, 9].includes(entry.method)) {
        return `Encrypted ZIP compression method ${entry.method} is not supported.`;
      }
    } else if (entry.method !== 0 && entry.method !== 8) {
      return `ZIP compression method ${entry.method} is not supported.`;
    }
    if (entry.uncompressedSize > this.maxImageBytes) return "Image exceeds the current 64 MiB limit.";
    return null;
  }

  async readEncryptedEntry(entry, password) {
    if (typeof password !== "string") {
      throw new ZipArchiveError("A password is required for this ZIP entry.", "PASSWORD_REQUIRED");
    }

    const api = await getZipDecryptionApi();
    if (!this.zipReader) {
      this.zipReader = new api.ZipReader(new api.BlobReader(this.file));
      this.zipEntries = await this.zipReader.getEntries();
      if (this.zipEntries.length !== this.entries.length) {
        throw new ZipArchiveError("ZIP entry metadata does not match the archive directory.", "ZIP_ENTRY_MISMATCH");
      }
    }

    const zipEntry = this.zipEntries[entry.id];
    if (!zipEntry) throw new ZipArchiveError("ZIP entry could not be located.", "ZIP_ENTRY_MISSING");

    try {
      const output = await zipEntry.getData(new api.Uint8ArrayWriter(), {
        password,
        checkCrc32: true,
        checkAuthenticationCode: true
      });
      if (!(output instanceof Uint8Array)) {
        throw new ZipArchiveError("ZIP decryption returned invalid image data.", "ZIP_OUTPUT_INVALID");
      }
      if (output.byteLength > this.maxImageBytes) {
        throw new ZipArchiveError("Image exceeds the current 64 MiB limit.", "SIZE_LIMIT");
      }
      this.entryPasswords.set(entry.id, password);
      this.lastPassword = password;
      return output;
    } catch (error) {
      const code = String(error?.code || "");
      const message = String(error?.message || error || "");
      if (/INVALID_PASSWORD|INVALID_AUTHENTICATION_CODE|INVALID_CRC32|INVALID_COMPRESSED_DATA|INVALID_UNCOMPRESSED_SIZE|INVALID PASSWORD|WRONG PASSWORD/i.test(code + " " + message)) {
        if (this.entryPasswords.get(entry.id) === password) this.entryPasswords.delete(entry.id);
        if (this.lastPassword === password) this.lastPassword = null;
        throw new ZipArchiveError(
          "The password is incorrect, or this encrypted ZIP entry is damaged.",
          "BAD_PASSWORD"
        );
      }
      throw error;
    }
  }

  async readEntry(entry, options = {}) {
    if (this.closed || !this.file) throw new ZipArchiveError("Archive is closed.", "ARCHIVE_CLOSED");
    const unavailable = this.getEntryAvailability(entry);
    if (unavailable) throw new ZipArchiveError(unavailable, entry.encrypted ? "UNSUPPORTED_ENCRYPTION" : "UNSUPPORTED_METHOD");
    if (entry.encrypted) {
      const password = options.password ?? this.entryPasswords.get(entry.id) ?? this.lastPassword;
      return this.readEncryptedEntry(entry, password);
    }

    const headerBytes = new Uint8Array(await this.file.slice(entry.localHeaderOffset, entry.localHeaderOffset + 30).arrayBuffer());
    if (headerBytes.length !== 30) throw new ZipArchiveError("ZIP local header is truncated.", "INVALID_ZIP");
    const header = new DataView(headerBytes.buffer, headerBytes.byteOffset, headerBytes.byteLength);
    if (header.getUint32(0, true) !== LOCAL) throw new ZipArchiveError("ZIP local header signature is invalid.", "INVALID_ZIP");

    const localFlags = header.getUint16(6, true);
    const localMethod = header.getUint16(8, true);
    if ((localFlags & 0x0001) || (localFlags & 0x0040)) throw new ZipArchiveError("Encrypted ZIP entries cannot be opened yet.", "ENCRYPTED");
    if (localMethod !== entry.method) throw new ZipArchiveError("Local and central ZIP methods do not match.", "INVALID_ZIP");

    const dataStart = entry.localHeaderOffset + 30 + header.getUint16(26, true) + header.getUint16(28, true);
    const dataEnd = dataStart + entry.compressedSize;
    if (dataStart < entry.localHeaderOffset || dataEnd > this.file.size || dataEnd < dataStart) {
      throw new ZipArchiveError("ZIP entry data points outside the file.", "INVALID_ZIP");
    }

    let output;
    if (entry.method === 0) {
      if (entry.compressedSize !== entry.uncompressedSize) throw new ZipArchiveError("Stored entry has inconsistent sizes.", "SIZE_MISMATCH");
      output = new Uint8Array(await this.file.slice(dataStart, dataEnd).arrayBuffer());
    } else {
      if (typeof DecompressionStream !== "function") throw new ZipArchiveError("This browser lacks the required Deflate decoder.", "NO_DEFLATE");
      let decoder;
      try { decoder = new DecompressionStream("deflate-raw"); }
      catch { throw new ZipArchiveError("Raw Deflate is unavailable in this browser.", "NO_DEFLATE"); }
      const stream = this.file.slice(dataStart, dataEnd).stream().pipeThrough(decoder);
      output = await collectStream(stream, entry.uncompressedSize, this.maxImageBytes);
    }

    if (output.length > this.maxImageBytes) throw new ZipArchiveError("Image exceeds the current 64 MiB limit.", "SIZE_LIMIT");
    if (checksum(output) !== entry.crc32) throw new ZipArchiveError("ZIP CRC-32 check failed.", "CRC_MISMATCH");
    return output;
  }

  close() {
    this.closed = true;
    this.lastPassword = null;
    this.entryPasswords.clear();
    this.zipEntries = null;
    if (this.zipReader) {
      try { Promise.resolve(this.zipReader.close()).catch(() => {}); } catch {/* Best-effort worker cleanup. */}
      this.zipReader = null;
    }
    this.file = null;
    this.entries = [];
  }
}

# Archive readers

The current ZIP reader is a small, dependency-free prototype. `format-detect.mjs` checks the selected file using bounded signature reads. `archive-loader.mjs` dynamically imports `zip.js` only after a ZIP-based file has been selected. Other recognized formats are routed to format-specific readers as those readers are added.

## Implemented

- Locate the End of Central Directory (EOCD) record.
- Parse the central directory and preserve archive paths for display.
- Decode UTF-8 filenames and CRC-validated Info-ZIP Unicode Path fields.
- Detect unflagged UTF-8 and legacy Shift_JIS / CP932 Japanese names, with CP437 retained as the general legacy fallback.
- Read Stored (method 0) and Deflate (method 8) entries.
- Use the browser's native `DecompressionStream("deflate-raw")` for Deflate data.
- Validate declared output size and CRC-32.
- Detect encrypted entries and report that decryption is not yet available.
- Read only the selected image rather than extracting the full archive.

## Current limits

- ZIP64 is not implemented.
- Multi-volume ZIPs are not implemented.
- Encrypted ZIP entries are not decrypted.
- Only Stored and Deflate compression are implemented.
- Per-image extracted data is capped at 128 MiB.
- The central directory is capped at 20,000 entries.
- Only JPG, JPEG, PNG, GIF, WebP, AVIF, and BMP are listed.

## Startup contract

- Do not statically import an archive engine from `viewer.js`.
- Do not initialize a decompressor while the popup or empty viewer is idle.
- Keep heavyweight WebAssembly engines in dedicated, format-specific Workers.
- Load the selected engine only after the file signature is identified.
- Keep the selected archive's session alive during reading and dispose of its Worker and buffers when the archive is replaced or closed.
- For 7z, retain a bounded least-recently-used cache of recently decrypted page bytes in memory only. Never persist decrypted page data to IndexedDB or disk; clear the cache when the archive closes or the password is rejected / changed. The cache is capped at 128 MiB and 24 entries.

## API

```js
import { ZipArchive } from "./zip.js";

const archive = await ZipArchive.open(file);
const images = archive.imageEntries;
const bytes = await archive.readEntry(images[0]);
archive.close();
```

`readEntry` returns a `Uint8Array`. The caller owns its lifetime and should release references when the image is no longer needed. The 7z reader may return a copy from its bounded in-memory page cache, so callers must not rely on the returned array being the same object across calls.

# Aquvi Free — Third-party notices

Aquvi Free includes the third-party components below. Their copyright and license terms remain applicable to those components. Aquvi's own project license is separate and has not yet been selected.

## @zip.js/zip.js 2.25.0

- Purpose: ZIP encryption and decompression support.
- License: BSD 3-Clause.
- Copyright: Gildas Lormeau.
- Included notice: `vendor/zipjs/LICENSE`.
- Upstream: https://github.com/gildas-lormeau/zip.js

## 7-Zip 26.02 / un7z-opfs 1.0.2

- Purpose in Free: 7z reading in a local Web Worker.
- License: GNU LGPL (version 2.1 or later) plus the unRAR restriction described in `vendor/7zip/un7z-opfs/License.txt`.
- Copyright: Igor Pavlov; un7z-opfs project authors retain their respective rights.
- Included notices: `vendor/7zip/un7z-opfs/License.txt` and `vendor/COPYING.LESSER`.
- Upstream: https://github.com/caiiiycuk/un7z-opfs
- Aquvi pins the upstream commit and verifies the WASM binary hash during package preparation.

## JS7z v2.5.0 / 7-Zip 25.01

- Purpose in Free: TAR and ZIP entries compressed with BZIP2. The Free capability profile blocks RAR and other non-Free archive formats before this Worker is started.
- License: GNU LGPL (version 2.1 or later) with an unRAR restriction for RAR-related decoder code. The upstream license notice also identifies BSD 3-Clause and BSD 2-Clause portions.
- Copyright: Igor Pavlov and the respective upstream contributors, including Apple Inc. and Facebook, Inc. for the BSD-licensed decoder portions, and Alexander Roshal for unRAR-derived code.
- Included notices: `vendor/7zip-full/License.txt`, `vendor/7zip-full/unRarLicense.txt`, and `vendor/COPYING.LESSER`.
- Upstream: https://github.com/GMH-Code/JS7z
- Pinned release: https://github.com/GMH-Code/JS7z/releases/tag/v2.5.0
- Aquvi verifies the release archive and extracted JavaScript/WASM hashes during package preparation.

## Distribution notes

The JS7z bundle contains unRAR-derived extraction code. Aquvi Free does not expose RAR reading and does not create RAR archives or implement a RAR-compatible archiver. Do not use this code to build a RAR-compatible archiver. The unRAR notice states that distribution of the unRAR utility itself may not be charged for; any future paid distribution containing this bundle requires a separate legal review and must not be assumed permitted.

The LGPL text is supplied in `vendor/COPYING.LESSER`. The full component notices and engine-version information are distributed with the extension. Source and build references are listed above and in the engine preparation scripts.

This notice is informational and is not legal advice. Confirm the exact license scope and LGPL compliance obligations for the final distribution model before publishing.

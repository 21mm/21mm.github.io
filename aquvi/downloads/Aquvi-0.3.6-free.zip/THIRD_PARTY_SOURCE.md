# Aquvi Free — Third-party source references

This file records the upstream source locations corresponding to the pinned third-party runtimes. It is intended to make component provenance and rebuild references easier to inspect. It does not, by itself, determine whether every statutory or license-specific source-offer requirement has been fulfilled.

## @zip.js/zip.js 2.25.0

- Upstream project: https://github.com/gildas-lormeau/zip.js
- Versioned package: https://www.npmjs.com/package/@zip.js/zip.js/v/2.25.0
- License notice: `vendor/zipjs/LICENSE`
- Vendored runtime used by Aquvi: `vendor/zipjs/zip-native.min.js` and `vendor/zipjs/zip-web-worker-native.js`

## un7z-opfs 1.0.2 and 7-Zip 26.02

- Upstream integration source at the pinned commit: https://github.com/caiiiycuk/un7z-opfs/tree/56666d0e1f31608dc9eb64f3cb9090464e13863d
- Upstream build file: https://github.com/caiiiycuk/un7z-opfs/blob/56666d0e1f31608dc9eb64f3cb9090464e13863d/CMakeLists.txt
- 7-Zip 26.02 source archive referenced by that build: https://github.com/ip7z/7zip/releases/download/26.02/7z2602-src.7z
- Expected 7-Zip source archive SHA-256: `c7502dd4557481f52ccf1b3e680329f1fdd207e79a25544afeb3106325474944`
- Aquvi's pinned runtime download and verification: `scripts/prepare-7z-engine.py`
- Aquvi's bundled OPFS glue and patch are provided by the pinned un7z-opfs source project; the runtime is used by Aquvi's 7z Worker.
- License notice: `vendor/7zip/un7z-opfs/License.txt`; full LGPL text: `vendor/COPYING.LESSER`

## JS7z v2.5.0 and 7-Zip 25.01

- Upstream source tag: https://github.com/GMH-Code/JS7z/tree/v2.5.0
- Exact tag commit: https://github.com/GMH-Code/JS7z/commit/7dd10ac45dc946c82e0ff1498b27e66d75e3d8bf
- Pinned ST+FS+EC release archive: https://github.com/GMH-Code/JS7z/releases/download/v2.5.0/js7z-st-fs-ec.zip
- Aquvi's pinned release and runtime checksums: `scripts/prepare-multiformat-engine.py`
- License notices: `vendor/7zip-full/License.txt` and `vendor/7zip-full/unRarLicense.txt`; full LGPL text: `vendor/COPYING.LESSER`

## Source availability and release check

The linked repositories and releases identify the source and prebuilt runtimes used by the current development build. Before public distribution, verify that the exact corresponding source, build scripts, any Aquvi modifications, and user rights/offer required by the applicable LGPL terms are available to recipients in the required form and for the required period. The public project license for Aquvi itself has not yet been selected.
